  			
											<?php
				session_start();
				$conexao='';
				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';
				?>
											<html>  	

											<!--Início dos comandos em sql de para inícializar a tela de Inclusao e alteração --> 	

											<?php
				//se for alteração pega esse campo, se for vinculação também pega esse campo.			
				 $SQ_CISTERNAS_CADASTRO_EVENTOS_LOG= gt("SQ_CISTERNAS_CADASTRO_EVENTOS_LOG");				
				//se estiver dando apenas um refresh na tela, então envia esse campo informando, para não apagar os dados já preenchidos.
				$RETORNO_CAMPOS_SQ_CISTERNAS_CADASTRO_EVENTOS_LOG= gt("RETORNO_CAMPOS_SQ_CISTERNAS_CADASTRO_EVENTOS_LOG");


				//Se vier de outra página e essa só for uma página assessória, que segue um fluxo e volta para a anterior gt("TelaVinculadaRetorno") ao terminar a inclusão.
				if( gt("TelaVinculadaRetorno")<>"" ){
					//nome da página de retorno.
					$_SESSION["TelaVinculadaRetorno"]= gt("TelaVinculadaRetorno");
					//nome da página
					$TelaVinculadaRetorno=$_SESSION["TelaVinculadaRetorno"];
					//verifica se está vindo de algum lugar com dados preenchidos.
					if ($_SESSION[$TelaVinculadaRetorno]<>""){
						$_SESSION[$TelaVinculadaRetorno]="";
						$RETORNO_CAMPOS_SQ_CISTERNAS_CADASTRO_EVENTOS_LOG="PARAPREENCHERRETORNO";
					}else{
						//se não preenche os dados para retorna.
						//dados da página para retornar com tudo preenchido da página de retorno.
						$_SESSION[$TelaVinculadaRetorno]=fnTodosGtEPost(); 
					}
				}				

				// PODE SER UM RELOAD OU BACK NA PRÓPIA PÁGINA ou quando atualiza uma função java script de um select.
				if (($RETORNO_CAMPOS_SQ_CISTERNAS_CADASTRO_EVENTOS_LOG<>"") or (gt("atualizarCampos")=="sim")){
						
					$DT_DA_INAUGURACAO = gt("DT_DA_INAUGURACAO");
								$TP_DE_CONSTRUCAO = gt("TP_DE_CONSTRUCAO");
								$DE_DOS_MATERIAIS = gt("DE_DOS_MATERIAIS");
								$DE_ENTIDADE_MANTENEDORA = gt("DE_ENTIDADE_MANTENEDORA");
								$DE_LOCALIZACAO = gt("DE_LOCALIZACAO");
								$DE_UF = gt("DE_UF");
								$DE_ENDERECO = gt("DE_ENDERECO");
								
				} else {					
					if ($SQ_CISTERNAS_CADASTRO_EVENTOS_LOG<>""){				
						//Faz a consulta no banco de dados na tabela para retornar a lista.
						$sqlp= " select DT_DA_INAUGURACAO,TP_DE_CONSTRUCAO,DE_DOS_MATERIAIS,DE_ENTIDADE_MANTENEDORA,DE_LOCALIZACAO,DE_UF,DE_ENDERECO from cisternas_cadastro WHERE SQ_CISTERNAS_CADASTRO_EVENTOS_LOG='".$SQ_CISTERNAS_CADASTRO_EVENTOS_LOG."'";

						$resp = mysqlexecuta($conexao,$sqlp);
						while ($rowp = fnmysqli_fetch_array($resp)) {							
							
										//buscando do campo do banco de dados DT_DA_INAUGURACAO.
										$DT_DA_INAUGURACAO = fnFormataDtBdParaTelaCalendario($rowp["DT_DA_INAUGURACAO"]);	
										
											//buscando do campo do banco de dados TP_DE_CONSTRUCAO.
											$TP_DE_CONSTRUCAO = $rowp["TP_DE_CONSTRUCAO"];	
											
											//buscando do campo do banco de dados DE_DOS_MATERIAIS.
											$DE_DOS_MATERIAIS = $rowp["DE_DOS_MATERIAIS"];	
											
											//buscando do campo do banco de dados DE_ENTIDADE_MANTENEDORA.
											$DE_ENTIDADE_MANTENEDORA = $rowp["DE_ENTIDADE_MANTENEDORA"];	
											
											//buscando do campo do banco de dados DE_LOCALIZACAO.
											$DE_LOCALIZACAO = $rowp["DE_LOCALIZACAO"];	
											
											//buscando do campo do banco de dados DE_UF.
											$DE_UF = $rowp["DE_UF"];	
											
											//buscando do campo do banco de dados DE_ENDERECO.
											$DE_ENDERECO = $rowp["DE_ENDERECO"];	
											
						}; 
					}else {						
						$DT_DA_INAUGURACAO = "";
									$TP_DE_CONSTRUCAO = "";
									$DE_DOS_MATERIAIS = "";
									$DE_ENTIDADE_MANTENEDORA = "";
									$DE_LOCALIZACAO = "";
									$DE_UF = "";
									$DE_ENDERECO = "";
									
					}			  
					
				}
				?>
				
				

											<!--Fim dos comandos em sql de para inícializar a tela de Inclusao e alteração --> 		

											<link href='css/bootstrap.css' rel='stylesheet'><link href='_css_estiloGeral.css' rel='stylesheet'>

											<!--Início dos comandos em JavaScript na tela de Inclusao e alteração --> 

												
			<script language=javaScript> 
				function fnSubmit(IeNew){					 
						

					// Validando no javaScript o campo document.formCadastro.DT_DA_INAUGURACAO,'O preenchimento do campo (Data da inauguração) é obrigatório.','OBRIGATÓRIO','Date' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formCadastro.DT_DA_INAUGURACAO,'O preenchimento do campo (Data da inauguração) é obrigatório.','OBRIGATÓRIO','Date')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						

					// Validando no javaScript o campo document.formCadastro.TP_DE_CONSTRUCAO,'O preenchimento do campo (Tipo de construção) é obrigatório.','OBRIGATÓRIO','Selecao' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formCadastro.TP_DE_CONSTRUCAO,'O preenchimento do campo (Tipo de construção) é obrigatório.','OBRIGATÓRIO','Selecao')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						

					// Validando no javaScript o campo document.formCadastro.DE_ENTIDADE_MANTENEDORA,'O preenchimento do campo (Entidade mantenedora) é obrigatório.','OBRIGATÓRIO','Selecao' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formCadastro.DE_ENTIDADE_MANTENEDORA,'O preenchimento do campo (Entidade mantenedora) é obrigatório.','OBRIGATÓRIO','Selecao')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						

					// Validando no javaScript o campo document.formCadastro.DE_LOCALIZACAO,'O preenchimento do campo (Localização GPS) é obrigatório.','OBRIGATÓRIO','text' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formCadastro.DE_LOCALIZACAO,'O preenchimento do campo (Localização GPS) é obrigatório.','OBRIGATÓRIO','text')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						

					// Validando no javaScript o campo document.formCadastro.DE_UF,'O preenchimento do campo (UF) é obrigatório.','OBRIGATÓRIO','Selecao' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formCadastro.DE_UF,'O preenchimento do campo (UF) é obrigatório.','OBRIGATÓRIO','Selecao')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						

					// Validando no javaScript o campo document.formCadastro.DE_ENDERECO,'O preenchimento do campo (Endereço) é obrigatório.','OBRIGATÓRIO','text' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formCadastro.DE_ENDERECO,'O preenchimento do campo (Endereço) é obrigatório.','OBRIGATÓRIO','text')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						
					//Para validar se já quer voltar para tela de inclusão novamente para preencher os dados novamente.
					document.formCadastro.IeNew.value=IeNew;					
					document.formCadastro.submit();
				}
				//Aqui atualiza a própria página no caso de um campo ser vinculado ao outro ai só colocar nos  parametrosAdicionais= onchange='fnAtualizarPropriaPagina();' '; do select e na clausula where do próximo campos clausulaWhere='WHERE '1'='.TP_DE_MARCACAO.' AND DE_CLINICA='._SESSION['DE_CLINICA'].'	
				function fnAtualizarPropriaPagina(){
					document.formCadastro.action='Cadastro_eventos_log_Edit.php?atualizarCampos=sim';					
					document.formCadastro.submit();
				}
			</script> 				
			<script language=javaScript> 
				function fnValidaCampo(campo,Mensagem,TipoDeValidacao,TipoDeCampo){
					//se o usuário pediu para não mostrar esse campo então pode incluir ele vazio mesmo que esteja como obrigatório.
					if(campo==undefined){
						return true;
					}else{
						if (campo.value==0){
							fnMensagem(Mensagem);
							campo.focus();
							return false;
						}							
						return true;
					}
				}
			</script> 				
			<script language=javaScript> 	
			    function fnExcluir(LinkExclusao,MensagemPergunta){
					var retorno = confirm(MensagemPergunta);
					if (retorno){
						window.location=LinkExclusao;
						return true;
					} else {
						return false;
					}
				}
			    function fnAlterar(LinkAlteracao){
 					window.location=LinkAlteracao;
				}				
				function fnMensagem(Mensagem){
					//assim pode mudar em apenas um lugar e colocar em um div, ou no topo da página como o cliente desejar alterando só nesse arquivo.
					alert(Mensagem);
				}
	
			</script> 
					<!--AS JavaScript /AS-->

											<!--Fim dos comandos em JavaScript na tela de Inclusao e alteração -->

											<!--Início dos comandos em FormatacaoJQuery na tela de Inclusao e alteração --> 

											<script language=javaScript>$("#DT_DA_INAUGURACAO").mask("99/99/9999");$("#DT_DA_INAUGURACAO").mask("99/99/9999 99:99:99");").mask("99/99/9999 99:99:99");</script>
											
											<!--Fim dos comandos em FormatacaoJQuery na tela de Inclusao e alteração -->											

											<body id='idBody' onload="">
											<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "menu.php"; 
			?> <?php  }; ?>
											<form id='formCadastro' name='formCadastro' action='Cadastro_eventos_logEdit_banco.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'  method='POST' >
												<table class='clDetalhesIncluir'>
													<tr><td class='clTitulo' colspan=100%>
														<br/><br/>Cadastro
													</td></tr>
													<tr><td>
														
										 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_CADASTRO_EVENTOS_LOG','DT_DA_INAUGURACAO')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrDT_DA_INAUGURACAO'>
									 		<td class='classTd' style='display:block' id='idclassTdDT_DA_INAUGURACAO'>
										 		<div class='classLabel' style='display:block' id='idclassLabelDT_DA_INAUGURACAO'>
														<!-- início na tela Cadastro_Edit do label DT_DA_INAUGURACAO -->
														Data da inauguração
														<!-- fim na tela Cadastro_Edit do label DT_DA_INAUGURACAO -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdDT_DA_INAUGURACAO'>

													<!-- início na tela Cadastro_Edit do campo DT_DA_INAUGURACAO --> 
													
													<input class='classInput'  type='Date' name='DT_DA_INAUGURACAO' 
															id='DT_DA_INAUGURACAO' 
															
															Width='-1'
															Height='-1'
															MaxLength='100'	
															Title='Data da inauguração'
															value='<?php echo $DT_DA_INAUGURACAO;?>'
															 
							onKeyPress="return digitos(event, this);" 
							onKeyUp="funcoesGlobaisMascaraGeral('DATA',this,event);"
							onBlur="funcoesGlobaisValidaData('',this);"
							 

														
															/>
															<!-- fim na tela Cadastro_Edit do campo DT_DA_INAUGURACAO -->															
													</span>
												</td>
											</tr>
									 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_CADASTRO_EVENTOS_LOG','TP_DE_CONSTRUCAO')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrTP_DE_CONSTRUCAO'>
									 	<td class='classTd' style='display:block' id='idclassTdTP_DE_CONSTRUCAO'>
										 	<div class='classLabel' style='display:block' id='idclassLabelTP_DE_CONSTRUCAO'>
													<!-- início na tela Cadastro_Edit do label TP_DE_CONSTRUCAO -->
													Tipo de construção
													<!-- fim na tela Cadastro_Edit do label TP_DE_CONSTRUCAO -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdTP_DE_CONSTRUCAO'>
												<!-- início na tela Cadastro_Edit do campo TP_DE_CONSTRUCAO -->
													<?php 
													//Montando o campo de select options com os seguintes dados.
													$tabela='cisternas_tipodeconstrucao';
													$campoValor='SQ_CISTERNAS_TIPODECONSTRUCAO';
													$CampoDescricao="DE_NOME";
													$clausulaWhere='  ';
													$valorSelecionado=$TP_DE_CONSTRUCAO;
													$nomeCampo='TP_DE_CONSTRUCAO';
													//para adicionar funções estilos etc.
													$parametrosAdicionais='';
													$sqlSelect= "SELECT ".$campoValor." as Valor, ".$CampoDescricao." as Descricao  FROM ".$tabela." ".$clausulaWhere." ";
													$respSelect = mysqlexecuta($conexao,$sqlSelect);
													//	Monta o select de acordo com os dados informados echo($sqlSelect);
													echo '<select  name="'.$nomeCampo.'" id="'.$nomeCampo.'" '.$parametrosAdicionais.' >';
														echo '<option value=""></options>';					
														while ($rowSelect = fnmysqli_fetch_array($respSelect)) { 
															//faz todo o loop consultando os campos.
															?>
																<option <?php 
																		
																		if($valorSelecionado==$rowSelect['Valor']){
																			echo 'selected';
																		}; ?> 
																value='<?php echo $rowSelect['Valor']; ?>'
																><?php echo $rowSelect['Descricao']; ?></option>
															<?php
														} //fim do while.
														?>
														</select>	
												<!-- fim na tela Cadastro_Edit do campo TP_DE_CONSTRUCAO -->
											</div>
												
											</td>
										</tr>
									<tr  class='classTr'>
										<td class='classTd'>
											<div class='classLabel'>Descrição dos materiais</div>
											<div  class='classCampo'>	<script type='text/javascript'>
												window.onload = function()  {
												CKEDITOR.replace('DE_DOS_MATERIAIS');
												};
												</script> 
												
														<textarea 
														name='DE_DOS_MATERIAIS'
														class='classInput'
														
														id='DE_DOS_MATERIAIS'
														Title='<'
														cols=''
														rows=''
														MaxLength='8000'><?php echo urldecode($DE_DOS_MATERIAIS);?></textarea>	
											</div>
										</td>
									</tr>
									 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_CADASTRO_EVENTOS_LOG','DE_ENTIDADE_MANTENEDORA')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrDE_ENTIDADE_MANTENEDORA'>
									 	<td class='classTd' style='display:block' id='idclassTdDE_ENTIDADE_MANTENEDORA'>
										 	<div class='classLabel' style='display:block' id='idclassLabelDE_ENTIDADE_MANTENEDORA'>
													<!-- início na tela Cadastro_Edit do label DE_ENTIDADE_MANTENEDORA -->
													Entidade mantenedora
													<!-- fim na tela Cadastro_Edit do label DE_ENTIDADE_MANTENEDORA -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdDE_ENTIDADE_MANTENEDORA'>
												<!-- início na tela Cadastro_Edit do campo DE_ENTIDADE_MANTENEDORA -->
													<?php 
													//Montando o campo de select options com os seguintes dados.
													$tabela='cisternas_entidademantenedora';
													$campoValor='SQ_CISTERNAS_ENTIDADEMANTENEDORA';
													$CampoDescricao="CONCAT(NU_CNPJ,'-',NO_FANTASIA)";
													$clausulaWhere='    ';
													$valorSelecionado=$DE_ENTIDADE_MANTENEDORA;
													$nomeCampo='DE_ENTIDADE_MANTENEDORA';
													//para adicionar funções estilos etc.
													$parametrosAdicionais='';
													$sqlSelect= "SELECT ".$campoValor." as Valor, ".$CampoDescricao." as Descricao  FROM ".$tabela." ".$clausulaWhere." ";
													$respSelect = mysqlexecuta($conexao,$sqlSelect);
													//	Monta o select de acordo com os dados informados echo($sqlSelect);
													echo '<select  name="'.$nomeCampo.'" id="'.$nomeCampo.'" '.$parametrosAdicionais.' >';
														echo '<option value=""></options>';					
														while ($rowSelect = fnmysqli_fetch_array($respSelect)) { 
															//faz todo o loop consultando os campos.
															?>
																<option <?php 
																		
																		if($valorSelecionado==$rowSelect['Valor']){
																			echo 'selected';
																		}; ?> 
																value='<?php echo $rowSelect['Valor']; ?>'
																><?php echo $rowSelect['Descricao']; ?></option>
															<?php
														} //fim do while.
														?>
														</select>	
												<!-- fim na tela Cadastro_Edit do campo DE_ENTIDADE_MANTENEDORA -->
											</div>
												
											</td>
										</tr>
										 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_CADASTRO_EVENTOS_LOG','DE_LOCALIZACAO')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrDE_LOCALIZACAO'>
									 		<td class='classTd' style='display:block' id='idclassTdDE_LOCALIZACAO'>
										 		<div class='classLabel' style='display:block' id='idclassLabelDE_LOCALIZACAO'>
														<!-- início na tela Cadastro_Edit do label DE_LOCALIZACAO -->
														Localização GPS
														<!-- fim na tela Cadastro_Edit do label DE_LOCALIZACAO -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdDE_LOCALIZACAO'>

													<!-- início na tela Cadastro_Edit do campo DE_LOCALIZACAO --> 
													
													<input class='classInput'  type='text' name='DE_LOCALIZACAO' 
															id='DE_LOCALIZACAO' 
															
															Width='-1'
															Height='-1'
															MaxLength='100'	
															Title='Localização GPS'
															value='<?php echo $DE_LOCALIZACAO;?>'
															 

														
															/>
															<!-- fim na tela Cadastro_Edit do campo DE_LOCALIZACAO -->															
													</span>
												</td>
											</tr>
									 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_CADASTRO_EVENTOS_LOG','DE_UF')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrDE_UF'>
									 	<td class='classTd' style='display:block' id='idclassTdDE_UF'>
										 	<div class='classLabel' style='display:block' id='idclassLabelDE_UF'>
													<!-- início na tela Cadastro_Edit do label DE_UF -->
													UF
													<!-- fim na tela Cadastro_Edit do label DE_UF -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdDE_UF'>
												<!-- início na tela Cadastro_Edit do campo DE_UF -->
													<?php 
													//Montando o campo de select options com os seguintes dados.
													$tabela='cisternas_uf';
													$campoValor='SQ_CISTERNAS_UF';
													$CampoDescricao="DE_NOME";
													$clausulaWhere=' ';
													$valorSelecionado=$DE_UF;
													$nomeCampo='DE_UF';
													//para adicionar funções estilos etc.
													$parametrosAdicionais='';
													$sqlSelect= "SELECT ".$campoValor." as Valor, ".$CampoDescricao." as Descricao  FROM ".$tabela." ".$clausulaWhere." ";
													$respSelect = mysqlexecuta($conexao,$sqlSelect);
													//	Monta o select de acordo com os dados informados echo($sqlSelect);
													echo '<select  name="'.$nomeCampo.'" id="'.$nomeCampo.'" '.$parametrosAdicionais.' >';
														echo '<option value=""></options>';					
														while ($rowSelect = fnmysqli_fetch_array($respSelect)) { 
															//faz todo o loop consultando os campos.
															?>
																<option <?php 
																		
																		if($valorSelecionado==$rowSelect['Valor']){
																			echo 'selected';
																		}; ?> 
																value='<?php echo $rowSelect['Valor']; ?>'
																><?php echo $rowSelect['Descricao']; ?></option>
															<?php
														} //fim do while.
														?>
														</select>	
												<!-- fim na tela Cadastro_Edit do campo DE_UF -->
											</div>
												
											</td>
										</tr>
										 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_CADASTRO_EVENTOS_LOG','DE_ENDERECO')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrDE_ENDERECO'>
									 		<td class='classTd' style='display:block' id='idclassTdDE_ENDERECO'>
										 		<div class='classLabel' style='display:block' id='idclassLabelDE_ENDERECO'>
														<!-- início na tela Cadastro_Edit do label DE_ENDERECO -->
														Endereço
														<!-- fim na tela Cadastro_Edit do label DE_ENDERECO -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdDE_ENDERECO'>

													<!-- início na tela Cadastro_Edit do campo DE_ENDERECO --> 
													
													<input class='classInput'  type='text' name='DE_ENDERECO' 
															id='DE_ENDERECO' 
															
															Width='-1'
															Height='-1'
															MaxLength='100'	
															Title='Endereço'
															value='<?php echo $DE_ENDERECO;?>'
															 

														
															/>
															<!-- fim na tela Cadastro_Edit do campo DE_ENDERECO -->															
													</span>
												</td>
											</tr><input 	
								type='hidden' 
								name='SQ_CISTERNAS_CADASTRO_EVENTOS_LOG' 
								id='SQ_CISTERNAS_CADASTRO_EVENTOS_LOG' 
								value='<?php echo $SQ_CISTERNAS_CADASTRO_EVENTOS_LOG; ?>'> <?php $_SESSION['RETORNO_Cadastro_Edit']=fnTodosGtEPost(); ?>
													</td></tr>
													<tr><td>										
														
				<tr class='classTrButton'>		
					<td colspan=100% class='classtdButton'>
						<!--  Edit início do botão de envio -->
						<input class='btn btn-primary btn-sm mt-1' 	
								type='button' 
								<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_CADASTRO_EVENTOS_LOG','btSubmit')){ echo '';} else { echo 'style="display:none"';}; ?>
								name='btSubmit' 
								title='Envia e aparece a tela de confirmação, inclusão de um único registro.'
								id='btSubmit'
								onClick='fnSubmit("N");'
								value='Enviar'	 											
								>	
								&nbsp;&nbsp;&nbsp;&nbsp;
						<!-- Edit fim do botão de envio  -->	
						<!-- Edit início do botão de envio e Novo  -->													
						<input class='btn btn-primary btn-sm mt-1' 
						       <?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_CADASTRO_EVENTOS_LOG','btSubmitEnviarENovo')){ echo '';} else { echo 'style="display:none"';}; ?>	
								type='button' 
								title='Envia e já volta para essa tela só com os campos que normalmente já são preenchidos repetidos para efetuar um novo cadastro.'
								name='btSubmitEnviarENovo' 
								id='btSubmitEnviarENovo'
								onClick='fnSubmit("S");'
								value='Enviar e Novo'	 											
								>	
								<input type=hidden value='N' id='IeNew' name='IeNew'/>
								 &nbsp;&nbsp;&nbsp;&nbsp;
						<!-- Edit fim do botão de envio e Novo -->	
						<!-- Edit início do botão de voltar -->															 
						 <input class='btn btn-primary btn-sm mt-1'  	
						 <?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_CADASTRO_EVENTOS_LOG','btVoltar')){ echo '';} else { echo 'style="display:none"';}; ?>
								type='button' 
								title='Volta a tela anterior.'
								name='btVoltar' 
								onClick='history.go(-1);'
								id='btVoltar' 
								value='Voltar'	 											
								>
						<!-- Edit fim do botão de voltar -->
						<!-- Edit início do botão de upload -->									
								<a  <?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_CADASTRO_EVENTOS_LOG','btUploadVariosArquivos')){ echo '';} else { echo 'style="display:none"';}; ?>  href=# onClick='fnUploadArquivoParaBase("cisternas_cadastro","#DT_DA_INAUGURACAO#,#TP_DE_CONSTRUCAO#,#DE_DOS_MATERIAIS#,#DE_ENTIDADE_MANTENEDORA#,#DE_LOCALIZACAO#,#DE_UF#,#DE_ENDERECO#","fnFormataDtBd(DT_DA_INAUGURACAO) ,#TP_DE_CONSTRUCAO# ,#DE_DOS_MATERIAIS# ,#DE_ENTIDADE_MANTENEDORA# ,#DE_LOCALIZACAO# ,#DE_UF# ,#DE_ENDERECO# ");'	>							
								<img src='images/upload.png' class='imgupload' title="Para subir arquivos um arquivo com vários registros é necessário deixar ele no formato que separe os campos por virgula. Não é necessário enviar cabeçalho, só precisa enviar a quantidade de títulos iguais ao dessa tela de inclusão e na mesma ordem dessa tela de inclusão, segue a orderm: ('Data da inauguração','Tipo de construção','Descrição dos materiais','Entidade mantenedora','Localização GPS','UF','Endereço')" >
								</a>
						<!-- Edit fim do botão de upload -->	
								
					</td>
				</tr>
													</td></tr>
													<tr><td colspan=100% >										
																												
													</td></tr>													
													<tr><td colspan=100% >										
																												
													</td></tr>
													<tr><td class='MensagemRodape' colspan=100%>
													<hr/>											
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>Cadastro<?php  }; ?>
													</td></tr>
												</table>
											</form>												
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "rodape.php"; 
			?> <?php  }; ?>											
											<form name='frmArquivo' action='uploadArquivoPg.php'>
												<input type=hidden value='' name='tabelaGravar'>
												<input type=hidden value='' name='strCabecalhoRegras'>
												<input type=hidden value='' name='strCabecalho'>
											</form>
											</body>
											</html>