<?php
error_reporting (E_ALL & ~ E_NOTICE & ~ E_DEPRECATED);

		//if($_SERVER['SERVER_NAME']<>'localhost'){
			if('localhost'<>'localhost'){
			//conexão com o servidor
			$conexao  = mysql_connect("localhost", "bd", "bds");
			 
			  //$mysqli = new mysqli("localhost", "my_user", "my_password", "test");
				
			// Caso a conexão seja reprovada, exibe na tela uma mensagem de erro
			if (!$conexao) die ("<h1>Falha ao conectar com o Banco de Dados!</h1>");
			 
			//$conect->set_charset("utf8");
			mysql_set_charset('utf8', $conect);

			// Caso a conexão seja aprovada, então conecta o Banco de Dados.	
			$conect = mysql_select_db("bd",$conexao  );

		}
		//aqui faz o bloqueio para só chamar a página do banco de dados somente uma vez para segurança da aplicação.
		//faz aqui para acessar a própria página se não for _banco, que se for banco já tem que estar preenchida.
        $executar= fnSegurancaPost(); 
		
		$_SESSION["LOG_N"]=$_SESSION["LOG_N"].$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]."REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA.<br><br>";
		//preenche esse dado no servidor anterior se estiver em brano não acessa a página.
		if($_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]==""){
				echo "Erro ao acessar o servidor xr.";
				$_SESSION["LOG_N"]=$_SESSION["LOG_N"]."Erro ao acessar o servidor xr.<br><br>";
							  exit;
		};
			if (   ($_SERVER["REQUEST_URI"]=='/GCPHP/cadastroIncluirPost.php')
				or ($_SERVER["REQUEST_URI"]=='/GCPHP/geradorCodigoConsultasAjax.php')
			)
			{
				$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["REQUEST_URI"];
			} else {
				$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]="";
			}
			
		//faz aqui para acessar a PROXIMA página QUE É BANCO.
        $executar= fnSegurancaPost(); 			
	
function fnSubstituirTudoConexaobanco($str){
    $str=str_replace('=','KhrefIGUAL',$str);
    $str=str_replace('DOCTYPE','KDOCTIGUAL',$str);
    $str=str_replace('<','KmenorTIGUAL',$str);
    $str=str_replace('>','KmaiorTIGUAL',$str);
    return $str;
}		
/*Configurando este arquivo, depois é só você dar um include em suas paginas php, isto facilita muito, pois caso haja necessidade de mudar seu Banco de Dados
você altera somente um arquivo

Esta função executa um comando SQL no banco de dados MySQL
$id – Ponteiro da Conexão 
$sql – Cláusula SQL a executar 
$erro – Especifica se a função exibe ou não(0=não, 1=sim)

$res – Resposta 
*/ 
function mysqlexecutaMySQLSemCli($id,$sql,$erro = 1) { 
//$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["REQUEST_URI"];
			//aqui coloca as excessões, que tem em todo rodapé mas não tem onde tem a palavra banco, para segurança e para não incluir ao clicar duas vezes.

	$mystring = strtolower($sql);
	$findme   = 'select';
	$pos = strpos($mystring, $findme);

	// Note o uso de ===.  Simples == não funcionaria como esperado
	// se não tiver a palavra select então é um insert update ou delete, lógico que tem insert com select mas não nesse código.
	if ($pos === false) {
		//echo "A string '$findme' não foi encontrada na string '$mystring'";

	//
	// Abre ou cria o arquivo ComandosSQlExecutado.txt para salvar todos os comandos enviados para o banco de dados,um tipo de backup incremental, e registro de log, debug.
	// "a" representa que o arquivo é aberto para ser escrito
	$fp = fopen("ComandosSQlExecutado.txt", "a");

	// Escreve "exemplo de escrita" no ComandosSQlExecutado.txt salva a data hora minuto e segundo executado.
	$escreve = fwrite($fp, "/*".date('d/m/Y H:i:s')."*/");

	// Escreve "exemplo de escrita" no ComandosSQlExecutado.txt salva o comando sql enviado.
	$escreve = fwrite($fp, $sql);

	// Fecha o arquivo
	fclose($fp); //-> OK
	}
	//execulta o comando sql.
		if(empty($sql) OR !($id)) 
		   return 0; 
   
   
	   
	   //VERIFICA SE PODE ACESSAR O BANCO UM TIPO DE SEGURANÇA.
		$mystring = strtolower($sql);
		$findme   = 'select';
		$pos = strpos($mystring, $findme);
        $podeAcessarOBanco="SIM";
		// Note o uso de ===.  Simples == não funcionaria como esperado
		// se não tiver a palavra select então é um insert update ou delete, lógico que tem insert com select mas não nesse código.
		if ($pos === false) {
		/*	//echo "A string '$findme' não foi encontrada na string '$mystring'";
			if($_SESSION["HTTP_HOST_ATUAL_REQUISICAO_SEGURANCA"]!=$_SERVER["HTTP_HOST"]
				or $_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]==""){
					$_SESSION["HTTP_HOST_ATUAL_REQUISICAO_SEGURANCA"]="";
 
					//POR SEGURANÇA NÃO PODE ACESSAR MAIS O BANCO POIS DEU DOIS CLIQUES NO UPDATE OU INSERT E ISSO É PROIBIDO.
					$podeAcessarOBanco="NAO";
					
			};
			//COM ISSO SÓ ACESSA UMA VEZ POR PÁGINA.
      		if (   ($_SERVER["REQUEST_URI"]=='/GCPHP/cadastroIncluirPost.php')
				or ($_SERVER["REQUEST_URI"]=='/GCPHP/geradorCodigoConsultasAjax.php')
			)
			{
				$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["REQUEST_URI"];
			}else{
				$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]="";	
			};*/
		}
		else{
		//	$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["REQUEST_URI"];
		};
		//Erro na conexão ou no comando SQL   
		//if ($podeAcessarOBanco=="SIM")  {
					$_SESSION["LOG_SQLN"]=$_SESSION["LOG_SQLN"]."107".$sql;
				  
				  //Erro na conexão ou no comando SQL   
			   if (!($res = @mysql_query($sql,$id))) {

				  if($erro) 
					echo "Ocorreu um erro na execução do Comando SQL no banco de dados. Favor Contactar o Administrador.";
				  exit;
			   };
   	//	}else{
		//	echo "";
		//}   
    return $res; 
 }


function fnFormatarText($texto){
$formatado=strip_tags($texto);
$formatado=str_replace('Á','&Aacute;',$formatado);
$formatado=str_replace('á','&aacute;',$formatado);
$formatado=str_replace('Â','&Acirc;',$formatado);
$formatado=str_replace('â','&acirc;',$formatado);
$formatado=str_replace('À','&Agrave;',$formatado);
$formatado=str_replace('à','&agrave;',$formatado);
$formatado=str_replace('Å','&Aring;',$formatado);
$formatado=str_replace('å','&aring;',$formatado);
$formatado=str_replace('Ã','&Atilde;',$formatado);
$formatado=str_replace('ã','&atilde;',$formatado);
$formatado=str_replace('Ä','&Auml;',$formatado);
$formatado=str_replace('ä','&auml;',$formatado);
$formatado=str_replace('Æ','&AElig;',$formatado);
$formatado=str_replace('æ','&aelig;',$formatado);
$formatado=str_replace('É','&Eacute;',$formatado);
$formatado=str_replace('é','&eacute;',$formatado);
$formatado=str_replace('Ê','&Ecirc;',$formatado);
$formatado=str_replace('ê','&ecirc;',$formatado);
$formatado=str_replace('È','&Egrave;',$formatado);
$formatado=str_replace('è','&egrave;',$formatado);
$formatado=str_replace('Ë','&Euml;',$formatado);
$formatado=str_replace('ë','&euml;',$formatado);
$formatado=str_replace('Ð','&ETH;',$formatado);
$formatado=str_replace('ð','&eth;',$formatado);
$formatado=str_replace('Í','&Iacute;',$formatado);
$formatado=str_replace('í','&iacute;',$formatado);
$formatado=str_replace('Î','&Icirc;',$formatado);
$formatado=str_replace('î','&icirc;',$formatado);
$formatado=str_replace('Ì','&Igrave;',$formatado);
$formatado=str_replace('ì','&igrave;',$formatado);
$formatado=str_replace('Ï','&Iuml;',$formatado);
$formatado=str_replace('ï','&iuml;',$formatado);
$formatado=str_replace('Ó','&Oacute;',$formatado);
$formatado=str_replace('ó','&oacute;',$formatado);
$formatado=str_replace('Ô','&Ocirc;',$formatado);
$formatado=str_replace('ô','&ocirc;',$formatado);
$formatado=str_replace('Ò','&Ograve;',$formatado);
$formatado=str_replace('ò','&ograve;',$formatado);
$formatado=str_replace('Ø','&Oslash;',$formatado);
$formatado=str_replace('ø','&oslash;',$formatado);
$formatado=str_replace('Õ','&Otilde;',$formatado);
$formatado=str_replace('õ','&otilde;',$formatado);
$formatado=str_replace('Ö','&Ouml;',$formatado);
$formatado=str_replace('ö','&ouml;',$formatado);
$formatado=str_replace('Ú','&Uacute;',$formatado);
$formatado=str_replace('ú','&uacute;',$formatado);
$formatado=str_replace('Û','&Ucirc;',$formatado);
$formatado=str_replace('û','&ucirc;',$formatado);
$formatado=str_replace('Ù','&Ugrave;',$formatado);
$formatado=str_replace('ù','&ugrave;',$formatado);
$formatado=str_replace('Ü','&Uuml;',$formatado);
$formatado=str_replace('ü','&uuml;',$formatado);
$formatado=str_replace('Ç','&Ccedil;',$formatado);
$formatado=str_replace('ç','&ccedil;',$formatado);
$formatado=str_replace('Ñ','&Ntilde;',$formatado);
$formatado=str_replace('ñ','&ntilde;',$formatado);
$formatado=str_replace('<','&lt;',$formatado);
$formatado=str_replace('>','&gt;',$formatado);
//$formatado=str_replace('&','&amp;',$formatado);
$formatado=str_replace('"','&quot;',$formatado);
$formatado=str_replace('®','&reg;',$formatado);
$formatado=str_replace('©','&copy;',$formatado);
$formatado=str_replace('Ý','&Yacute;',$formatado);
$formatado=str_replace('ý','&yacute;',$formatado);
$formatado=str_replace('Þ','&THORN;',$formatado);
$formatado=str_replace('þ','&thorn;',$formatado);
$formatado=str_replace('ß','&szlig;',$formatado);
return $formatado;
}
/*Configurando este arquivo, depois é só você dar um include em suas paginas php, isto facilita muito, pois caso haja necessidade de mudar seu Banco de Dados
você altera somente um arquivo
$sql – Cláusula SQL a executar 
$res – Resposta 
*/ 
function mysqlexecuta($idconexao,$sql) { 
//$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["REQUEST_URI"];
			//aqui coloca as excessões, que tem em todo rodapé mas não tem onde tem a palavra banco, para segurança e para não incluir ao clicar duas vezes.
		/*	if (   ($_SERVER["REQUEST_URI"]=='/GCPHP/cadastroIncluirPost.php')
				or ($_SERVER["REQUEST_URI"]=='/GCPHP/geradorCodigoConsultasAjax.php')
			){
				$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["REQUEST_URI"];
			};
			*/
	$_SESSION["LOG_SQLN"]=$_SESSION["LOG_SQLN"]."208".$sql;
	//$DBConnect = new mysqli("127.0.0.1","root","","Ladle"); 
	//CONEXÃO MAIS AVANÇADA COM PROCEDURES E OBJETOS MYSQLI
//	if ($_SERVER['SERVER_NAME']=='localhost'){
		if ('localhost'=='localhost'){	
			if ($_SERVER['SERVER_NAME']=='localhost'){	
				$conect = new mysqli('localhost', 'root', '', 'bd');
			} else {		
				$conect = new mysqli('localhost', 'bd', 'bdss', 'bd');
			}	
		//$conect = new mysqli('127.0.0.1', 'root', '', 'bd_gerador_de_codigo');
		//$conect = mysql_connect("localhost", "cerimoni_bd", "grupo300123");

		if (!$conect) {
			die('Connect Error (' . mysqli_connect_errno() . ') '
					. mysqli_connect_error()); }

		$mystring = strtolower($sql);
		$findme   = 'select';
		$pos = strpos($mystring, $findme);
 
		// Note o uso de ===.  Simples == não funcionaria como esperado
		// se não tiver a palavra select então é um insert update ou delete, lógico que tem insert com select mas não nesse código.
		if ($pos === false) {


			//
			// Abre ou cria o arquivo ComandosSQlExecutado.txt para salvar todos os comandos enviados para o banco de dados,um tipo de backup incremental, e registro de log, debug.
			// "a" representa que o arquivo é aberto para ser escrito
			$fp = fopen("ComandosSQlUpdateDeleteInsertExecutados.txt", "a");

			// Escreve "exemplo de escrita" no ComandosSQlExecutado.txt salva a data hora minuto e segundo executado.
			$escreve = fwrite($fp, "/*".date('d/m/Y H:i:s')."*/");

			// Escreve "exemplo de escrita" no ComandosSQlExecutado.txt salva o comando sql enviado.
			$escreve = fwrite($fp, $sql);

			// Fecha o arquivo
			fclose($fp); //-> OK
		}
	//	else{
		//	$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["REQUEST_URI"];
		//};
			//	
		if(empty($sql)) 
		   return 0; 
	   
	   //VERIFICA SE PODE ACESSAR O BANCO UM TIPO DE SEGURANÇA.
		$mystring = strtolower($sql);
		$findme   = 'select';
		$pos = strpos($mystring, $findme);
        $podeAcessarOBanco="SIM";
		// Note o uso de ===.  Simples == não funcionaria como esperado
		// se não tiver a palavra select então é um insert update ou delete, lógico que tem insert com select mas não nesse código.
		if ($pos === false) {
			//echo "A string '$findme' não foi encontrada na string '$mystring'";
		/*	if($_SESSION["HTTP_HOST_ATUAL_REQUISICAO_SEGURANCA"]!=$_SERVER["HTTP_HOST"]
				or $_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]==""){
				//	$_SESSION["HTTP_HOST_ATUAL_REQUISICAO_SEGURANCA"]="";
                    //COM ISSO SÓ ACESSA UMA VEZ POR PÁGINA.
      				//$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]="";
					//POR SEGURANÇA NÃO PODE ACESSAR MAIS O BANCO POIS DEU DOIS CLIQUES NO UPDATE OU INSERT E ISSO É PROIBIDO.
					$podeAcessarOBanco="NAO";
						//COM ISSO SÓ ACESSA UMA VEZ POR PÁGINA.
	
			};
      		if (   ($_SERVER["REQUEST_URI"]=='/GCPHP/cadastroIncluirPost.php')
				or ($_SERVER["REQUEST_URI"]=='/GCPHP/geradorCodigoConsultasAjax.php')
			)
			{
				$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["REQUEST_URI"];
			}else{
				$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]="";	
			};	
				*/
			
		}
		else{
		//	$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["REQUEST_URI"];
		};
		   $_SESSION["LOG_SQLN"]=$_SESSION["LOG_SQLN"]."<br/><br/>282".$sql;
		//Erro na conexão ou no comando SQL   
	//	if ($podeAcessarOBanco=="SIM")  {
		   $_SESSION["LOG_SQLN"]=$_SESSION["LOG_SQLN"]."<br/><br/>284".$sql;
			$query = $sql or die("Ocorreu um erro na execução do Comando SQL no banco de dados. Favor Contactar o dba." . mysqli_error($conect));  
			$result = $conect->query($query); 
	//	}else{
		//	echo "";
		//};
	} else {
	   //VERIFICA SE PODE ACESSAR O BANCO UM TIPO DE SEGURANÇA.
		$mystring = strtolower($sql);
		$findme   = 'select';
		$pos = strpos($mystring, $findme);
        $podeAcessarOBanco="SIM";
		// Note o uso de ===.  Simples == não funcionaria como esperado
		// se não tiver a palavra select então é um insert update ou delete, lógico que tem insert com select mas não nesse código.
		if ($pos === false) {
			//echo "A string '$findme' não foi encontrada na string '$mystring'";
		/*	if($_SESSION["HTTP_HOST_ATUAL_REQUISICAO_SEGURANCA"]!=$_SERVER["HTTP_HOST"]
				or $_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]==""){
				//	$_SESSION["HTTP_HOST_ATUAL_REQUISICAO_SEGURANCA"]="";
                    //COM ISSO SÓ ACESSA UMA VEZ POR PÁGINA.
      			//	$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]="";
					//POR SEGURANÇA NÃO PODE ACESSAR MAIS O BANCO POIS DEU DOIS CLIQUES NO UPDATE OU INSERT E ISSO É PROIBIDO.
					$podeAcessarOBanco="NAO";
					
			};
			

			//COM ISSO SÓ ACESSA UMA VEZ POR PÁGINA.
      		if (   ($_SERVER["REQUEST_URI"]=='/GCPHP/cadastroIncluirPost.php')
				or ($_SERVER["REQUEST_URI"]=='/GCPHP/geradorCodigoConsultasAjax.php')
			)
			{
				$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["REQUEST_URI"];
			}else{
				$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]="";	
			};
			*/
		}
		else{
		//	$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["REQUEST_URI"];
		};
				    $_SESSION["LOG_SQLN"]=$_SESSION["LOG_SQLN"]."326".$sql;
	//	if ($podeAcessarOBanco=="SIM")  {
		    $_SESSION["LOG_SQLN"]=$_SESSION["LOG_SQLN"]."328".$sql;
			$result=mysqlexecutaMySQLSemCli($idconexao,$sql);
		//}else{
		//	echo "";
		//};
	}
	return $result; 
 }
 			//echo $_SERVER["REQUEST_URI"];                           
 function fnmysqli_fetch_array($resp){

	if ($_SERVER['SERVER_NAME']=='localhost'){				
		$retorno= mysqli_fetch_array($resp);
	} else {
		$retorno= mysqli_fetch_array($resp);

	       //$retorno= mysql_fetch_array($resp); v 5.6

	}
	return $retorno;
 }
  function fnmysqli_fetch_field($resp){
	if ($_SERVER['SERVER_NAME']=='localhost'){				
		$retorno= mysqli_fetch_field($resp);
	} else {
		$retorno= mysqli_fetch_field($resp);
	  //  $retorno= mysql_fetch_field($resp); v 5.6
	}
	return $retorno;
 }
?>