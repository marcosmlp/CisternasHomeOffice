 			
									       <?php  
			$CLAUSULAWHERE=''; ?>
										   <?php
				session_start();
				$conexao='';
				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';
				?>										
											<html> 

											<!--Início dos comandos sql na tela de lista --> 

											
								<?php if ( gt("SQ_CISTERNAS_ENTIDADEMANTENEDORA_EVENTOS_LOG") <> "") {
									 
									if ( $CLAUSULAWHERE=="") {
										$CLAUSULAWHERE = " WHERE ";
									} ELSE{
										$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
									};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.SQ_CISTERNAS_ENTIDADEMANTENEDORA_EVENTOS_LOG = '".gt("SQ_CISTERNAS_ENTIDADEMANTENEDORA_EVENTOS_LOG")."' "; 
								}; ?><?php if ( gt("NO_FANTASIA") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.NO_FANTASIA = '".gt("NO_FANTASIA")."' "; 
							   }; ?><?php if ( gt("Entidademantenedora") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.Entidademantenedora = '".gt("Entidademantenedora")."' "; 
							   }; ?><?php if ( gt("NU_CNPJ") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.NU_CNPJ = '".gt("NU_CNPJ")."' "; 
							   }; ?><?php if ( gt("DE_ENDERECO") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.DE_ENDERECO = '".gt("DE_ENDERECO")."' "; 
							   }; ?><?php if ( gt("DE_UF") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.DE_UF = '".gt("DE_UF")."' "; 
							   }; ?><?php if ( gt("NU_CEP") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.NU_CEP = '".gt("NU_CEP")."' "; 
							   }; ?><?php if ( gt("DE_TELEFONE") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.DE_TELEFONE = '".gt("DE_TELEFONE")."' "; 
							   }; ?>
											 <?php 
							 if ( gt('SQ_CISTERNAS_ENTIDADEMANTENEDORA') <> '') {								    
					if ( $CLAUSULAWHERE=='') {
						$CLAUSULAWHERE = ' WHERE ';
					} ELSE{
						$CLAUSULAWHERE =  $CLAUSULAWHERE.' AND ';
					};  
						$CLAUSULAWHERE= $CLAUSULAWHERE." 
							tb1.SQ_CISTERNAS_ENTIDADEMANTENEDORA = '".gt('SQ_CISTERNAS_ENTIDADEMANTENEDORA')."' "; 
				   }; 
				      $sqlp= " SELECT tb1.SQ_EVENTOS_LOG,tb1.DESCRICAO_DO_EVENTO_EM_EVENTOS_LOG,tb1.DT_DO_EVENTO_EM_EVENTOS_LOG, tb1.SQ_CISTERNAS_ENTIDADEMANTENEDORA,tb1.NO_FANTASIA, tb1.NU_CNPJ, tb1.DE_ENDERECO,  cisternas_uf.DE_NOME as NomeVinculado_DE_UF, tb1.NU_CEP, tb1.DE_TELEFONE FROM cisternas_entidademantenedora_eventos_log tb1 
											left join cisternas_uf on cisternas_uf.SQ_CISTERNAS_UF=tb1.DE_UF ".$CLAUSULAWHERE." ";
					  $resp = mysqlexecuta($conexao,$sqlp);

				?>

											<!--Fim dos comandos sql na tela de lista --> 

											<link href='css/bootstrap.css' rel='stylesheet'><link href='_css_estiloGeral.css' rel='stylesheet'>

											<!--Início dos comandos em JavaScript na tela de lista --> 

											<!--AS JavaScript /AS-->

											<!--Fim dos comandos em JavaScript na tela de lista --> 

											<!--AS StrFormatacaoJQuery /AS-->
											<body id='idBody'>
											<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "menu.php"; 
			?> <?php  }; ?>
											<form id='formEntidademantenedora' name='formEntidademantenedora' action='Entidademantenedora_eventos_logList_banco.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'  method='POST'>
												<table class='classList'>
												
													<tr><td class='clTitulo' colspan=100%>
													<br/><br/>Entidade mantenedora
				<?php if(fnAcesso('Entidademantenedora_Edit.php')){ ?>
					<a class='linkComandos' title='Novo registro' href='Entidademantenedora_Edit.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'/><img class='clicones' style='height: 19px; width: 19px;' src='images/add.png'>Novo registro</a> 
				<?php }?>
				
													</td></tr>
													<tr><td>
														<table id='example' class='display' cellspacing='0' width='100%'>
														    <thead>
																<tr class='cltrlabelList'><th>Comandos</th>
																	 <tr class='cltrlabelList'><th>Comandos</th>
				   <th class='classLabel'>Data do evento</th>
				   <th class='classLabel'>Descrição do evento</th>
				   <th class='classLabel'>Ip identificando quem fez o evento</th>
				   
																	
						<th class='classLabel'>Nome fantasia</th>
						<th class='classLabel'>CNPJ</th>
						<th class='classLabel'>Endereço</th>
						<th class='classLabel'>UF</th>
						<th class='classLabel'>CEP</th>
						<th class='classLabel'>Telefone</th>
																	<!--fim label dos campos da lista superiores -->
																</tr>
															</thead>
														    <tfoot>
																<tr class='cltrlabelList'><th>Comandos</th>
																 <tr class='cltrlabelList'><th>Comandos</th>
				   <th class='classLabel'>Data do evento</th>
				   <th class='classLabel'>Descrição do evento</th>
				   <th class='classLabel'>Ip identificando quem fez o evento</th>
				   
																
						<th class='classLabel'>Nome fantasia</th>
						<th class='classLabel'>CNPJ</th>
						<th class='classLabel'>Endereço</th>
						<th class='classLabel'>UF</th>
						<th class='classLabel'>CEP</th>
						<th class='classLabel'>Telefone</th>
																<!--fim label dos campos da lista inferiores -->
																</tr>
															</tfoot>
															<tbody>
																<?php while ($rowp = fnmysqli_fetch_array($resp)) { ?><tr class='classTr'>
																<!--início dos campos da lista -->
																<td>
																	 
				<?php if(fnAcesso('Entidademantenedora_Details.php')){ ?>
					<a class='linkComandos' title='Detalhar registro' href='Entidademantenedora_Details.php?SQ_CISTERNAS_ENTIDADEMANTENEDORA_EVENTOS_LOG=<?php echo $rowp['SQ_CISTERNAS_ENTIDADEMANTENEDORA_EVENTOS_LOG'];?>&TelaVinculada=<?php echo gt("TelaVinculada"); ?>'/><img class='clicones' style='height: 19px; width: 19px;' src='images/details.png'></a> 
				<?php }?>				
               
																	 
				<?php if(fnAcesso('Entidademantenedora_Edit.php')){ ?>
					<a class='linkComandos' title='Alterar' href='Entidademantenedora_Edit.php?SQ_CISTERNAS_ENTIDADEMANTENEDORA_EVENTOS_LOG=<?php echo $rowp['SQ_CISTERNAS_ENTIDADEMANTENEDORA_EVENTOS_LOG'];?>&TelaVinculada=<?php echo gt("TelaVinculada"); ?>'/><img class='clicones' style='height: 19px; width: 19px;' src='images/edit.png'></a> 
				<?php }?>
				
																					
				<?php if(fnAcesso('Entidademantenedora_Delete.php')){ ?>
					<a class=linkComandos title='Excluir registro' href='Entidademantenedora_Delete.php?SQ_CISTERNAS_ENTIDADEMANTENEDORA_EVENTOS_LOG=<?php echo $rowp['SQ_CISTERNAS_ENTIDADEMANTENEDORA_EVENTOS_LOG'];?>&TelaVinculada=<?php echo gt("TelaVinculada"); ?>'/><img class='clicones' style='height: 19px; width: 19px;' src='images/delete.png'></a> 
				<?php }?>					
				
																</td>																
																														
																
				<!--início dos campos da lista após os comandos -->												
				<td class='clCampoList'><?php echo $rowp['DT_DO_EVENTO_EM_EVENTOS_LOG'];?></td>
				<td class='clCampoList'><?php echo $rowp['DESCRICAO_DO_EVENTO_EM_EVENTOS_LOG'];?></td>
				<td class='clCampoList'><?php echo $rowp['IP_DO_EVENTO_EM_EVENTOS_LOG'];?></td>
				
																	
				<td class='clCampoList'><?php echo $rowp['NO_FANTASIA'];?></td>
				<td class='clCampoList'><?php echo $rowp['NU_CNPJ'];?></td>
				<td class='clCampoList'><?php echo $rowp['DE_ENDERECO'];?></td>
				<td class='clCampoList'><?php echo $rowp['NomeVinculado_DE_UF'];?></td>
				<td class='clCampoList'><?php echo $rowp['NU_CEP'];?></td>
				<td class='clCampoList'><?php echo $rowp['DE_TELEFONE'];?></td>

																<!--fim dos campos da lista -->
																</tr><?php  }; ?>
															</tbody>
														</table>
													</td></tr>
													<tr><td>										
													
													</td></tr>
													<tr><td class=MensagemRodape colspan=100%>
														<hr/>										
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>Entidade mantenedora<?php  }; ?>
													</td></tr>
												</table>
											</form>										
											</body>
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "rodape.php"; 
			?> <?php  }; ?>	
											</html>