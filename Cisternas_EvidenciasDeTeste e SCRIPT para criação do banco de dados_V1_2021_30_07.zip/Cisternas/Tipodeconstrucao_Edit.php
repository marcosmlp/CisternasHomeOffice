  			
											<?php
				session_start();
				$conexao='';
				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';
				?>
											<html>  	

											<!--Início dos comandos em sql de para inícializar a tela de Inclusao e alteração --> 	

											<?php
				//se for alteração pega esse campo, se for vinculação também pega esse campo.			
				 $SQ_CISTERNAS_TIPODECONSTRUCAO= gt("SQ_CISTERNAS_TIPODECONSTRUCAO");				
				//se estiver dando apenas um refresh na tela, então envia esse campo informando, para não apagar os dados já preenchidos.
				$RETORNO_CAMPOS_SQ_CISTERNAS_TIPODECONSTRUCAO= gt("RETORNO_CAMPOS_SQ_CISTERNAS_TIPODECONSTRUCAO");


				//Se vier de outra página e essa só for uma página assessória, que segue um fluxo e volta para a anterior gt("TelaVinculadaRetorno") ao terminar a inclusão.
				if( gt("TelaVinculadaRetorno")<>"" ){
					//nome da página de retorno.
					$_SESSION["TelaVinculadaRetorno"]= gt("TelaVinculadaRetorno");
					//nome da página
					$TelaVinculadaRetorno=$_SESSION["TelaVinculadaRetorno"];
					//verifica se está vindo de algum lugar com dados preenchidos.
					if ($_SESSION[$TelaVinculadaRetorno]<>""){
						$_SESSION[$TelaVinculadaRetorno]="";
						$RETORNO_CAMPOS_SQ_CISTERNAS_TIPODECONSTRUCAO="PARAPREENCHERRETORNO";
					}else{
						//se não preenche os dados para retorna.
						//dados da página para retornar com tudo preenchido da página de retorno.
						$_SESSION[$TelaVinculadaRetorno]=fnTodosGtEPost(); 
					}
				}				

				// PODE SER UM RELOAD OU BACK NA PRÓPIA PÁGINA ou quando atualiza uma função java script de um select.
				if (($RETORNO_CAMPOS_SQ_CISTERNAS_TIPODECONSTRUCAO<>"") or (gt("atualizarCampos")=="sim")){
						
					$DE_NOME = gt("DE_NOME");
								$DE_DETALHADA_DA_UNIDADE = gt("DE_DETALHADA_DA_UNIDADE");
								
				} else {					
					if ($SQ_CISTERNAS_TIPODECONSTRUCAO<>""){				
						//Faz a consulta no banco de dados na tabela para retornar a lista.
						$sqlp= " select DE_NOME,DE_DETALHADA_DA_UNIDADE from cisternas_tipodeconstrucao WHERE SQ_CISTERNAS_TIPODECONSTRUCAO='".$SQ_CISTERNAS_TIPODECONSTRUCAO."'";

						$resp = mysqlexecuta($conexao,$sqlp);
						while ($rowp = fnmysqli_fetch_array($resp)) {							
							
											//buscando do campo do banco de dados DE_NOME.
											$DE_NOME = $rowp["DE_NOME"];	
											
											//buscando do campo do banco de dados DE_DETALHADA_DA_UNIDADE.
											$DE_DETALHADA_DA_UNIDADE = $rowp["DE_DETALHADA_DA_UNIDADE"];	
											
						}; 
					}else {						
						$DE_NOME = "";
									$DE_DETALHADA_DA_UNIDADE = "";
									
					}			  
					
				}
				?>
				
				

											<!--Fim dos comandos em sql de para inícializar a tela de Inclusao e alteração --> 		

											<link href='css/bootstrap.css' rel='stylesheet'><link href='_css_estiloGeral.css' rel='stylesheet'>

											<!--Início dos comandos em JavaScript na tela de Inclusao e alteração --> 

												
			<script language=javaScript> 
				function fnSubmit(IeNew){					 
						

					// Validando no javaScript o campo document.formTipodeconstrucao.DE_NOME,'O preenchimento do campo (Nome) é obrigatório.','OBRIGATÓRIO','text' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formTipodeconstrucao.DE_NOME,'O preenchimento do campo (Nome) é obrigatório.','OBRIGATÓRIO','text')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						
					//Para validar se já quer voltar para tela de inclusão novamente para preencher os dados novamente.
					document.formTipodeconstrucao.IeNew.value=IeNew;					
					document.formTipodeconstrucao.submit();
				}
				//Aqui atualiza a própria página no caso de um campo ser vinculado ao outro ai só colocar nos  parametrosAdicionais= onchange='fnAtualizarPropriaPagina();' '; do select e na clausula where do próximo campos clausulaWhere='WHERE '1'='.TP_DE_MARCACAO.' AND DE_CLINICA='._SESSION['DE_CLINICA'].'	
				function fnAtualizarPropriaPagina(){
					document.formTipodeconstrucao.action='Tipodeconstrucao_Edit.php?atualizarCampos=sim';					
					document.formTipodeconstrucao.submit();
				}
			</script> 				
			<script language=javaScript> 
				function fnValidaCampo(campo,Mensagem,TipoDeValidacao,TipoDeCampo){
					//se o usuário pediu para não mostrar esse campo então pode incluir ele vazio mesmo que esteja como obrigatório.
					if(campo==undefined){
						return true;
					}else{
						if (campo.value==0){
							fnMensagem(Mensagem);
							campo.focus();
							return false;
						}							
						return true;
					}
				}
			</script> 				
			<script language=javaScript> 	
			    function fnExcluir(LinkExclusao,MensagemPergunta){
					var retorno = confirm(MensagemPergunta);
					if (retorno){
						window.location=LinkExclusao;
						return true;
					} else {
						return false;
					}
				}
			    function fnAlterar(LinkAlteracao){
 					window.location=LinkAlteracao;
				}				
				function fnMensagem(Mensagem){
					//assim pode mudar em apenas um lugar e colocar em um div, ou no topo da página como o cliente desejar alterando só nesse arquivo.
					alert(Mensagem);
				}
	
			</script> 
					<!--AS JavaScript /AS-->

											<!--Fim dos comandos em JavaScript na tela de Inclusao e alteração -->

											<!--Início dos comandos em FormatacaoJQuery na tela de Inclusao e alteração --> 

											<script language=javaScript></script>
											
											<!--Fim dos comandos em FormatacaoJQuery na tela de Inclusao e alteração -->											

											<body id='idBody' onload="">
											<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "menu.php"; 
			?> <?php  }; ?>
											<form id='formTipodeconstrucao' name='formTipodeconstrucao' action='TipodeconstrucaoEdit_banco.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'  method='POST' >
												<table class='clDetalhesIncluir'>
													<tr><td class='clTitulo' colspan=100%>
														<br/><br/>Tipo de construção
													</td></tr>
													<tr><td>
														
										 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_TIPODECONSTRUCAO','DE_NOME')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrDE_NOME'>
									 		<td class='classTd' style='display:block' id='idclassTdDE_NOME'>
										 		<div class='classLabel' style='display:block' id='idclassLabelDE_NOME'>
														<!-- início na tela Tipodeconstrucao_Edit do label DE_NOME -->
														Nome
														<!-- fim na tela Tipodeconstrucao_Edit do label DE_NOME -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdDE_NOME'>

													<!-- início na tela Tipodeconstrucao_Edit do campo DE_NOME --> 
													
													<input class='classInput'  type='text' name='DE_NOME' 
															id='DE_NOME' 
															
															Width='-1'
															Height='-1'
															MaxLength='100'	
															Title='Nome'
															value='<?php echo $DE_NOME;?>'
															 

														
															/>
															<!-- fim na tela Tipodeconstrucao_Edit do campo DE_NOME -->															
													</span>
												</td>
											</tr>
									<tr  class='classTr'>
										<td class='classTd'>
											<div class='classLabel'>Descrição detalhada da unidade</div>
											<div  class='classCampo'>	<script type='text/javascript'>
												window.onload = function()  {
												CKEDITOR.replace('DE_DETALHADA_DA_UNIDADE');
												};
												</script> 
												
														<textarea 
														name='DE_DETALHADA_DA_UNIDADE'
														class='classInput'
														
														id='DE_DETALHADA_DA_UNIDADE'
														Title='<'
														cols=''
														rows=''
														MaxLength='1200'><?php echo urldecode($DE_DETALHADA_DA_UNIDADE);?></textarea>	
											</div>
										</td>
									</tr><input 	
								type='hidden' 
								name='SQ_CISTERNAS_TIPODECONSTRUCAO' 
								id='SQ_CISTERNAS_TIPODECONSTRUCAO' 
								value='<?php echo $SQ_CISTERNAS_TIPODECONSTRUCAO; ?>'> <?php $_SESSION['RETORNO_Tipodeconstrucao_Edit']=fnTodosGtEPost(); ?>
													</td></tr>
													<tr><td>										
														
				<tr class='classTrButton'>		
					<td colspan=100% class='classtdButton'>
						<!--  Edit início do botão de envio -->
						<input class='btn btn-primary btn-sm mt-1' 	
								type='button' 
								<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_TIPODECONSTRUCAO','btSubmit')){ echo '';} else { echo 'style="display:none"';}; ?>
								name='btSubmit' 
								title='Envia e aparece a tela de confirmação, inclusão de um único registro.'
								id='btSubmit'
								onClick='fnSubmit("N");'
								value='Enviar'	 											
								>	
								&nbsp;&nbsp;&nbsp;&nbsp;
						<!-- Edit fim do botão de envio  -->	
						<!-- Edit início do botão de envio e Novo  -->													
						<input class='btn btn-primary btn-sm mt-1' 
						       <?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_TIPODECONSTRUCAO','btSubmitEnviarENovo')){ echo '';} else { echo 'style="display:none"';}; ?>	
								type='button' 
								title='Envia e já volta para essa tela só com os campos que normalmente já são preenchidos repetidos para efetuar um novo cadastro.'
								name='btSubmitEnviarENovo' 
								id='btSubmitEnviarENovo'
								onClick='fnSubmit("S");'
								value='Enviar e Novo'	 											
								>	
								<input type=hidden value='N' id='IeNew' name='IeNew'/>
								 &nbsp;&nbsp;&nbsp;&nbsp;
						<!-- Edit fim do botão de envio e Novo -->	
						<!-- Edit início do botão de voltar -->															 
						 <input class='btn btn-primary btn-sm mt-1'  	
						 <?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_TIPODECONSTRUCAO','btVoltar')){ echo '';} else { echo 'style="display:none"';}; ?>
								type='button' 
								title='Volta a tela anterior.'
								name='btVoltar' 
								onClick='history.go(-1);'
								id='btVoltar' 
								value='Voltar'	 											
								>
						<!-- Edit fim do botão de voltar -->
						<!-- Edit início do botão de upload -->									
								<a  <?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_TIPODECONSTRUCAO','btUploadVariosArquivos')){ echo '';} else { echo 'style="display:none"';}; ?>  href=# onClick='fnUploadArquivoParaBase("cisternas_tipodeconstrucao","#DE_NOME#,#DE_DETALHADA_DA_UNIDADE#","#DE_NOME# ,#DE_DETALHADA_DA_UNIDADE# ");'	>							
								<img src='images/upload.png' class='imgupload' title="Para subir arquivos um arquivo com vários registros é necessário deixar ele no formato que separe os campos por virgula. Não é necessário enviar cabeçalho, só precisa enviar a quantidade de títulos iguais ao dessa tela de inclusão e na mesma ordem dessa tela de inclusão, segue a orderm: ('Nome','Descrição detalhada da unidade')" >
								</a>
						<!-- Edit fim do botão de upload -->	
								
					</td>
				</tr>
													</td></tr>
													<tr><td colspan=100% >										
																												
													</td></tr>													
													<tr><td colspan=100% >										
																												
													</td></tr>
													<tr><td class='MensagemRodape' colspan=100%>
													<hr/>											
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>Tipo de construção<?php  }; ?>
													</td></tr>
												</table>
											</form>												
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "rodape.php"; 
			?> <?php  }; ?>											
											<form name='frmArquivo' action='uploadArquivoPg.php'>
												<input type=hidden value='' name='tabelaGravar'>
												<input type=hidden value='' name='strCabecalhoRegras'>
												<input type=hidden value='' name='strCabecalho'>
											</form>
											</body>
											</html>