 			
									       <?php  
			$CLAUSULAWHERE=''; ?>
										   <?php
				session_start();
				$conexao='';
				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';
				?>										
											<html> 

											<!--Início dos comandos sql na tela de lista --> 

											
								<?php if ( gt("SQ_CISTERNAS_CADASTRO") <> "") {
									 
									if ( $CLAUSULAWHERE=="") {
										$CLAUSULAWHERE = " WHERE ";
									} ELSE{
										$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
									};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.SQ_CISTERNAS_CADASTRO = '".gt("SQ_CISTERNAS_CADASTRO")."' "; 
								}; ?><?php if ( gt("Cadastro") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.Cadastro = '".gt("Cadastro")."' "; 
							   }; ?><?php if ( gt("DT_DA_INAUGURACAO") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.DT_DA_INAUGURACAO = '".gt("DT_DA_INAUGURACAO")."' "; 
							   }; ?><?php if ( gt("TP_DE_CONSTRUCAO") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.TP_DE_CONSTRUCAO = '".gt("TP_DE_CONSTRUCAO")."' "; 
							   }; ?><?php if ( gt("DE_DOS_MATERIAIS") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.DE_DOS_MATERIAIS = '".gt("DE_DOS_MATERIAIS")."' "; 
							   }; ?><?php if ( gt("DE_ENTIDADE_MANTENEDORA") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.DE_ENTIDADE_MANTENEDORA = '".gt("DE_ENTIDADE_MANTENEDORA")."' "; 
							   }; ?><?php if ( gt("DE_LOCALIZACAO") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.DE_LOCALIZACAO = '".gt("DE_LOCALIZACAO")."' "; 
							   }; ?><?php if ( gt("DE_UF") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.DE_UF = '".gt("DE_UF")."' "; 
							   }; ?><?php if ( gt("DE_ENDERECO") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.DE_ENDERECO = '".gt("DE_ENDERECO")."' "; 
							   }; ?>
											 <?php 
				//Faz a consulta no banco de dados na tabela para retornar a lista geral
				      $sqlp= " SELECT tb1.SQ_CISTERNAS_CADASTRO,tb1.DT_DA_INAUGURACAO,  cisternas_tipodeconstrucao.DE_NOME as NomeVinculado_TP_DE_CONSTRUCAO, tb1.DE_DOS_MATERIAIS,    CONCAT(cisternas_entidademantenedora.NU_CNPJ,'-', cisternas_entidademantenedora.NO_FANTASIA) as NomeVinculado_DE_ENTIDADE_MANTENEDORA, tb1.DE_LOCALIZACAO,  cisternas_uf.DE_NOME as NomeVinculado_DE_UF, tb1.DE_ENDERECO FROM cisternas_cadastro tb1 
											left join cisternas_tipodeconstrucao on cisternas_tipodeconstrucao.SQ_CISTERNAS_TIPODECONSTRUCAO=tb1.TP_DE_CONSTRUCAO
											left join cisternas_entidademantenedora on cisternas_entidademantenedora.SQ_CISTERNAS_ENTIDADEMANTENEDORA=tb1.DE_ENTIDADE_MANTENEDORA
											left join cisternas_uf on cisternas_uf.SQ_CISTERNAS_UF=tb1.DE_UF ".$CLAUSULAWHERE." ";
					  $resp = mysqlexecuta($conexao,$sqlp);

				?>

											<!--Fim dos comandos sql na tela de lista --> 

											<link href='css/bootstrap.css' rel='stylesheet'><link href='_css_estiloGeral.css' rel='stylesheet'>

											<!--Início dos comandos em JavaScript na tela de lista --> 

											<!--AS JavaScript /AS-->

											<!--Fim dos comandos em JavaScript na tela de lista --> 

											<!--AS StrFormatacaoJQuery /AS-->
											<body id='idBody'>
											<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "menu.php"; 
			?> <?php  }; ?>
											<form id='formCadastro' name='formCadastro' action='CadastroList_banco.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'  method='POST'>
												<table class='classList'>
												
													<tr><td class='clTitulo' colspan=100%>
													<br/><br/>Cadastro
				<?php if(fnAcesso('Cadastro_Edit.php')){ ?>
					<a class='linkComandos' title='Novo registro' href='Cadastro_Edit.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'/><img class='clicones' style='height: 19px; width: 19px;' src='images/add.png'>Novo registro</a> 
				<?php }?>
				
													</td></tr>
													<tr><td>
														<table id='example' class='display' cellspacing='0' width='100%'>
														    <thead>
																<tr class='cltrlabelList'><th>Comandos</th>
																	<!--início label dos campos da lista superiores -->
																	
						<th class='classLabel'>Data da inauguração</th>
						<th class='classLabel'>Tipo de construção</th>
						<th class='classLabel'>Descrição dos materiais</th>
						<th class='classLabel'>Entidade mantenedora</th>
						<th class='classLabel'>Localização GPS</th>
						<th class='classLabel'>UF</th>
						<th class='classLabel'>Endereço</th>
																	<!--fim label dos campos da lista superiores -->
																</tr>
															</thead>
														    <tfoot>
																<tr class='cltrlabelList'><th>Comandos</th>
																<!--início label dos campos da lista inferiores -->
																
						<th class='classLabel'>Data da inauguração</th>
						<th class='classLabel'>Tipo de construção</th>
						<th class='classLabel'>Descrição dos materiais</th>
						<th class='classLabel'>Entidade mantenedora</th>
						<th class='classLabel'>Localização GPS</th>
						<th class='classLabel'>UF</th>
						<th class='classLabel'>Endereço</th>
																<!--fim label dos campos da lista inferiores -->
																</tr>
															</tfoot>
															<tbody>
																<?php while ($rowp = fnmysqli_fetch_array($resp)) { ?><tr class='classTr'>
																<!--início dos campos da lista -->
																<td>
																	 
				<?php if(fnAcesso('Cadastro_Details.php')){ ?>
					<a class='linkComandos' title='Detalhar registro' href='Cadastro_Details.php?SQ_CISTERNAS_CADASTRO=<?php echo $rowp['SQ_CISTERNAS_CADASTRO'];?>&TelaVinculada=<?php echo gt("TelaVinculada"); ?>'/><img class='clicones' style='height: 19px; width: 19px;' src='images/details.png'></a> 
				<?php }?>				
               
																	 
				<?php if(fnAcesso('Cadastro_Edit.php')){ ?>
					<a class='linkComandos' title='Alterar' href='Cadastro_Edit.php?SQ_CISTERNAS_CADASTRO=<?php echo $rowp['SQ_CISTERNAS_CADASTRO'];?>&TelaVinculada=<?php echo gt("TelaVinculada"); ?>'/><img class='clicones' style='height: 19px; width: 19px;' src='images/edit.png'></a> 
				<?php }?>
				
																					
				<?php if(fnAcesso('Cadastro_Delete.php')){ ?>
					<a class=linkComandos title='Excluir registro' href='Cadastro_Delete.php?SQ_CISTERNAS_CADASTRO=<?php echo $rowp['SQ_CISTERNAS_CADASTRO'];?>&TelaVinculada=<?php echo gt("TelaVinculada"); ?>'/><img class='clicones' style='height: 19px; width: 19px;' src='images/delete.png'></a> 
				<?php }?>					
				
																</td>																
																<!--início dos campos da lista após os comandos -->
																	
				<td class='clCampoList'><?php echo fnFormataDtBdParaTela($rowp['DT_DA_INAUGURACAO']);?></td>
				<td class='clCampoList'><?php echo $rowp['NomeVinculado_TP_DE_CONSTRUCAO'];?></td>
				<td class='clCampoList'><?php echo fnDecode($rowp['DE_DOS_MATERIAIS']);?></td>
				<td class='clCampoList'><?php echo $rowp['NomeVinculado_DE_ENTIDADE_MANTENEDORA'];?></td>
				<td class='clCampoList'><?php echo $rowp['DE_LOCALIZACAO'];?></td>
				<td class='clCampoList'><?php echo $rowp['NomeVinculado_DE_UF'];?></td>
				<td class='clCampoList'><?php echo $rowp['DE_ENDERECO'];?></td>

																<!--fim dos campos da lista -->
																</tr><?php  }; ?>
															</tbody>
														</table>
													</td></tr>
													<tr><td>										
													
													</td></tr>
													<tr><td class=MensagemRodape colspan=100%>
														<hr/>										
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>Cadastro<?php  }; ?>
													</td></tr>
												</table>
											</form>										
											</body>
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "rodape.php"; 
			?> <?php  }; ?>	
											</html>