 			
											<?php
				session_start();
				$conexao='';
				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';
				?>
											<html> 

											<!--Início dos comandos sql na tela de detalhes --> 

											
											<?php					
					if (gt("SQ_CISTERNAS_ENTIDADEMANTENEDORA")<>""){				
						//Faz a consulta no banco de dados na tabela para retornar a lista.
						$sqlp= "  SELECT tb1.SQ_CISTERNAS_ENTIDADEMANTENEDORA,tb1.NO_FANTASIA, tb1.NO_FANTASIA, tb1.NU_CNPJ, tb1.DE_ENDERECO,  cisternas_uf.DE_NOME as NomeVinculado_DE_UF, tb1.NU_CEP, tb1.DE_TELEFONE FROM cisternas_entidademantenedora tb1 
												left join cisternas_uf on cisternas_uf.SQ_CISTERNAS_UF=tb1.DE_UF ".$CLAUSULAWHERE."  WHERE SQ_CISTERNAS_ENTIDADEMANTENEDORA='".gt("SQ_CISTERNAS_ENTIDADEMANTENEDORA")."'";

						$resp = mysqlexecuta($conexao,$sqlp);
	 
					}
				?>

											<!--Fim dos comandos sql na tela de detalhes --> 

											<link href='css/bootstrap.css' rel='stylesheet'><link href='_css_estiloGeral.css' rel='stylesheet'>

											<!--Início dos comandos em JavaScript na tela de detalhes --> 

											<!--AS JavaScript /AS-->

											<!--Fim dos comandos em JavaScript na tela de detalhes --> 

											<!--AS StrFormatacaoJQuery /AS-->
											<body id='idBody'>
											<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "menu.php"; 
			?> <?php  }; ?>
											<form id='formEntidademantenedora' name='formEntidademantenedora' action='EntidademantenedoraDetails_banco.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'  method='POST'>
												<table class='clDetalhes'>
													<tr><td class='clTitulo' colspan=100%>
													<br/><br/>Entidade mantenedora
													</td></tr>
													<tr><td>
														<table>
															
															<?php while ($rowp = fnmysqli_fetch_array($resp)) { ?><tr class='classTr'>
															
																
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label NO_FANTASIA -->
					Nome fantasia
					<!-- fim na tela Details do label NO_FANTASIA -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo NO_FANTASIA -->
					<?php echo $rowp['NO_FANTASIA'];?>
					<!-- fim na tela Details do campo NO_FANTASIA -->
				</td>
				</tr>
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label NU_CNPJ -->
					CNPJ
					<!-- fim na tela Details do label NU_CNPJ -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo NU_CNPJ -->
					<?php echo $rowp['NU_CNPJ'];?>
					<!-- fim na tela Details do campo NU_CNPJ -->
				</td>
				</tr>
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label DE_ENDERECO -->
					Endereço
					<!-- fim na tela Details do label DE_ENDERECO -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo DE_ENDERECO -->
					<?php echo $rowp['DE_ENDERECO'];?>
					<!-- fim na tela Details do campo DE_ENDERECO -->
				</td>
				</tr>
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label NomeVinculado_DE_UF -->
					UF
					<!-- fim na tela Details do label NomeVinculado_DE_UF -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo NomeVinculado_DE_UF -->
					<?php echo $rowp['NomeVinculado_DE_UF'];?>
					<!-- fim na tela Details do campo NomeVinculado_DE_UF -->
				</td>
				</tr>
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label NU_CEP -->
					CEP
					<!-- fim na tela Details do label NU_CEP -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo NU_CEP -->
					<?php echo $rowp['NU_CEP'];?>
					<!-- fim na tela Details do campo NU_CEP -->
				</td>
				</tr>
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label DE_TELEFONE -->
					Telefone
					<!-- fim na tela Details do label DE_TELEFONE -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo DE_TELEFONE -->
					<?php echo $rowp['DE_TELEFONE'];?>
					<!-- fim na tela Details do campo DE_TELEFONE -->
				</td>
				</tr>
																
															
														</table>
													</td></tr>
													<tr><td>	

													<!--Início dos botoes na tela detalhes -->

													<?php 
			   //início verificar se tem acesso aos eventos.
			   if(fnAcesso('Entidademantenedora_eventos_log_List.php')){ ?>
				<input type='button' name='idVerEventos' style='display:block' class='btn btn-primary btn-sm mt-1' title='Ver todos os eventos e datas que foram feitos.' id='idVerEventos' value='Ver todos eventos' onClick='window.location="Entidademantenedora_eventos_log_List.php?SQ_CISTERNAS_ENTIDADEMANTENEDORA=<?php echo $rowp['SQ_CISTERNAS_ENTIDADEMANTENEDORA']; ?>";'/>
				<?php } 
				//fim verificar se tem acesso aos eventos. 
				?> 													
													
													<!--Fim dos botoes na tela detalhes -->

													</td></tr>
													<tr><td class=MensagemRodape colspan=100%>
													<hr/>
														
													<!--Início MensagemRodape na tela detalhes -->	

													<?php if (gt("TelaVinculada")<>"SIM"){ ?>Entidade mantenedora<?php  }; ?>

													<!--Fim MensagemRodape na tela detalhes -->

													</td></tr>
												</table>
											</form>										
											</body>
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "rodape.php"; 
			?> <?php  }; ?>	
											<?php  }; //fim do while ?>
											</html>