 			
									       <?php  
			$CLAUSULAWHERE=''; ?>
										   <?php
				session_start();
				$conexao='';
				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';
				?>										
											<html> 

											<!--Início dos comandos sql na tela de lista --> 

											
								<?php if ( gt("SQ_CISTERNAS_TIPODECONSTRUCAO") <> "") {
									 
									if ( $CLAUSULAWHERE=="") {
										$CLAUSULAWHERE = " WHERE ";
									} ELSE{
										$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
									};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.SQ_CISTERNAS_TIPODECONSTRUCAO = '".gt("SQ_CISTERNAS_TIPODECONSTRUCAO")."' "; 
								}; ?><?php if ( gt("DE_NOME") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.DE_NOME = '".gt("DE_NOME")."' "; 
							   }; ?><?php if ( gt("Tipodeconstrucao") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.Tipodeconstrucao = '".gt("Tipodeconstrucao")."' "; 
							   }; ?><?php if ( gt("DE_DETALHADA_DA_UNIDADE") <> "") {
								    
							    if ( $CLAUSULAWHERE=="") {
									$CLAUSULAWHERE = " WHERE ";
								} ELSE{
									$CLAUSULAWHERE =  $CLAUSULAWHERE." AND ";
								};  
									$CLAUSULAWHERE= $CLAUSULAWHERE." 
										tb1.DE_DETALHADA_DA_UNIDADE = '".gt("DE_DETALHADA_DA_UNIDADE")."' "; 
							   }; ?>
											 <?php 
				//Faz a consulta no banco de dados na tabela para retornar a lista geral
				      $sqlp= " SELECT tb1.SQ_CISTERNAS_TIPODECONSTRUCAO,tb1.DE_NOME, tb1.DE_DETALHADA_DA_UNIDADE FROM cisternas_tipodeconstrucao tb1  ".$CLAUSULAWHERE." ";
					  $resp = mysqlexecuta($conexao,$sqlp);

				?>

											<!--Fim dos comandos sql na tela de lista --> 

											<link href='css/bootstrap.css' rel='stylesheet'><link href='_css_estiloGeral.css' rel='stylesheet'>

											<!--Início dos comandos em JavaScript na tela de lista --> 

											<!--AS JavaScript /AS-->

											<!--Fim dos comandos em JavaScript na tela de lista --> 

											<!--AS StrFormatacaoJQuery /AS-->
											<body id='idBody'>
											<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "menu.php"; 
			?> <?php  }; ?>
											<form id='formTipodeconstrucao' name='formTipodeconstrucao' action='TipodeconstrucaoList_banco.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'  method='POST'>
												<table class='classList'>
												
													<tr><td class='clTitulo' colspan=100%>
													<br/><br/>Tipo de construção
				<?php if(fnAcesso('Tipodeconstrucao_Edit.php')){ ?>
					<a class='linkComandos' title='Novo registro' href='Tipodeconstrucao_Edit.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'/><img class='clicones' style='height: 19px; width: 19px;' src='images/add.png'>Novo registro</a> 
				<?php }?>
				
													</td></tr>
													<tr><td>
														<table id='example' class='display' cellspacing='0' width='100%'>
														    <thead>
																<tr class='cltrlabelList'><th>Comandos</th>
																	<!--início label dos campos da lista superiores -->
																	
						<th class='classLabel'>Nome</th>
						<th class='classLabel'>Descrição detalhada da unidade</th>
																	<!--fim label dos campos da lista superiores -->
																</tr>
															</thead>
														    <tfoot>
																<tr class='cltrlabelList'><th>Comandos</th>
																<!--início label dos campos da lista inferiores -->
																
						<th class='classLabel'>Nome</th>
						<th class='classLabel'>Descrição detalhada da unidade</th>
																<!--fim label dos campos da lista inferiores -->
																</tr>
															</tfoot>
															<tbody>
																<?php while ($rowp = fnmysqli_fetch_array($resp)) { ?><tr class='classTr'>
																<!--início dos campos da lista -->
																<td>
																	 
				<?php if(fnAcesso('Tipodeconstrucao_Details.php')){ ?>
					<a class='linkComandos' title='Detalhar registro' href='Tipodeconstrucao_Details.php?SQ_CISTERNAS_TIPODECONSTRUCAO=<?php echo $rowp['SQ_CISTERNAS_TIPODECONSTRUCAO'];?>&TelaVinculada=<?php echo gt("TelaVinculada"); ?>'/><img class='clicones' style='height: 19px; width: 19px;' src='images/details.png'></a> 
				<?php }?>				
               
																	 
				<?php if(fnAcesso('Tipodeconstrucao_Edit.php')){ ?>
					<a class='linkComandos' title='Alterar' href='Tipodeconstrucao_Edit.php?SQ_CISTERNAS_TIPODECONSTRUCAO=<?php echo $rowp['SQ_CISTERNAS_TIPODECONSTRUCAO'];?>&TelaVinculada=<?php echo gt("TelaVinculada"); ?>'/><img class='clicones' style='height: 19px; width: 19px;' src='images/edit.png'></a> 
				<?php }?>
				
																					
				<?php if(fnAcesso('Tipodeconstrucao_Delete.php')){ ?>
					<a class=linkComandos title='Excluir registro' href='Tipodeconstrucao_Delete.php?SQ_CISTERNAS_TIPODECONSTRUCAO=<?php echo $rowp['SQ_CISTERNAS_TIPODECONSTRUCAO'];?>&TelaVinculada=<?php echo gt("TelaVinculada"); ?>'/><img class='clicones' style='height: 19px; width: 19px;' src='images/delete.png'></a> 
				<?php }?>					
				
																</td>																
																<!--início dos campos da lista após os comandos -->
																	
				<td class='clCampoList'><?php echo $rowp['DE_NOME'];?></td>
				<td class='clCampoList'><?php echo fnDecode($rowp['DE_DETALHADA_DA_UNIDADE']);?></td>

																<!--fim dos campos da lista -->
																</tr><?php  }; ?>
															</tbody>
														</table>
													</td></tr>
													<tr><td>										
													
													</td></tr>
													<tr><td class=MensagemRodape colspan=100%>
														<hr/>										
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>Tipo de construção<?php  }; ?>
													</td></tr>
												</table>
											</form>										
											</body>
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "rodape.php"; 
			?> <?php  }; ?>	
											</html>