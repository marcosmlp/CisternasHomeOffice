<?php
			session_start();

				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';

				
				//if($_SESSION['sessionConversacao']==""){
				$txChat=gt("txChat");	
					?>
<!DOCTYPE html>
<style>
    @media only screen and (max-width: 1400px) {
    .mobile-hide{ display: none !important; }
    /*inline */
    }

</style>
<!-- saved from url=(0049)https://coderthemes.com/hyper/saas/apps-chat.html -->
<html lang="en" class="mm-active"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        
        <title>Cadastro</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description">
        <meta content="Coderthemes" name="author">
        <!-- App favicon -->
        <link rel="shortcut icon" href="https://coderthemes.com/hyper/saas/assets/images/favicon.ico">

         App css 
        <link href="./layoutHipper/icons.min.css" rel="stylesheet" type="text/css">
        <link href="./layoutHipper/app.min.css" rel="stylesheet" type="text/css" id="light-style">
        <link href="./layoutHipper/app-dark.min.css" rel="stylesheet" type="text/css" id="dark-style" disabled="disabled">








		
    </head>
<script>
function fnMostrarMenu(idMenuAgenda){
    
    if(document.getElementById(idMenuAgenda).style.display!="none"){
        document.getElementById(idMenuAgenda).style.display="none";        


    } else{

        document.getElementById(idMenuAgenda).style.display="block";
    }
    

}

</script>
    <body id="bodyid" class="mm-show" data-layout-config="{&quot;leftSideBarTheme&quot;:&quot;dark&quot;,&quot;layoutBoxed&quot;:false, &quot;leftSidebarCondensed&quot;:false, 
    &quot;leftSidebarScrollable&quot;:false,&quot;darkMode&quot;:false, &quot;showRightSidebarOnStart&quot;: true}" data-leftbar-theme="dark">
        <!-- Begin page -->
        <div class="wrapper mm-active">
            <!-- ========== Left Sidebar Start ========== -->
            <div class="left-side-menu mm-show">
				
                <!-- LOGO -->
                <a href="" class="logo text-center logo-light">
                    <span class="logo-lg">
                        <img src="./layoutHipper/logo.png" alt="" height="26">
                    </span>
                    <span class="logo-sm">
                        <img src="./layoutHipper/logo_sm.png" alt="" height="26">
                    </span>
                </a>

                <!-- LOGO -->
                <a href="" class="logo text-center logo-dark">
                    <span class="logo-lg">
                        <img src="./layoutHipper/logo-dark.png" alt="" height="26">
                    </span>
                    <span class="logo-sm">
                        <img src="./layoutHipper/logo_sm_dark.png" alt="" height="26">
                    </span>
                </a>
    
                <div class="h-100 mm-active" id="left-side-menu-container" data-simplebar="init"><div class="simplebar-wrapper" style="margin: 0px;"><div class="simplebar-height-auto-observer-wrapper"><div class="simplebar-height-auto-observer"></div></div><div class="simplebar-mask"><div class="simplebar-offset" style="right: 0px; bottom: 0px;"><div class="simplebar-content-wrapper" style="height: 100%; overflow: auto;"><div class="simplebar-content" style="padding: 0px;">

                    <!--- Sidemenu -->
                    <ul class="metismenu side-nav mm-show">

                        <li class="side-nav-title side-nav-item">Navigation</li>
                                                 
                        <li class="side-nav-item">
                            <a onClick="fnMostrarMenu('idMenuCadastro');" class="side-nav-link"  >
                                <img src="./layoutHipper/casa.png" class="uil-document-layout-center-casa uil-document-layout-center">&nbsp;&nbsp;&nbsp;
                                <span> Cadastros </span>
                               <!-- <img src="./layoutHipper/setaEsquerda.png" class="menu-arrow"></img>-->
                            </a>
                          <ul class="side-nav-second-level " aria-expanded="false" id=idMenuCadastro  style="display:block">
								<!--AS Menu_Inicio /AS--> 
	

					
								
					<?php if(fnAcesso('UF_List.php')){ ?>
					<li><a title='UF' href='UF_List.php'>UF</a></li>
					<?php }?>
					
					<?php if(fnAcesso('Entidademantenedora_List.php')){ ?>
					<li><a title='Entidade mantenedora' href='Entidademantenedora_List.php'>Entidade mantenedora</a></li>
					<?php }?>
					
					<?php if(fnAcesso('Cadastro_List.php')){ ?>
					<li><a title='Cadastro' href='Cadastro_List.php'>Cadastro</a></li>
					<?php }?>
					
					<?php if(fnAcesso('Tipodeconstrucao_List.php')){ ?>
					<li><a title='Tipo de construção' href='Tipodeconstrucao_List.php'>Tipo de construção</a></li>
					<?php }?>
					<!--AS Menu /AS-->		
														
				
                            </ul>
						</li>  
								



                    </ul>

                    <!-- Help Box -->

                    <!-- end Help Box -->
                    <!-- End Sidebar -->

                    <div class="clearfix"></div>

                </div></div></div></div><div class="simplebar-placeholder" style="width: auto; height: 1422px;"></div></div><div class="simplebar-track simplebar-horizontal" style="visibility: hidden;"><div class="simplebar-scrollbar" style="width: 0px; display: none;"></div></div><div class="simplebar-track simplebar-vertical" style="visibility: visible;"><div class="simplebar-scrollbar" style="height: 470px; transform: translate3d(0px, 0px, 0px); display: block;"></div></div></div>
                <!-- Sidebar -left -->

            </div>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    <!-- Topbar Start -->
                    <div class="navbar-custom">
                        <ul class="list-unstyled topbar-right-menu float-right mb-0">
                            <li class="dropdown notification-list d-lg-none">
                                <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown" href="https://coderthemes.com/hyper/saas/apps-chat.html#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <i class="dripicons-search noti-icon"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-animated dropdown-lg p-0">
                                    <form class="p-3">
                                        <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient&#39;s username">
                                    </form>
                                </div>
                            </li>
                            <li class="dropdown notification-list topbar-dropdown">
                                <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown" href="https://coderthemes.com/hyper/saas/apps-chat.html#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <img src="./layoutHipper/Brazil.jpg" alt="user-image" class="mr-0 mr-sm-1" height="12"> 
                                    <span class="align-middle d-none d-sm-inline-block">Português</span> 
									 <img src="./layoutHipper/setaclarapais.png" class="mdi mdi-chevron-down d-none d-sm-inline-block align-middle"> 
                                </a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated topbar-dropdown-menu">

                                    <!-- item-->
                                    <a href="javascript:void(0);" class="dropdown-item notify-item">
                                        <img src="./layoutHipper/germany.jpg" alt="user-image" class="mr-1" height="12"> <span class="align-middle">German</span>
                                    </a>
									
                                    <a href="javascript:void(0);" class="dropdown-item notify-item">
                                        <img src="./layoutHipper//us.jpg" alt="user-image" class="mr-1" height="12"> <span class="align-middle">English</span>
                                    </a>
									
                                    <!-- item-->
                                    <a href="javascript:void(0);" class="dropdown-item notify-item">
                                        <img src="./layoutHipper/italy.jpg" alt="user-image" class="mr-1" height="12"> <span class="align-middle">Italian</span>
                                    </a>
                
                                    <!-- item-->
                                    <a href="javascript:void(0);" class="dropdown-item notify-item">
                                        <img src="./layoutHipper/spain.jpg" alt="user-image" class="mr-1" height="12"> <span class="align-middle">Spanish</span>
                                    </a>

                                    <!-- item-->
                                    <a href="javascript:void(0);" class="dropdown-item notify-item">
                                        <img src="./layoutHipper/russia.jpg" alt="user-image" class="mr-1" height="12"> <span class="align-middle">Russian</span>
                                    </a>

                                </div>
                            </li>

                            <li class="dropdown notification-list">
                                <a class="nav-link dropdown-toggle arrow-none" data-toggle="dropdown"role="button" aria-haspopup="false" aria-expanded="false">

									 <img src="./layoutHipper/sino.png" class="dripicons-bell noti-icon">

                                   
                                </a>
                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-animated dropdown-lg" style="">

                                    <!-- item-->
                                    <div class="dropdown-item noti-title">
                                        <h5 class="m-0">
                                            <span class="float-right">
                                                <a href="javascript: void(0);" class="text-dark">
                                                    <small>Clear All</small>
                                                </a>
                                            </span>Notification
                                        </h5>
                                    </div>

                                    <div style="max-height: 230px;" data-simplebar="init"><div class="simplebar-wrapper" style="margin: 0px;"><div class="simplebar-height-auto-observer-wrapper"><div class="simplebar-height-auto-observer"></div></div><div class="simplebar-mask"><div class="simplebar-offset" style="right: 0px; bottom: 0px;"><div class="simplebar-content-wrapper" style="height: auto; overflow: auto;"><div class="simplebar-content" style="padding: 0px;">
                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-primary">
                                                <i class="mdi mdi-comment-account-outline"></i>
                                            </div>
                                            <p class="notify-details">Caleb Flakelar commented on Admin
                                                <small class="text-muted">1 min ago</small>
                                            </p>
                                        </a>

                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-info">
                                                <i class="mdi mdi-account-plus"></i>
                                            </div>
                                            <p class="notify-details">New user registered.
                                                <small class="text-muted">5 hours ago</small>
                                            </p>
                                        </a>

                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon">
                                                <img src="./layoutHipper/avatar-2.jpg" class="img-fluid rounded-circle" alt=""> </div>
                                            <p class="notify-details">Cristina Pride</p>
                                            <p class="text-muted mb-0 user-msg">
                                                <small>Hi, How are you? What about our next meeting</small>
                                            </p>
                                        </a>

                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-primary">
                                                <i class="mdi mdi-comment-account-outline"></i>
                                            </div>
                                            <p class="notify-details">Caleb Flakelar commented on Admin
                                                <small class="text-muted">4 days ago</small>
                                            </p>
                                        </a>

                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon">
                                                <img src="./layoutHipper/avatar-4.jpg" class="img-fluid rounded-circle" alt=""> </div>
                                            <p class="notify-details">Karen Robinson</p>
                                            <p class="text-muted mb-0 user-msg">
                                                <small>Wow ! this admin looks good and awesome design</small>
                                            </p>
                                        </a>

                                        <!-- item-->
                                        <a href="javascript:void(0);" class="dropdown-item notify-item">
                                            <div class="notify-icon bg-info">
                                                <i class="mdi mdi-heart"></i>
                                            </div>
                                            <p class="notify-details">Carlos Crouch liked
                                                <b>Admin</b>
                                                <small class="text-muted">13 days ago</small>
                                            </p>
                                        </a>
                                    </div></div></div></div><div class="simplebar-placeholder" style="width: 0px; height: 0px;"></div></div><div class="simplebar-track simplebar-horizontal" style="visibility: hidden;"><div class="simplebar-scrollbar" style="width: 0px; display: none;"></div></div><div class="simplebar-track simplebar-vertical" style="visibility: hidden;"><div class="simplebar-scrollbar" style="height: 0px; display: none; transform: translate3d(0px, 0px, 0px);"></div></div></div>

                                    <!-- All-->
                                    <a href="javascript:void(0);" class="dropdown-item text-center text-primary notify-item notify-all">
                                        View All
                                    </a>

                                </div>
                            </li>



                            <li class="notification-list">
                                <a class="nav-link right-bar-toggle" href="javascript: void(0);">
                                    <img src="./layoutHipper/configuracao.png" class="dripicons-gear noti-icon">
                                </a>
                            </li>


                        </ul>
 
                    </div>
                    <!-- end Topbar -->

                    <!-- Start Content-->
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Cadastro</a></li>
                                            <li class="breadcrumb-item active">Cadastro</li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Cadastro</h4>
                                </div>
                            </div>
                        </div>
                        <!-- end page title -->


									
							
							
							
							
                        <?php					
							
                            $mystring = strtolower($_SERVER["REQUEST_URI"]);
                    
                            if (strpos(strtoupper($mystring),strtoupper('_List.php'))>-1 )		
                            {
                                //echo '	                        <div class="row" style="overflow:auto; "  >';
                                ?>
                            
                                <div  style="border-radius: 10px;height:721; overflow:auto" id="idtamanhodaPaginaRolagem" >
                        
                                                            <ul id="idtamanhodaPagina"  style="height:999;">	
                    
                                                            <div  style="overflow:visible;" style="padding: 0px;">	
                                                            <div class="menupontinhoflutuante" id="idNavCustom" onClick="fnMostrarMenu('left-side-menu');" style="display:non">														
                                                                            <a  style="float:right;" >
                                                                                            <img src="layoutHipper\pontinhos.jpeg" id="idImgPontinhos" class="idImgPontinhos"  style="width: 60px;heigth:60px;z-index:99999!important">
                                                                                        </a>
                                                        
                                                            </div>
                                                                            <!-- start page title -->
                                                                            <div class="row">
                            
                                                                                    <div class="page-title-box">
                                                                                        <h4 class="page-title">                                        
                    
                                                                                        &nbsp;
                                                                                    </div></br>
                                                                                
                                                                            </div>
                                                                            <!-- end page title -->											
                            <?php
                            } else {
                            ?>	
                                                <div class="row"  > 
                                                <!-- start container digitação -->	
                                                
                    
                                                <!-- form area geral -->
                    
                                                    <div class="card"  style="border-radius: 10px;">
                                                        <div class="card-body"  style=" border-radius: 10px;height:721; overflow:auto"id="idtamanhodaPaginaRolagem" >
                                                            <ul id="idtamanhodaPagina33" class="conversation-list" data-simplebar="init" style="height:100%;">
                        
                                                            <div class="menupontinhoflutuante" id="idNavCustom" onClick="fnMostrarMenu('left-side-menu');"  style="display:non">														
                                                                            <a style="float:right;" >
                                                                                            <img src="layoutHipper\pontinhos.jpeg" id="idImgPontinhos" class="idImgPontinhos"  style="width: 60px;heigth:60px;z-index:99999!important">
                                                                                        </a>
                                                        
                                                            </div>
                                                                            <!-- start page title -->
                                                                            <div class="row">
                    
                                                                                    <div class="page-title-box">
                                                                                    &nbsp;
                                                                                        <h4 class="page-title">                                        
                    
                                                                                        &nbsp;&nbsp;&nbsp;&nbsp;Cadastro&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h4>
                                                                                    </div>
                    
                                                                            </div>
                                                                            <!-- end page title -->
                                                                            
                                                                            
                    
                                            <?php	
                                        }; //se tiver list que ocupa mais espaço
                                        
                                        ?>					  
		
