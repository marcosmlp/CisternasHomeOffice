<?php
$novo_nome='';

ini_set('upload-max-filesize', '10M');
ini_set('post_max_size', '10M');


	class UploadFile{
		private $arquivo;
		private $altura;
		private $largura;
		private $pasta;

		function __construct($arquivo, $altura, $largura, $pasta){
			$this->arquivo = $arquivo;
			$this->altura  = $altura;
			$this->largura = $largura;
			$this->pasta   = $pasta;
		}
		
		private function getExtensao(){
			//retorna a extensao da imagem	
			$extensao = explode('.', $this->arquivo['name']);
			$extensao = strtolower(end($extensao));
			return $extensao;
		}
		
		private function ehImagem($extensao){
			$extensoes = array('gif', 'jpeg', 'jpg', 'png', 'txt', 'bat', 'txt', 'csv', 'xsl', 'xslt', 'sql');	 // extensoes permitidas
			if (in_array($extensao, $extensoes))
				return true;	
		}
		
		//largura, altura, tipo, localizacao da imagem original
		private function redimensionar($imgLarg, $imgAlt, $tipo, $img_localizacao){
			//descobrir novo tamanho sem perder a proporcao
			if ( $imgLarg > $imgAlt ){
				$novaLarg = $this->largura;
				$novaAlt = round( ($novaLarg / $imgLarg) * $imgAlt );
			}
			elseif ( $imgAlt > $imgLarg ){
				$novaAlt = $this->altura;
				$novaLarg = round( ($novaAlt / $imgAlt) * $imgLarg );
			}
			else // altura == largura
				$novaAltura = $novaLargura = max($this->largura, $this->altura);
			
			//redimencionar a imagem
			
			//cria uma nova imagem com o novo tamanho	
			$novaimagem = imagecreatetruecolor($novaLarg, $novaAlt);
			
			switch ($tipo){
				case 1:	// gif
					$origem = imagecreatefromgif($img_localizacao);
					imagecopyresampled($novaimagem, $origem, 0, 0, 0, 0,
					$novaLarg, $novaAlt, $imgLarg, $imgAlt);
					imagegif($novaimagem, $img_localizacao);
					break;
				case 2:	// jpg
					$origem = imagecreatefromjpeg($img_localizacao);
					imagecopyresampled($novaimagem, $origem, 0, 0, 0, 0,
					$novaLarg, $novaAlt, $imgLarg, $imgAlt);
					imagejpeg($novaimagem, $img_localizacao);
					break;
				case 3:	// png
					$origem = imagecreatefrompng($img_localizacao);
					imagecopyresampled($novaimagem, $origem, 0, 0, 0, 0,
					$novaLarg, $novaAlt, $imgLarg, $imgAlt);
					imagepng($novaimagem, $img_localizacao);
					break;
			}
			
			//destroi as imagens criadas
			imagedestroy($novaimagem);
			imagedestroy($origem);
		}
		
		public function salvar(){									
			$extensao = $this->getExtensao();
			
			//gera um nome unico para a imagem em funcao do tempo
			//$novo_nome = $this->arquivo['name'].time() . '.' . $extensao;
			//$novo_nome = $_POST['tipo'].time().$this->arquivo['name'];

			$novo_nome = 'NovaCarga.csv';


// 			$novo_nome = $_POST['tipo'].time().'.' . $extensao;
			//localizacao do arquivo 
			$destino = $this->pasta . $novo_nome;
			
// 			$servidorBd = 'df7436sr235.diretorio.caixa/var/carga/sides/'.$destino;
// 			if( !move_uploaded_file($this->arquivo['tmp_name'], $servidorBd) ){
// 				return "Erro " . $this->arquivo['error'];
// 			}
			//move o arquivo esse primeiro será o processado,como toda vez tem que substituir então ele que será apagado ao inserir um com o mesmo nome.
			if (! move_uploaded_file($this->arquivo['tmp_name'], $destino)){
				if ($this->arquivo['error'] == 1)
					return "Tamanho excede o permitido";
				else
					return "Erro " . $this->arquivo['error'];
			}
			
			//esse é o arquivo que será visto ao fazer download, até mesmo para não acessar ele e que será gravado com esse nome na base.
			//$rs = file($destino);
			$destinoNovo = $this->pasta.date("Y_m_d_").time().$novo_nome;
			//file_put_contents( $destinoNovo , implode( PHP_EOL,$rs));
			$novo_nome=$destinoNovo;
		    //le o arquivo anterior.
			$fptc = @fopen($destino, "rb");
		    $strtextoCompleto = @fread($fptc, 99999999);
	    
		    //salva o arquivo com o novo nome para não sobrescrever
			$arquivonovo = fopen($destinoNovo, "w");
			fwrite($arquivonovo, $strtextoCompleto);
			//tira o arquivo da memória do computador.
			fclose($arquivonovo);
			fclose($fptc);
			//limpar o texto da memória.
			$strtextoCompleto="";
			//esse é o arquivo que será visto ao fazer download, até mesmo para não acessar ele e que será gravado com esse nome na base.
		//	if (! move_uploaded_file($this->arquivo['tmp_name'], time().$destino)){
			//	if ($this->arquivo['error'] == 1)
				//	return "Tamanho excede o permitido";
			//	else
			//		return "Erro " . $this->arquivo['error'];
		//	}				
			//if ($this->ehImagem($extensao)){												
				//pega a largura, altura, tipo e atributo da imagem
				//list($largura, $altura, $tipo, $atributo) = getimagesize($destino);

				// testa se Ã© preciso redimensionar a imagem
				//if(($largura > $this->largura) || ($altura > $this->altura))
				//	$this->redimensionar($largura, $altura, $tipo, $destino);
			//}sides\application\
				if ($_POST['tipo'] == 'OBJETIVOS_INDIVIDUAIS') {
					//aguarda 10 segundos para terminar de salvar.
					sleep(10);
					// tem que alterar a primeira linha pois vem com campos em branco e dï¿½ erro pois nï¿½o pode ter tï¿½tulo na tela.
					$nomeArquivo=$destino;
					//echo "<script>alert('Inclusao 2.Unidade:".$destino." Tipo');</script>";
					if(!file_exists($nomeArquivo))
					{
					//	echo "Arquivo nï¿½o foi encontrado";
					}
					else
					{
						$totalDelimitadorPorLinha=43;
						$Delimitador =";";	
						$strCabecalho="ACORDO DE OBJETIVOS;Status;Status parcial;Avaliador;Mat.Avaliador;Avaliado;Mat.Avaliado;Coluna;ACORDO 2015 - OBJETIVOS INDIVIDUAIS;cExtra1;cExtra2;cExtra3;1 INSERIR OBJETIVOS INDIVIDUAIS;cExtra4;cExtra5;cExtra6;1.1 OBJETIVO INDIVIDUAL;cExtra7;cExtra8;cExtra9;1.2 OBJETIVO INDIVIDUAL;cExtra10;cExtra11;cExtra12;1.3 OBJETIVO INDIVIDUAL;cExtra13;cExtra14;cExtra15;1.4 OBJETIVO INDIVIDUAL;cExtra16;cExtra17;cExtra18;1.5 OBJETIVO INDIVIDUAL;cExtra19;cExtra20;cExtra21;1.6 OBJETIVO INDIVIDUAL;cExtra22;cExtra23;cExtra24;1.7 OBJETIVO INDIVIDUAL;cExtra25;cExtra26;cExtra27;";
						$fileName=$nomeArquivo;	
					    $fileNamePadrao="upload/ObjetivosOrganizados.csv"; 
						$NAOaceitaLinhaEmbranco=true;
						$retorno=  fnAjustarArquivo($fileName,$fileNamePadrao,$Delimitador,$totalDelimitadorPorLinha,$strCabecalho,$NAOaceitaLinhaEmbranco);
					}//arquivo nao foi encontrado.
				}
			return "/".$novo_nome."";
		}						
	}
?>


<?php

function fnAjustarArquivoN($fileName,$fileNamePadrao,$Delimitador,$totalDelimitadorPorLinha,$strCabecalho,$NAOaceitaLinhaEmbranco){
	$tempo=time();
	/*
	 PEGUEI O ARQUIVO SALVEI COMO EXCEL ORIGINAL DEPOIS EXPORTEI ELE PARA CSV SEPARADO POR VIRGULA QUE AUTOMÁTICAMENTE JÁ SALVA POR PONTO E VIRGULA PADRÃO.
	exemplo e explicação de cada parametro.
	total de delimitadores por linha, quantos campos tem separados por ponto e virgula.
	$totalDelimitadorPorLinha=43;
	qual o tipo de delimitador usado , ou ;
	$Delimitador =";";	
	se tiver cabeçalho e quiser subistituir por outro cabeçalho.
	$strCabecalho="ACORDO DE OBJETIVOS;Status;Status parcial;Avaliador;Mat.Avaliador;Avaliado;Mat.Avaliado;Coluna;ACORDO 2015 - OBJETIVOS INDIVIDUAIS;cExtra1;cExtra2;cExtra3;1 INSERIR OBJETIVOS INDIVIDUAIS;cExtra4;cExtra5;cExtra6;1.1 OBJETIVO INDIVIDUAL;cExtra7;cExtra8;cExtra9;1.2 OBJETIVO INDIVIDUAL;cExtra10;cExtra11;cExtra12;1.3 OBJETIVO INDIVIDUAL;cExtra13;cExtra14;cExtra15;1.4 OBJETIVO INDIVIDUAL;cExtra16;cExtra17;cExtra18;1.5 OBJETIVO INDIVIDUAL;cExtra19;cExtra20;cExtra21;1.6 OBJETIVO INDIVIDUAL;cExtra22;cExtra23;cExtra24;1.7 OBJETIVO INDIVIDUAL;cExtra25;cExtra26;cExtra27";
	nome do arquivo que é lido.
	$fileName="objIndividuaiscsvtexto.txt";	
	nome do arquivo que quer salvar por exemplo le arq.csv  e salva arquivo.TXT
    $fileNamePadrao="objIndividuaiscsvtextoNovo.txt"; 
*/
	/*$arquivo2 = fopen($fileName, "w");
	$str2 = @fread($arquivo2, 99999999);
	//$str2=str_replace ( "\r" , "\n" , $str2);
	$str2=str_replace ( "\n" , "" , $str2);
	fwrite($arquivo2, $str2);
	fclose($arquivo2);
	sleep(13);	*/
	
	//$total = count(file($fileName));	
	//$fpORIGINAL = @fopen($fileName, "rb");
	//$strOriginal = @fread($fpORIGINAL, 99999999);

	// NO ARQUIVO TEM QUEBRA DE LINHA DENTRO DOS CAMPOS AI NÃO PODE DEFINIR A LINHA PELA SIMPLES QUEBRA DE LINHA MAS PELO PRIMEIRO NOME NO PROXIMO CAMPO.
	//$total = strpos_count($strOriginal,"\nACORDO");	
	
	//fclose($fpORIGINAL);
	$countlinhashandle=0;	
	$textoCompleto="";  

	$linhaOriginal="";
	$linhaOriginal="";
	$quantidadeDelimitadores="";
				for ($ic = 0; $ic < $totalDelimitadorPorLinha; $ic++){ 
					$quantidadeDelimitadores=$quantidadeDelimitadores.$Delimitador;
				}
				
	// verifica se o arquivo existe
	if (!file_exists($fileName)) return '';
	//abre o arquivo.
	$fp = @fopen($fileName, "rb");
	//$str = @fread($fp, filesize ($fp));
	if (!$fp) return '';
	$strGERAL = @fread($fp, 99999999);
	$strGERAL =str_replace( "\n@ACORDO#OBJETIVOS_INDIVIDUAIS@" , "$#$#ACORDO#$#$" , $strGERAL);
	$strGERAL=str_replace ( "\r\n" , "" , $strGERAL);
	$strGERAL=str_replace ( "\n\r" , "" , $strGERAL);
	$strGERAL=str_replace ( "\r" , "" , $strGERAL);
	$strGERAL=str_replace ( "\n" , "" , $strGERAL);	
	//tira todas as outras quebras de linha.
	//$strGERAL =str_replace( "$#$#ACORDO#$#$" , "\nACORDO" , $strGERAL);
	// NO ARQUIVO TEM QUEBRA DE LINHA DENTRO DOS CAMPOS AI NÃO PODE DEFINIR A LINHA PELA SIMPLES QUEBRA DE LINHA MAS PELO PRIMEIRO NOME NO PROXIMO CAMPO.
	$number_of_occurencesGeral = strpos_count($strGERAL,"$#$#ACORDO#$#$");	

	$total=$number_of_occurencesGeral;
$number_of_occurences=$number_of_occurencesGeral;
       // $str = @fread($fp, 999999); 
		//echo $str;
       // $number_of_occurences = strpos_count($str,"\n");
//echo "<br>number_of_occurencesGeral:";
//	echo $number_of_occurencesGeral;				
	for($i = 0; $i <= $total; $i++)
		 {
			// echo "<br><br>PLinhaOriginal:<br>";
			 //se quiser um cabeçalho diferente do original como por exemplo com nomes de campos preenchidos que vieram em branco.
				 	/*lê a linha especifica */
				 	$line=$i;
				 //	$line=$line;
				 	$occurence = 0;
				 	$contents = '';
				 	$startPos = -1;
				 	$number_of_occurences=$number_of_occurencesGeral;

				 	
				 	//enquanto o arquivo não estiver vazio.
				// 	while (!@feof($fp)) {
				 		//$str = @fread($fp, filesize ($fp));

				 		// na pratica esse é o comando correto para ler a  
				 		//$str = fgetc($fp);
				 		$str=$strGERAL;

				 		//  echo $number_of_occurences;
				 		if ($number_of_occurences == 0) {if ($start_pos != -1) {$contents .= $str;}}
				 		else {
				 			$lastPos = 0;
				 			for ($ia = 0; $ia < $number_of_occurences; $ia++){
				 				$pos = strpos($str,"$#$#ACORDO#$#$", $lastPos);
				 	
				 				$occurence++;
				 				if ($occurence == $line) {
				 					$startPos = $pos;
				 					if ($ia == $number_of_occurences - 1) {$contents = substr($str, $startPos + 1);}
				 				} elseif ($occurence == $line + 1) {
				 					if ($ia == 0) {$contents .= substr($str, 0, $pos);} else {$contents = substr($str, $startPos, $pos - $startPos);}
				 					$occurence = 0;
				 					break;
				 				}
				 				$lastPos = $pos + 1;
				 			}
				 		}
				 //	}

				 	//$contents=str_replace ( "\n" , "" , $contents);
				 	//adicionei os delimitadores no final para sempre dar maior ai só precisa de uma lógica.
				 	 $linhaOriginal=$contents.$quantidadeDelimitadores.$quantidadeDelimitadores;
				 	/*temina de ler a linha especifica */
			  // $linhaOriginal=getLineStr($fileName,$i);
			   $countlinhashandle=$countlinhashandle+1;
			   $linhaEmBranco="ACEITA";
				if($NAOaceitaLinhaEmbranco){
					$linhaEmBranco=trim($linhaOriginal);
				}

				$number_of_occurencesLinha = strpos_count($linhaOriginal,";"); 
				//	 echo "<br><br>Quantidade de ocorrencias:<br>";			
			//	echo $number_of_occurences;
				$quantosDelimitadoresFaltam=0;
 			if ($number_of_occurencesLinha == $totalDelimitadorPorLinha) {
 				$linhaNova=$linhaOriginal;
 			//	echo "<br><br>Já tem a quantidade certa:<br>";
 			//	echo $linhaOriginal; 				
 			}else {
				if ($number_of_occurencesLinha <= $totalDelimitadorPorLinha) {
					$quantosDelimitadoresFaltam=$number_of_occurencesLinha-$totalDelimitadorPorLinha;
				//	echo "<br><br>Quantos faltam:<br>";	
				//	echo $linhaOriginal;						
				//	echo $quantosDelimitadoresFaltam;	
					//adicina os delimitadores que faltavam			
					$linhaNova = $linhaOriginal.substr($quantidadeDelimitadores, $quantosDelimitadoresFaltam);
				}else {
	
					$quantosDelimitadoresFaltam=$totalDelimitadorPorLinha-$number_of_occurencesLinha;
					//$quantosDelimitadoresFaltam=$quantosDelimitadoresFaltam*-1;
					//echo "<br><br>Quantos faltam tamanho maior:<br>";
				//	echo  $quantosDelimitadoresFaltam;	
					//echo "<br><br>original:<br>";	
				//	echo $linhaOriginal;
					//echo strlen($linhaOriginal)-$quantosDelimitadoresFaltam;
					//verifica quantos ; tem em branco para frente.
					//se tiver maior é que foi exportado de forma errada ai tem vários arquivos com mais de 43 registros em branco e tem que tirar.
					// tira essa quantidade de ; que sobram da string original.
					$linhaNova = substr($linhaOriginal, 0,$quantosDelimitadoresFaltam);
					//$linhaNova = $linhaOriginal;
				}		
 			}
					// echo "<br><br>Presultado:<br>";
						//	   echo $linhaNova;
							   // caso queira adicionar br no lugar da quebra de linha $linhaNova=nl2br($linhaNova);							   
							   //tira a quebra de linha do meio do arquivo;
							   $linhaNova=str_replace ( "\n" , "" , $linhaNova);
							   $linhaNova=str_replace ( "'" , "" , $linhaNova);
							   $linhaNova=str_replace ( '"' , "" , $linhaNova);
							   $linhaNova=str_replace ( "\r" , "" , $linhaNova);	
							   $linhaNova=str_replace ( "Descrição do Objetivo" , "Descricao do Objetivo" , $linhaNova);
							   $linhaNova=str_replace ( "Comentário sobre o Objetivo" , "Comentario sobre o Objetivo" , $linhaNova);
							   $linhaNova=str_replace ( "Avaliação final" , "Avaliacao final" , $linhaNova);
							   $linhaNova=str_replace ( "Ponderação" , "Ponderacao" , $linhaNova);
							   $linhaNova=str_replace ( "DescriÃ§Ã£o do Objetivo" ,"Descricao do Objetivo" , $linhaNova);
							   $linhaNova=str_replace ( "ComentÃ¡rio sobre o Objetivo" , "Comentario sobre o Objetivo" , $linhaNova);
							   $linhaNova=str_replace ( "AvaliaÃ§Ã£o final" , "Avaliacao final" , $linhaNova);
							   $linhaNova=str_replace ( "PonderaÃ§Ã£o" , "Ponderacao" , $linhaNova);							   							   							   							   							   

							   
							   
							//echo $i;   

						if ($i == 0){
									if ($strCabecalho!=""){
									$linhaNova=$strCabecalho; 								
									}
						}
						if($linhaEmBranco!=""){
							if ($i == $total){
							// não adiciona a quebra de linha no final se for o último arquivo.
								$textoCompleto=$textoCompleto.$linhaNova."";
							} else {
								$textoCompleto=$textoCompleto.$linhaNova."\n";	
							}
						}

		//escreve o arquivo novo.					   
	//$arquivo = fopen("objIndividuaiscsvtexto.txt", "w");						   
					   
	  //echo $countlinhashandle;
  
  //echo getStrLine("objIndividuaiscsvtexto.txt",$i);
       //    $linha = "teste";
         //  if($i == $id);
         //  else
          //       fwrite($novo, $linha);
    }
    echo "<!--Terminou o processamento e ajuste do arquivo-->";
 //   echo $fileNamePadrao;
	$arquivo = fopen($fileNamePadrao, "w");	
	$textoCompleto =str_replace( "$#$#ACORDO#$#$" , "ACORDO" , $textoCompleto);
	$textoCompleto =str_replace( "#$#ACORDO#$#$" , "ACORDO" , $textoCompleto);
	fwrite($arquivo, $textoCompleto);		

	//tira o arquivo da memória do computador.
fclose($arquivo);
@fclose($fp);
//echo time()-$tempo;
return "Alterado com sucesso";
}
//Apaga um arquivo!!!
//unlink("editantoArquivoantigo.txt");

function strpos_count2($haystack, $needle, $ib = 0) { 
    while (strpos($haystack,$needle) !== false) {$haystack = substr($haystack, (strpos($haystack,$needle) + 1)); $ib++;} 
    return $ib; 
} 
function getLineStr2($file,$line=1){ 
/*lê a linha especifica */
	$occurence = 0; 
    $contents = ''; 
    $startPos = -1; 
	// verifica se o arquivo existe
    if (!file_exists($file)) return ''; 
	//abre o arquivo.
    $fp = @fopen($file, "rb");
    //$str = @fread($fp, filesize ($fp));
    if (!$fp) return ''; 

	//enquanto o arquivo não estiver vazio.
    while (!@feof($fp)) {    	
    	//$str = @fread($fp, filesize ($fp));
        $str = @fread($fp, 99999999); 
       // na pratica esse é o comando correto para ler a  $str = fgetc($fp);
	    $str=str_replace ( "\r\n" , "\n" , $str);	
	    $str=str_replace ( "\n\r" , "\n" , $str);	
     	$str=str_replace ( "\r" , "\n" , $str);			
    	// NO ARQUIVO TEM QUEBRA DE LINHA DENTRO DOS CAMPOS AI NÃO PODE DEFINIR A LINHA PELA SIMPLES QUEBRA DE LINHA MAS PELO PRIMEIRO NOME NO PROXIMO CAMPO.
        $number_of_occurences = strpos_count($str,"\nACORDO");
      //  echo $number_of_occurences;
        if ($number_of_occurences == 0) {if ($start_pos != -1) {$contents .= $str;}} 
        else { 
            $lastPos = 0; 
            for ($i = 0; $i < $number_of_occurences; $i++){ 
                $pos = strpos($str,"\nACORDO", $lastPos); 
				
                $occurence++; 
                if ($occurence == $line) { 
                    $startPos = $pos; 
                    if ($i == $number_of_occurences - 1) {$contents = substr($str, $startPos + 1);} 
                } elseif ($occurence == $line + 1) { 
                    if ($i == 0) {$contents .= substr($str, 0, $pos);} else {$contents = substr($str, $startPos, $pos - $startPos);} 
                    $occurence = 0; 
                    break; 
                } 
                $lastPos = $pos + 1; 
            } 
        } 
    } 
    @fclose($fp); 
    $contents=str_replace ( "\n" , "" , $contents);
    return $contents; 
    /*temina de ler a linha especifica */
} 
 
?>