 			
											<?php
				session_start();
				$conexao='';
				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';
				?>
											<html> 											
	
											<link href='css/bootstrap.css' rel='stylesheet'><link href='_css_estiloGeral.css' rel='stylesheet'>

											<!--Início dos comandos em JavaScript na tela de Inclusao e alteração no banco de dados --> 

															
			<script language=javaScript> 
				function fnValidaCampo(campo,Mensagem,TipoDeValidacao,TipoDeCampo){
					//se o usuário pediu para não mostrar esse campo então pode incluir ele vazio mesmo que esteja como obrigatório.
					if(campo==undefined){
						return true;
					}else{
						if (campo.value==0){
							fnMensagem(Mensagem);
							campo.focus();
							return false;
						}							
						return true;
					}
				}
			</script> 				
			<script language=javaScript> 	
			    function fnExcluir(LinkExclusao,MensagemPergunta){
					var retorno = confirm(MensagemPergunta);
					if (retorno){
						window.location=LinkExclusao;
						return true;
					} else {
						return false;
					}
				}
			    function fnAlterar(LinkAlteracao){
 					window.location=LinkAlteracao;
				}				
				function fnMensagem(Mensagem){
					//assim pode mudar em apenas um lugar e colocar em um div, ou no topo da página como o cliente desejar alterando só nesse arquivo.
					alert(Mensagem);
				}
	
			</script> 
					<!--AS JavaScript /AS-->

											<!--Fim dos comandos em JavaScript na tela de Inclusao e alteração no banco de dados -->

											<body id='idBody'>
											<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "menu.php"; 
			?> <?php  }; ?>
											<form id='formEntidademantenedora' name='formEntidademantenedora' action='EntidademantenedoraEdit_banco.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'  method='POST'>
												<table class='clDetalhes'>

													<tr><td class='clTitulo' colspan=100%>
													<br/><br/>Entidade mantenedora
													</td></tr>
													<tr><td>													 
																																																			
													
					<!-- início do update e da inclusão -->
					<?php
					//verifica se é insert.
					 if ($_POST['SQ_CISTERNAS_ENTIDADEMANTENEDORA']==''){
						  $sqlp= " Insert into cisternas_entidademantenedora (NO_FANTASIA,NU_CNPJ,DE_ENDERECO,DE_UF,NU_CEP,DE_TELEFONE) values('".fnPOST('NO_FANTASIA')."'
															,'".fnPOST('NU_CNPJ')."'
															,'".fnPOST('DE_ENDERECO')."'
															,'".fnPOST('DE_UF')."'
															,'".fnPOST('NU_CEP')."'
															,'".fnPOST('DE_TELEFONE')."'
															)";
						  $resp = mysqlexecuta($conexao,$sqlp);
						  $sqlp= " select  SQ_CISTERNAS_ENTIDADEMANTENEDORA from cisternas_entidademantenedora order by 1 desc  limit 1 ";
						  $resp = mysqlexecuta($conexao,$sqlp);
						  while ($rowp = fnmysqli_fetch_array($resp)) { 
						  echo '<br/>Registro inserido com sucesso.<br/><br/>'; echo '<br/>Código do registro inserido:';
							$SQ_CISTERNAS_ENTIDADEMANTENEDORA= $rowp['SQ_CISTERNAS_ENTIDADEMANTENEDORA'];
							$_SESSION['SQ_CISTERNAS_ENTIDADEMANTENEDORA']= $SQ_CISTERNAS_ENTIDADEMANTENEDORA;
							echo $SQ_CISTERNAS_ENTIDADEMANTENEDORA;
								$voltar='Entidademantenedora_Edit.php?'.$_SESSION['RETORNO_Entidademantenedora_Edit'];
								
								echo '<br/><br/>';
								//INSERE E JÁ VAI PARA UM NOVO, PARA INSERIR UM NOVO REGISTRO, TELA VINCULADA É QUANDO ESTA VINCULADA A UMA PRINCIPAL E NÃO DEVE MOSTRAR MENUS.							
								if (gt('IeNew')=='S'){	
                                    ?>
									<script>window.location="Entidademantenedora_Edit.php?<?php echo $_SESSION['RETORNO_Entidademantenedora_Edit'] ?>";</script>';	
									<?php		exit();						
									
								}  
								//INSERE E JÁ VAI O EDIT CASO TENHA TABELAS VINCULADAS multselect PARA ADICIONAR ELAS, TELA VINCULADA É QUANDO ESTA VINCULADA A UMA PRINCIPAL E NÃO DEVE MOSTRAR MENUS.						
								if (gt('IeMultSelect')=='S'){		
									?>
									<script>window.location="Entidademantenedora_Edit.php?<?php echo 'SQ_CISTERNAS_ENTIDADEMANTENEDORA='. $rowp['SQ_CISTERNAS_ENTIDADEMANTENEDORA'].'&TelaVinculada='.gt('TelaVinculada'); ?>";</script>';	
									<?php		exit();						
									
								} 

								//Insere nos eventos a inclusão do registro.
								$sqlp2= " insert into cisternas_entidademantenedora_eventos_log  (DT_DO_EVENTO_EM_EVENTOS_LOG,DESCRICAO_DO_EVENTO_EM_EVENTOS_LOG,IP_DO_EVENTO_EM_EVENTOS_LOG, SQ_CISTERNAS_ENTIDADEMANTENEDORA, NO_FANTASIA,NU_CNPJ,DE_ENDERECO,DE_UF,NU_CEP,DE_TELEFONE) select '".date("Y-m-d H:i:s")."' as DT_DO_EVENTO_EM_EVENTOS_LOG ,'Dados da inclusão do registro.' as DESCRICAO_DO_EVENTO_EM_EVENTOS_LOG ,'".get_client_ip()."' AS IP_DO_EVENTO_EM_EVENTOS_LOG, SQ_CISTERNAS_ENTIDADEMANTENEDORA, NO_FANTASIA,NU_CNPJ,DE_ENDERECO,DE_UF,NU_CEP,DE_TELEFONE from cisternas_entidademantenedora where SQ_CISTERNAS_ENTIDADEMANTENEDORA = '".$rowp['SQ_CISTERNAS_ENTIDADEMANTENEDORA']."' ";

								$resp2 = mysqlexecuta($conexao,$sqlp2);
								
								 }  ;
					 //else se não vier o id preenchido então é update	
					} 
													 else { 
						  //Insere nos eventos da alteração do registro.
						  $sqlp= " insert into cisternas_entidademantenedora_eventos_log  (DT_DO_EVENTO_EM_EVENTOS_LOG,DESCRICAO_DO_EVENTO_EM_EVENTOS_LOG,IP_DO_EVENTO_EM_EVENTOS_LOG ,SQ_CISTERNAS_ENTIDADEMANTENEDORA, NO_FANTASIA,NU_CNPJ,DE_ENDERECO,DE_UF,NU_CEP,DE_TELEFONE) select '".date("Y-m-d H:i:s")."' as DT_DO_EVENTO_EM_EVENTOS_LOG ,'Dados antes da alteração do registro.' as DESCRICAO_DO_EVENTO_EM_EVENTOS_LOG,'".get_client_ip()."' AS IP_DO_EVENTO_EM_EVENTOS_LOG,SQ_CISTERNAS_ENTIDADEMANTENEDORA, NO_FANTASIA,NU_CNPJ,DE_ENDERECO,DE_UF,NU_CEP,DE_TELEFONE from cisternas_entidademantenedora where SQ_CISTERNAS_ENTIDADEMANTENEDORA ='".fnPOST('SQ_CISTERNAS_ENTIDADEMANTENEDORA')."'";
						  $resp = mysqlexecuta($conexao,$sqlp);
						  
						  //Faz o update na tabela
						  $sqlp= " Update  cisternas_entidademantenedora set NO_FANTASIA='".fnPOST('NO_FANTASIA')."'
																	,NU_CNPJ='".fnPOST('NU_CNPJ')."'
																	,DE_ENDERECO='".fnPOST('DE_ENDERECO')."'
																	,DE_UF='".fnPOST('DE_UF')."'
																	,NU_CEP='".fnPOST('NU_CEP')."'
																	,DE_TELEFONE='".fnPOST('DE_TELEFONE')."'
																	  where SQ_CISTERNAS_ENTIDADEMANTENEDORA='".fnPOST('SQ_CISTERNAS_ENTIDADEMANTENEDORA')."'";
						  $resp = mysqlexecuta($conexao,$sqlp);
						  // consulta no servidor se o registro está atualizado, e pega o código se retornar é que o update não deu erro.
						  $sqlp= " select  SQ_CISTERNAS_ENTIDADEMANTENEDORA from cisternas_entidademantenedora  where SQ_CISTERNAS_ENTIDADEMANTENEDORA='".fnPOST('SQ_CISTERNAS_ENTIDADEMANTENEDORA')."' order by 1 desc limit 1";
						  $resp = mysqlexecuta($conexao,$sqlp);
						  while ($rowp = fnmysqli_fetch_array($resp)) { 
						  //pega o código do registro atualizado.
						  echo '<br/>Registro alterado com sucesso.<br/><br/>'; echo '<br/>Código do registro alterado:';
							$SQ_CISTERNAS_ENTIDADEMANTENEDORA= $rowp['SQ_CISTERNAS_ENTIDADEMANTENEDORA'];
							$_SESSION['SQ_CISTERNAS_ENTIDADEMANTENEDORA']= $SQ_CISTERNAS_ENTIDADEMANTENEDORA;
							echo $SQ_CISTERNAS_ENTIDADEMANTENEDORA;
								$voltar='Entidademantenedora_Edit.php?'.$_SESSION['RETORNO_Entidademantenedora_Edit'];
							echo '<br/><br/>';
								//ATUALIZA E JÁ VAI PARA UM NOVO, PARA INSERIR UM NOVO REGISTRO, TELA VINCULADA É QUANDO ESTA VINCULADA A UMA PRINCIPAL E NÃO DEVE MOSTRAR MENUS.							
								if (gt('IeNew')=='S'){							
                                    ?>
									<script>window.location="Entidademantenedora_Edit.php?<?php echo $_SESSION['RETORNO_Entidademantenedora_Edit'] ?>";</script>';	
									<?php	exit();
								}  
								//ATUALIZA E JÁ VAI O EDIT CASO TENHA TABELAS VINCULADAS multselect PARA ADICIONAR ELAS, TELA VINCULADA É QUANDO ESTA VINCULADA A UMA PRINCIPAL E NÃO DEVE MOSTRAR MENUS.						
								if (gt('IeMultSelect')=='S'){							
										?>
									<script>window.location="Entidademantenedora_Edit.php?<?php echo 'SQ_CISTERNAS_ENTIDADEMANTENEDORA='. $rowp['SQ_CISTERNAS_ENTIDADEMANTENEDORA'].'&TelaVinculada='.gt('TelaVinculada'); ?>";</script>';	
									<?php		exit();
								}   }  ;
					}?>
					<!-- fim do update e da inclusão -->
					
					<?php 
					//Se vier de outra página e essa só for uma página assessória, que segue um fluxo e volta para a anterior gt(`TelaVinculadaRetorno) ao terminar a inclusão.
					if ($_SESSION['TelaVinculadaRetorno']<>''){	?>
								<script> alert('Incluído com sucesso');
								window.location="<?php echo $_SESSION['TelaVinculadaRetorno'];?>?RETORNO_CAMPOS_SQ_CHATBOT_AGENDA=PARAPREENCHERRETORNO&<?php echo $_SESSION[$_SESSION['TelaVinculadaRetorno']];?>&<?php echo 'SQ_CHATBOT_CLIENTE='. $rowp['SQ_CHATBOT_CLIENTE'].'&TelaVinculada='.gt('TelaVinculada'); ?>";</script>
								
						<?php
							//Exemplo: ChatBot/Agenda_Edit.php?DE_CLINICA=8&DT_DE_ALTERACAO=22/02/2021%2020:33&DE_CLIENTE=21&DE_ESPECIALIDADE=1&TP_DE_MARCACAO=1&DE_CONVENIO=3&TP_DE_CONVENIO=10&DE_STATUS_DO_AGENDAMENTO=1&DE_FORMA_DA_CONSULTA=1&DE_PROFISSIONAL=&DT_DATA=&DE_HORA=&SQ_CHATBOT_AGENDA=&IeNew=N&TelaVinculadaRetorno=Agenda_Edit.php&&SQ_CHATBOT_CLIENTE=&TelaVinculada=
					 $_SESSION['TelaVinculadaRetorno']='';
					}	?>
					<!-- Início do botão de Detalhar no incluir e alterar -->
					<?php if(fnAcesso('Entidademantenedora_Details.php')){ ?>
					<input  class='btn btn-primary btn-sm mt-1' 	
									type='button' 
									name='btDetalhar' 
									onClick='window.location="Entidademantenedora_Details.php?SQ_CISTERNAS_ENTIDADEMANTENEDORA=<?php echo $SQ_CISTERNAS_ENTIDADEMANTENEDORA ?>&TelaVinculada=";'
									id='btDetalhar' 
									value='Detalhar'	 											
									>
						
					<?php }?>			
					<!-- Fim do botão de Detalhar no incluir e alterar -->	

					<!-- Início do botão de Listar no incluir e alterar -->
									<input  class='btn btn-primary btn-sm mt-1' 	
									type='button' 
									name='btListar' 
									onClick='window.location="Entidademantenedora_List.php?SQ_CISTERNAS_ENTIDADEMANTENEDORA=<?php echo $SQ_CISTERNAS_ENTIDADEMANTENEDORA ?>&TelaVinculada=";'";'
									id='btListar' 
									value='Listar'	 											
									>
					<!-- Fim do botão de Listar no incluir e alterar -->	
					
					
																		
													
				<!-- Início do botão de voltar no incluir e alterar -->
									<input  class='btn btn-primary btn-sm mt-1' 	
								type='button' 
								name='btVoltar' 
								onClick='history.go(-1);'
								id='btVoltar' 
								value='Voltar'	 											
								>
				<!-- Fim do botão de voltar no incluir e alterar -->								
			
													</td></tr>
													<tr><td class=MensagemRodape colspan=100%>
													<hr/>											
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>Entidade mantenedora<?php  }; ?>
													</td></tr>
												</table>
											</form>										
											</body>
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "rodape.php"; 
			?> <?php  }; ?>	
											</html>