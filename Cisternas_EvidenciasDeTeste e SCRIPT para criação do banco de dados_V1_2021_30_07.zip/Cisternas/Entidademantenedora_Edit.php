  			
											<?php
				session_start();
				$conexao='';
				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';
				?>
											<html>  	

											<!--Início dos comandos em sql de para inícializar a tela de Inclusao e alteração --> 	

											<?php
				//se for alteração pega esse campo, se for vinculação também pega esse campo.			
				 $SQ_CISTERNAS_ENTIDADEMANTENEDORA= gt("SQ_CISTERNAS_ENTIDADEMANTENEDORA");				
				//se estiver dando apenas um refresh na tela, então envia esse campo informando, para não apagar os dados já preenchidos.
				$RETORNO_CAMPOS_SQ_CISTERNAS_ENTIDADEMANTENEDORA= gt("RETORNO_CAMPOS_SQ_CISTERNAS_ENTIDADEMANTENEDORA");


				//Se vier de outra página e essa só for uma página assessória, que segue um fluxo e volta para a anterior gt("TelaVinculadaRetorno") ao terminar a inclusão.
				if( gt("TelaVinculadaRetorno")<>"" ){
					//nome da página de retorno.
					$_SESSION["TelaVinculadaRetorno"]= gt("TelaVinculadaRetorno");
					//nome da página
					$TelaVinculadaRetorno=$_SESSION["TelaVinculadaRetorno"];
					//verifica se está vindo de algum lugar com dados preenchidos.
					if ($_SESSION[$TelaVinculadaRetorno]<>""){
						$_SESSION[$TelaVinculadaRetorno]="";
						$RETORNO_CAMPOS_SQ_CISTERNAS_ENTIDADEMANTENEDORA="PARAPREENCHERRETORNO";
					}else{
						//se não preenche os dados para retorna.
						//dados da página para retornar com tudo preenchido da página de retorno.
						$_SESSION[$TelaVinculadaRetorno]=fnTodosGtEPost(); 
					}
				}				

				// PODE SER UM RELOAD OU BACK NA PRÓPIA PÁGINA ou quando atualiza uma função java script de um select.
				if (($RETORNO_CAMPOS_SQ_CISTERNAS_ENTIDADEMANTENEDORA<>"") or (gt("atualizarCampos")=="sim")){
						
					$NO_FANTASIA = gt("NO_FANTASIA");
								$NU_CNPJ = gt("NU_CNPJ");
								$DE_ENDERECO = gt("DE_ENDERECO");
								$DE_UF = gt("DE_UF");
								$NU_CEP = gt("NU_CEP");
								$DE_TELEFONE = gt("DE_TELEFONE");
								
				} else {					
					if ($SQ_CISTERNAS_ENTIDADEMANTENEDORA<>""){				
						//Faz a consulta no banco de dados na tabela para retornar a lista.
						$sqlp= " select NO_FANTASIA,NU_CNPJ,DE_ENDERECO,DE_UF,NU_CEP,DE_TELEFONE from cisternas_entidademantenedora WHERE SQ_CISTERNAS_ENTIDADEMANTENEDORA='".$SQ_CISTERNAS_ENTIDADEMANTENEDORA."'";

						$resp = mysqlexecuta($conexao,$sqlp);
						while ($rowp = fnmysqli_fetch_array($resp)) {							
							
											//buscando do campo do banco de dados NO_FANTASIA.
											$NO_FANTASIA = $rowp["NO_FANTASIA"];	
											
											//buscando do campo do banco de dados NU_CNPJ.
											$NU_CNPJ = $rowp["NU_CNPJ"];	
											
											//buscando do campo do banco de dados DE_ENDERECO.
											$DE_ENDERECO = $rowp["DE_ENDERECO"];	
											
											//buscando do campo do banco de dados DE_UF.
											$DE_UF = $rowp["DE_UF"];	
											
											//buscando do campo do banco de dados NU_CEP.
											$NU_CEP = $rowp["NU_CEP"];	
											
											//buscando do campo do banco de dados DE_TELEFONE.
											$DE_TELEFONE = $rowp["DE_TELEFONE"];	
											
						}; 
					}else {						
						$NO_FANTASIA = "";
									$NU_CNPJ = "";
									$DE_ENDERECO = "";
									$DE_UF = "";
									$NU_CEP = "";
									$DE_TELEFONE = "";
									
					}			  
					
				}
				?>
				
				

											<!--Fim dos comandos em sql de para inícializar a tela de Inclusao e alteração --> 		

											<link href='css/bootstrap.css' rel='stylesheet'><link href='_css_estiloGeral.css' rel='stylesheet'>

											<!--Início dos comandos em JavaScript na tela de Inclusao e alteração --> 

												
			<script language=javaScript> 
				function fnSubmit(IeNew){					 
						

					// Validando no javaScript o campo document.formEntidademantenedora.NO_FANTASIA,'O preenchimento do campo (Nome fantasia) é obrigatório.','OBRIGATÓRIO','text' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formEntidademantenedora.NO_FANTASIA,'O preenchimento do campo (Nome fantasia) é obrigatório.','OBRIGATÓRIO','text')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						

					// Validando no javaScript o campo document.formEntidademantenedora.NU_CNPJ,'O preenchimento do campo (CNPJ) é obrigatório.','OBRIGATÓRIO','CNPJ' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formEntidademantenedora.NU_CNPJ,'O preenchimento do campo (CNPJ) é obrigatório.','OBRIGATÓRIO','CNPJ')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						

					// Validando no javaScript o campo document.formEntidademantenedora.DE_ENDERECO,'O preenchimento do campo (Endereço) é obrigatório.','OBRIGATÓRIO','text' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formEntidademantenedora.DE_ENDERECO,'O preenchimento do campo (Endereço) é obrigatório.','OBRIGATÓRIO','text')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						

					// Validando no javaScript o campo document.formEntidademantenedora.DE_UF,'O preenchimento do campo (UF) é obrigatório.','OBRIGATÓRIO','Selecao' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formEntidademantenedora.DE_UF,'O preenchimento do campo (UF) é obrigatório.','OBRIGATÓRIO','Selecao')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						

					// Validando no javaScript o campo document.formEntidademantenedora.NU_CEP,'O preenchimento do campo (CEP) é obrigatório.','OBRIGATÓRIO','CEP' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formEntidademantenedora.NU_CEP,'O preenchimento do campo (CEP) é obrigatório.','OBRIGATÓRIO','CEP')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						

					// Validando no javaScript o campo document.formEntidademantenedora.DE_TELEFONE,'O preenchimento do campo (Telefone) é obrigatório.','OBRIGATÓRIO','PhoneNumber' antes de enviar para o servidor.								
					if (!fnValidaCampo(document.formEntidademantenedora.DE_TELEFONE,'O preenchimento do campo (Telefone) é obrigatório.','OBRIGATÓRIO','PhoneNumber')){
						//se a validação do campo retornar false então dá a mensagem de erro e foca o campo que deu erro.
						return false;
					};					
						
					//Para validar se já quer voltar para tela de inclusão novamente para preencher os dados novamente.
					document.formEntidademantenedora.IeNew.value=IeNew;					
					document.formEntidademantenedora.submit();
				}
				//Aqui atualiza a própria página no caso de um campo ser vinculado ao outro ai só colocar nos  parametrosAdicionais= onchange='fnAtualizarPropriaPagina();' '; do select e na clausula where do próximo campos clausulaWhere='WHERE '1'='.TP_DE_MARCACAO.' AND DE_CLINICA='._SESSION['DE_CLINICA'].'	
				function fnAtualizarPropriaPagina(){
					document.formEntidademantenedora.action='Entidademantenedora_Edit.php?atualizarCampos=sim';					
					document.formEntidademantenedora.submit();
				}
			</script> 				
			<script language=javaScript> 
				function fnValidaCampo(campo,Mensagem,TipoDeValidacao,TipoDeCampo){
					//se o usuário pediu para não mostrar esse campo então pode incluir ele vazio mesmo que esteja como obrigatório.
					if(campo==undefined){
						return true;
					}else{
						if (campo.value==0){
							fnMensagem(Mensagem);
							campo.focus();
							return false;
						}							
						return true;
					}
				}
			</script> 				
			<script language=javaScript> 	
			    function fnExcluir(LinkExclusao,MensagemPergunta){
					var retorno = confirm(MensagemPergunta);
					if (retorno){
						window.location=LinkExclusao;
						return true;
					} else {
						return false;
					}
				}
			    function fnAlterar(LinkAlteracao){
 					window.location=LinkAlteracao;
				}				
				function fnMensagem(Mensagem){
					//assim pode mudar em apenas um lugar e colocar em um div, ou no topo da página como o cliente desejar alterando só nesse arquivo.
					alert(Mensagem);
				}
	
			</script> 
					<!--AS JavaScript /AS-->

											<!--Fim dos comandos em JavaScript na tela de Inclusao e alteração -->

											<!--Início dos comandos em FormatacaoJQuery na tela de Inclusao e alteração --> 

											<script language=javaScript>$("#NU_CNPJ").mask("99.999.999/9999-99");$("#NU_CEP").mask("99999-999");$("#DE_TELEFONE").mask("(99)9999-9999");$("#DE_TELEFONE").mask("99999-999");</script>
											
											<!--Fim dos comandos em FormatacaoJQuery na tela de Inclusao e alteração -->											

											<body id='idBody' onload="">
											<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "menu.php"; 
			?> <?php  }; ?>
											<form id='formEntidademantenedora' name='formEntidademantenedora' action='EntidademantenedoraEdit_banco.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'  method='POST' >
												<table class='clDetalhesIncluir'>
													<tr><td class='clTitulo' colspan=100%>
														<br/><br/>Entidade mantenedora
													</td></tr>
													<tr><td>
														
										 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_ENTIDADEMANTENEDORA','NO_FANTASIA')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrNO_FANTASIA'>
									 		<td class='classTd' style='display:block' id='idclassTdNO_FANTASIA'>
										 		<div class='classLabel' style='display:block' id='idclassLabelNO_FANTASIA'>
														<!-- início na tela Entidademantenedora_Edit do label NO_FANTASIA -->
														Nome fantasia
														<!-- fim na tela Entidademantenedora_Edit do label NO_FANTASIA -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdNO_FANTASIA'>

													<!-- início na tela Entidademantenedora_Edit do campo NO_FANTASIA --> 
													
													<input class='classInput'  type='text' name='NO_FANTASIA' 
															id='NO_FANTASIA' 
															
															Width='-1'
															Height='-1'
															MaxLength='100'	
															Title='Nome fantasia'
															value='<?php echo $NO_FANTASIA;?>'
															 

														
															/>
															<!-- fim na tela Entidademantenedora_Edit do campo NO_FANTASIA -->															
													</span>
												</td>
											</tr>
										 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_ENTIDADEMANTENEDORA','NU_CNPJ')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrNU_CNPJ'>
									 		<td class='classTd' style='display:block' id='idclassTdNU_CNPJ'>
										 		<div class='classLabel' style='display:block' id='idclassLabelNU_CNPJ'>
														<!-- início na tela Entidademantenedora_Edit do label NU_CNPJ -->
														CNPJ
														<!-- fim na tela Entidademantenedora_Edit do label NU_CNPJ -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdNU_CNPJ'>

													<!-- início na tela Entidademantenedora_Edit do campo NU_CNPJ --> 
													
													<input class='classInput'  type='text' name='NU_CNPJ' 
															id='NU_CNPJ' 
															
															Width='-1'
															Height='-1'
															MaxLength='19'	
															Title='CNPJ'
															value='<?php echo $NU_CNPJ;?>'
															 
								onKeyPress="return digitos(event, this);" 
								onKeyUp="funcoesGlobaisMascaraGeral('CNPJ',this,event);"
								onBlur="funcoesGlobaisValidarCNPJ('',this);"
								 

														
															/>
															<!-- fim na tela Entidademantenedora_Edit do campo NU_CNPJ -->															
													</span>
												</td>
											</tr>
										 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_ENTIDADEMANTENEDORA','DE_ENDERECO')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrDE_ENDERECO'>
									 		<td class='classTd' style='display:block' id='idclassTdDE_ENDERECO'>
										 		<div class='classLabel' style='display:block' id='idclassLabelDE_ENDERECO'>
														<!-- início na tela Entidademantenedora_Edit do label DE_ENDERECO -->
														Endereço
														<!-- fim na tela Entidademantenedora_Edit do label DE_ENDERECO -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdDE_ENDERECO'>

													<!-- início na tela Entidademantenedora_Edit do campo DE_ENDERECO --> 
													
													<input class='classInput'  type='text' name='DE_ENDERECO' 
															id='DE_ENDERECO' 
															
															Width='-1'
															Height='-1'
															MaxLength='100'	
															Title='Endereço'
															value='<?php echo $DE_ENDERECO;?>'
															 

														
															/>
															<!-- fim na tela Entidademantenedora_Edit do campo DE_ENDERECO -->															
													</span>
												</td>
											</tr>
									 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_ENTIDADEMANTENEDORA','DE_UF')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrDE_UF'>
									 	<td class='classTd' style='display:block' id='idclassTdDE_UF'>
										 	<div class='classLabel' style='display:block' id='idclassLabelDE_UF'>
													<!-- início na tela Entidademantenedora_Edit do label DE_UF -->
													UF
													<!-- fim na tela Entidademantenedora_Edit do label DE_UF -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdDE_UF'>
												<!-- início na tela Entidademantenedora_Edit do campo DE_UF -->
													<?php 
													//Montando o campo de select options com os seguintes dados.
													$tabela='cisternas_uf';
													$campoValor='SQ_CISTERNAS_UF';
													$CampoDescricao="DE_NOME";
													$clausulaWhere='  ';
													$valorSelecionado=$DE_UF;
													$nomeCampo='DE_UF';
													//para adicionar funções estilos etc.
													$parametrosAdicionais='';
													$sqlSelect= "SELECT ".$campoValor." as Valor, ".$CampoDescricao." as Descricao  FROM ".$tabela." ".$clausulaWhere." ";
													$respSelect = mysqlexecuta($conexao,$sqlSelect);
													//	Monta o select de acordo com os dados informados echo($sqlSelect);
													echo '<select  name="'.$nomeCampo.'" id="'.$nomeCampo.'" '.$parametrosAdicionais.' >';
														echo '<option value=""></options>';					
														while ($rowSelect = fnmysqli_fetch_array($respSelect)) { 
															//faz todo o loop consultando os campos.
															?>
																<option <?php 
																		
																		if($valorSelecionado==$rowSelect['Valor']){
																			echo 'selected';
																		}; ?> 
																value='<?php echo $rowSelect['Valor']; ?>'
																><?php echo $rowSelect['Descricao']; ?></option>
															<?php
														} //fim do while.
														?>
														</select>	
												<!-- fim na tela Entidademantenedora_Edit do campo DE_UF -->
											</div>
												
											</td>
										</tr>
										 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_ENTIDADEMANTENEDORA','NU_CEP')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrNU_CEP'>
									 		<td class='classTd' style='display:block' id='idclassTdNU_CEP'>
										 		<div class='classLabel' style='display:block' id='idclassLabelNU_CEP'>
														<!-- início na tela Entidademantenedora_Edit do label NU_CEP -->
														CEP
														<!-- fim na tela Entidademantenedora_Edit do label NU_CEP -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdNU_CEP'>

													<!-- início na tela Entidademantenedora_Edit do campo NU_CEP --> 
													
													<input class='classInput'  type='text' name='NU_CEP' 
															id='NU_CEP' 
															
															Width='-1'
															Height='-1'
															MaxLength='9'	
															Title='CEP'
															value='<?php echo $NU_CEP;?>'
															
							onkeydown="fnVerificaSeOCEPENumerico(this);"
							onKeyPress="funcoesGlobaisMascaraGeral('CEP',this,event);"
							onBlur="funcoesGlobaisFormataOnBlur('CEP',this);"
							 

														
															/>
															<!-- fim na tela Entidademantenedora_Edit do campo NU_CEP -->															
													</span>
												</td>
											</tr>
										 <tr class='classTr' style='display:<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_ENTIDADEMANTENEDORA','DE_TELEFONE')){ echo 'block';} else { echo 'none';}; ?>' id='idclassTrDE_TELEFONE'>
									 		<td class='classTd' style='display:block' id='idclassTdDE_TELEFONE'>
										 		<div class='classLabel' style='display:block' id='idclassLabelDE_TELEFONE'>
														<!-- início na tela Entidademantenedora_Edit do label DE_TELEFONE -->
														Telefone
														<!-- fim na tela Entidademantenedora_Edit do label DE_TELEFONE -->
												</div>
												<div class='classCampo' style='display:block' id='idclassCampoTdDE_TELEFONE'>

													<!-- início na tela Entidademantenedora_Edit do campo DE_TELEFONE --> 
													
													<input class='classInput'  type='PhoneNumber' name='DE_TELEFONE' 
															id='DE_TELEFONE' 
															
															Width='-1'
															Height='-1'
															MaxLength='15'	
															Title='Telefone'
															value='<?php echo $DE_TELEFONE;?>'
															 
							onKeyPress="return digitos(event, this);" 
							onKeyUp="funcoesGlobaisMascaraGeral('PhoneNumber',this,event);"
							onBlur="funcoesGlobaisFormataOnBlur('PhoneNumber',this);"
							 

														
															/>
															<!-- fim na tela Entidademantenedora_Edit do campo DE_TELEFONE -->															
													</span>
												</td>
											</tr><input 	
								type='hidden' 
								name='SQ_CISTERNAS_ENTIDADEMANTENEDORA' 
								id='SQ_CISTERNAS_ENTIDADEMANTENEDORA' 
								value='<?php echo $SQ_CISTERNAS_ENTIDADEMANTENEDORA; ?>'> <?php $_SESSION['RETORNO_Entidademantenedora_Edit']=fnTodosGtEPost(); ?>
													</td></tr>
													<tr><td>										
														
				<tr class='classTrButton'>		
					<td colspan=100% class='classtdButton'>
						<!--  Edit início do botão de envio -->
						<input class='btn btn-primary btn-sm mt-1' 	
								type='button' 
								<?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_ENTIDADEMANTENEDORA','btSubmit')){ echo '';} else { echo 'style="display:none"';}; ?>
								name='btSubmit' 
								title='Envia e aparece a tela de confirmação, inclusão de um único registro.'
								id='btSubmit'
								onClick='fnSubmit("N");'
								value='Enviar'	 											
								>	
								&nbsp;&nbsp;&nbsp;&nbsp;
						<!-- Edit fim do botão de envio  -->	
						<!-- Edit início do botão de envio e Novo  -->													
						<input class='btn btn-primary btn-sm mt-1' 
						       <?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_ENTIDADEMANTENEDORA','btSubmitEnviarENovo')){ echo '';} else { echo 'style="display:none"';}; ?>	
								type='button' 
								title='Envia e já volta para essa tela só com os campos que normalmente já são preenchidos repetidos para efetuar um novo cadastro.'
								name='btSubmitEnviarENovo' 
								id='btSubmitEnviarENovo'
								onClick='fnSubmit("S");'
								value='Enviar e Novo'	 											
								>	
								<input type=hidden value='N' id='IeNew' name='IeNew'/>
								 &nbsp;&nbsp;&nbsp;&nbsp;
						<!-- Edit fim do botão de envio e Novo -->	
						<!-- Edit início do botão de voltar -->															 
						 <input class='btn btn-primary btn-sm mt-1'  	
						 <?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_ENTIDADEMANTENEDORA','btVoltar')){ echo '';} else { echo 'style="display:none"';}; ?>
								type='button' 
								title='Volta a tela anterior.'
								name='btVoltar' 
								onClick='history.go(-1);'
								id='btVoltar' 
								value='Voltar'	 											
								>
						<!-- Edit fim do botão de voltar -->
						<!-- Edit início do botão de upload -->									
								<a  <?php if(fnAcessoCampoVisivel('SQ_CISTERNAS_ENTIDADEMANTENEDORA','btUploadVariosArquivos')){ echo '';} else { echo 'style="display:none"';}; ?>  href=# onClick='fnUploadArquivoParaBase("cisternas_entidademantenedora","#NO_FANTASIA#,#NU_CNPJ#,#DE_ENDERECO#,#DE_UF#,#NU_CEP#,#DE_TELEFONE#","#NO_FANTASIA# ,#NU_CNPJ# ,#DE_ENDERECO# ,#DE_UF# ,#NU_CEP# ,#DE_TELEFONE# ");'	>							
								<img src='images/upload.png' class='imgupload' title="Para subir arquivos um arquivo com vários registros é necessário deixar ele no formato que separe os campos por virgula. Não é necessário enviar cabeçalho, só precisa enviar a quantidade de títulos iguais ao dessa tela de inclusão e na mesma ordem dessa tela de inclusão, segue a orderm: ('Nome fantasia','CNPJ','Endereço','UF','CEP','Telefone')" >
								</a>
						<!-- Edit fim do botão de upload -->	
								
					</td>
				</tr>
													</td></tr>
													<tr><td colspan=100% >										
																												
													</td></tr>													
													<tr><td colspan=100% >										
																												
													</td></tr>
													<tr><td class='MensagemRodape' colspan=100%>
													<hr/>											
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>Entidade mantenedora<?php  }; ?>
													</td></tr>
												</table>
											</form>												
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "rodape.php"; 
			?> <?php  }; ?>											
											<form name='frmArquivo' action='uploadArquivoPg.php'>
												<input type=hidden value='' name='tabelaGravar'>
												<input type=hidden value='' name='strCabecalhoRegras'>
												<input type=hidden value='' name='strCabecalho'>
											</form>
											</body>
											</html>