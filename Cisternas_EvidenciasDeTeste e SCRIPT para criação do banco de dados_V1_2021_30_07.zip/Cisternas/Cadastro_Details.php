 			
											<?php
				session_start();
				$conexao='';
				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';
				?>
											<html> 

											<!--Início dos comandos sql na tela de detalhes --> 

											
											<?php					
					if (gt("SQ_CISTERNAS_CADASTRO")<>""){				
						//Faz a consulta no banco de dados na tabela para retornar a lista.
						$sqlp= "  SELECT tb1.SQ_CISTERNAS_CADASTRO,tb1.DT_DA_INAUGURACAO, tb1.DT_DA_INAUGURACAO,  cisternas_tipodeconstrucao.DE_NOME as NomeVinculado_TP_DE_CONSTRUCAO, tb1.DE_DOS_MATERIAIS,    CONCAT(cisternas_entidademantenedora.NU_CNPJ,'-', cisternas_entidademantenedora.NO_FANTASIA) as NomeVinculado_DE_ENTIDADE_MANTENEDORA, tb1.DE_LOCALIZACAO,  cisternas_uf.DE_NOME as NomeVinculado_DE_UF, tb1.DE_ENDERECO FROM cisternas_cadastro tb1 
												left join cisternas_tipodeconstrucao on cisternas_tipodeconstrucao.SQ_CISTERNAS_TIPODECONSTRUCAO=tb1.TP_DE_CONSTRUCAO
												left join cisternas_entidademantenedora on cisternas_entidademantenedora.SQ_CISTERNAS_ENTIDADEMANTENEDORA=tb1.DE_ENTIDADE_MANTENEDORA
												left join cisternas_uf on cisternas_uf.SQ_CISTERNAS_UF=tb1.DE_UF ".$CLAUSULAWHERE."  WHERE SQ_CISTERNAS_CADASTRO='".gt("SQ_CISTERNAS_CADASTRO")."'";

						$resp = mysqlexecuta($conexao,$sqlp);
	 
					}
				?>

											<!--Fim dos comandos sql na tela de detalhes --> 

											<link href='css/bootstrap.css' rel='stylesheet'><link href='_css_estiloGeral.css' rel='stylesheet'>

											<!--Início dos comandos em JavaScript na tela de detalhes --> 

											<!--AS JavaScript /AS-->

											<!--Fim dos comandos em JavaScript na tela de detalhes --> 

											<!--AS StrFormatacaoJQuery /AS-->
											<body id='idBody'>
											<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "menu.php"; 
			?> <?php  }; ?>
											<form id='formCadastro' name='formCadastro' action='CadastroDetails_banco.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'  method='POST'>
												<table class='clDetalhes'>
													<tr><td class='clTitulo' colspan=100%>
													<br/><br/>Cadastro
													</td></tr>
													<tr><td>
														<table>
															
															<?php while ($rowp = fnmysqli_fetch_array($resp)) { ?><tr class='classTr'>
															
																
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label DT_DA_INAUGURACAO -->
					Data da inauguração
					<!-- fim na tela Details do label DT_DA_INAUGURACAO -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo DT_DA_INAUGURACAO -->
					<?php echo $rowp['DT_DA_INAUGURACAO'];?>
					<!-- fim na tela Details do campo DT_DA_INAUGURACAO -->
				</td>
				</tr>
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label NomeVinculado_TP_DE_CONSTRUCAO -->
					Tipo de construção
					<!-- fim na tela Details do label NomeVinculado_TP_DE_CONSTRUCAO -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo NomeVinculado_TP_DE_CONSTRUCAO -->
					<?php echo $rowp['NomeVinculado_TP_DE_CONSTRUCAO'];?>
					<!-- fim na tela Details do campo NomeVinculado_TP_DE_CONSTRUCAO -->
				</td>
				</tr>
				<tr class=	'classTrList'>
					<td class='clCampoListDetalhes'>
						<!-- início na tela Details do label DE_DOS_MATERIAIS -->
						Descrição dos materiais
						<!-- fim na tela Details do label DE_DOS_MATERIAIS -->
					</td>
					
					<td class=clCampoDetalhes>
						<!-- início na tela Details do campo DE_DOS_MATERIAIS -->
						<?php echo fnDecode($rowp['DE_DOS_MATERIAIS']);?>
						<!-- fim na tela Details do campo DE_DOS_MATERIAIS -->
					</td>
				</tr>
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label NomeVinculado_DE_ENTIDADE_MANTENEDORA -->
					Entidade mantenedora
					<!-- fim na tela Details do label NomeVinculado_DE_ENTIDADE_MANTENEDORA -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo NomeVinculado_DE_ENTIDADE_MANTENEDORA -->
					<?php echo $rowp['NomeVinculado_DE_ENTIDADE_MANTENEDORA'];?>
					<!-- fim na tela Details do campo NomeVinculado_DE_ENTIDADE_MANTENEDORA -->
				</td>
				</tr>
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label DE_LOCALIZACAO -->
					Localização GPS
					<!-- fim na tela Details do label DE_LOCALIZACAO -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo DE_LOCALIZACAO -->
					<?php echo $rowp['DE_LOCALIZACAO'];?>
					<!-- fim na tela Details do campo DE_LOCALIZACAO -->
				</td>
				</tr>
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label NomeVinculado_DE_UF -->
					UF
					<!-- fim na tela Details do label NomeVinculado_DE_UF -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo NomeVinculado_DE_UF -->
					<?php echo $rowp['NomeVinculado_DE_UF'];?>
					<!-- fim na tela Details do campo NomeVinculado_DE_UF -->
				</td>
				</tr>
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label DE_ENDERECO -->
					Endereço
					<!-- fim na tela Details do label DE_ENDERECO -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo DE_ENDERECO -->
					<?php echo $rowp['DE_ENDERECO'];?>
					<!-- fim na tela Details do campo DE_ENDERECO -->
				</td>
				</tr>
																
															
														</table>
													</td></tr>
													<tr><td>	

													<!--Início dos botoes na tela detalhes -->

													<?php 
			   //início verificar se tem acesso aos eventos.
			   if(fnAcesso('Cadastro_eventos_log_List.php')){ ?>
				<input type='button' name='idVerEventos' style='display:block' class='btn btn-primary btn-sm mt-1' title='Ver todos os eventos e datas que foram feitos.' id='idVerEventos' value='Ver todos eventos' onClick='window.location="Cadastro_eventos_log_List.php?SQ_CISTERNAS_CADASTRO=<?php echo $rowp['SQ_CISTERNAS_CADASTRO']; ?>";'/>
				<?php } 
				//fim verificar se tem acesso aos eventos. 
				?> 													
													
													<!--Fim dos botoes na tela detalhes -->

													</td></tr>
													<tr><td class=MensagemRodape colspan=100%>
													<hr/>
														
													<!--Início MensagemRodape na tela detalhes -->	

													<?php if (gt("TelaVinculada")<>"SIM"){ ?>Cadastro<?php  }; ?>

													<!--Fim MensagemRodape na tela detalhes -->

													</td></tr>
												</table>
											</form>										
											</body>
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "rodape.php"; 
			?> <?php  }; ?>	
											<?php  }; //fim do while ?>
											</html>