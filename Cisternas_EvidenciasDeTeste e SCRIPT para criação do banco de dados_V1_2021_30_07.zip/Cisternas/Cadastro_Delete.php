 			
											<?php
				session_start();
				$conexao='';
				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';
				?>
											<html> 											
											 <?php 


				      //Faz a exclusão dos dados no banco de dados diretamente.
				      $sqlp= " Delete from cisternas_cadastro  where SQ_CISTERNAS_CADASTRO=".gt('SQ_CISTERNAS_CADASTRO');
					  $resp = mysqlexecuta($conexao,$sqlp);


				?>
											<link href='css/bootstrap.css' rel='stylesheet'><link href='_css_estiloGeral.css' rel='stylesheet'>
											
											<!--Início dos comandos em JavaScript na tela de Delete --> 

											<!--AS JavaScript /AS-->

											<!--Fim dos comandos em JavaScript na tela de Delete -->

											<body id='idBody'>
											<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "menu.php"; 
			?> <?php  }; ?>
											<form id='formCadastro' name='formCadastro' action='CadastroDelete_banco.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'  method='POST'>
												<table class='clDetalhes'>

													<tr><td class='clTitulo' colspan=100%>
													<br/><br/>Cadastro
													</td></tr>
													<tr><td>Registro excluído com sucesso.										
													
				<!-- Início do botão de voltar no delete -->
									<input  class='btn btn-primary btn-sm mt-1' 	
								type='button' 
								name='btVoltar' 
								onClick='history.go(-1);'
								id='btVoltar' 
								value='Voltar'	 											
								>
					<!-- Fim do botão de voltar no delete -->
			
													</td></tr>
													<tr><td class=MensagemRodape colspan=100%>
													<hr/>											
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>Cadastro<?php  }; ?>
													</td></tr>
												</table>
											</form>										
											</body>
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "rodape.php"; 
			?> <?php  }; ?>	
											</html>