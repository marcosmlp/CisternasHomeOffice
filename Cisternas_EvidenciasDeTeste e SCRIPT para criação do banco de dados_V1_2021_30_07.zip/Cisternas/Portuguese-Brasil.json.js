{
    "sEmptyTable": "Nenhum registro encontrado",
    "sInfo": "Mostrando de _START_ at� _END_ de _TOTAL_ registros",
    "sInfoEmpty": "Mostrando 0 at� 0 de 0 registros",
    "sInfoFiltered": "(Filtrados de _MAX_ registros)",
    "sInfoPostFix": "",
    "sInfoThousands": ".",
    "sLengthMenu": "_MENU_ resultados por p�gina",
    "sLoadingRecords": "Carregando...",
    "sProcessing": "Processando...",
    "sZeroRecords": "Nenhum registro encontrado",
    "sSearch": "Pesquisar",
    "oPaginate": {
        "sNext": "Pr�ximo",
        "sPrevious": "Anterior",
        "sFirst": "Primeiro",
        "sLast": "�ltimo"
    },
    "oAria": {
        "sSortAscending": ": Ordenar colunas de forma ascendente",
        "sSortDescending": ": Ordenar colunas de forma descendente"
    }
}