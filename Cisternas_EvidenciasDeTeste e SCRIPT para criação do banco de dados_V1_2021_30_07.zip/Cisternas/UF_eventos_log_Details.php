 			
											<?php
				session_start();
				$conexao='';
				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';
				?>
											<html> 

											<!--Início dos comandos sql na tela de detalhes --> 

											
											<?php					
					if (gt("SQ_CISTERNAS_UF_EVENTOS_LOG")<>""){				
						//Faz a consulta no banco de dados na tabela para retornar a lista.
						$sqlp= "  SELECT tb1.SQ_EVENTOS_LOG,tb1.DESCRICAO_DO_EVENTO_EM_EVENTOS_LOG,tb1.DT_DO_EVENTO_EM_EVENTOS_LOG, tb1.SQ_CISTERNAS_UF,tb1.DE_NOME, tb1.DE_NOME, tb1.NO_COMPLETO FROM cisternas_uf_eventos_log tb1  ".$CLAUSULAWHERE."  WHERE SQ_CISTERNAS_UF_EVENTOS_LOG='".gt("SQ_CISTERNAS_UF_EVENTOS_LOG")."'";

						$resp = mysqlexecuta($conexao,$sqlp);
	 
					}
				?>

											<!--Fim dos comandos sql na tela de detalhes --> 

											<link href='css/bootstrap.css' rel='stylesheet'><link href='_css_estiloGeral.css' rel='stylesheet'>

											<!--Início dos comandos em JavaScript na tela de detalhes --> 

											<!--AS JavaScript /AS-->

											<!--Fim dos comandos em JavaScript na tela de detalhes --> 

											<!--AS StrFormatacaoJQuery /AS-->
											<body id='idBody'>
											<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "menu.php"; 
			?> <?php  }; ?>
											<form id='formUF' name='formUF' action='UF_eventos_logDetails_banco.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'  method='POST'>
												<table class='clDetalhes'>
													<tr><td class='clTitulo' colspan=100%>
													<br/><br/>UF
													</td></tr>
													<tr><td>
														<table>
															
															<?php while ($rowp = fnmysqli_fetch_array($resp)) { ?><tr class='classTr'>
															
																
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label DE_NOME -->
					Nome
					<!-- fim na tela Details do label DE_NOME -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo DE_NOME -->
					<?php echo $rowp['DE_NOME'];?>
					<!-- fim na tela Details do campo DE_NOME -->
				</td>
				</tr>
				<tr  class='classTrList'>
					<td class='clCampoListDetalhes'>
					<!-- início na tela Details do label NO_COMPLETO -->
					Nome completo
					<!-- fim na tela Details do label NO_COMPLETO -->
				</td>
					<td class=clCampoDetalhes>
					<!-- início na tela Details do campo NO_COMPLETO -->
					<?php echo $rowp['NO_COMPLETO'];?>
					<!-- fim na tela Details do campo NO_COMPLETO -->
				</td>
				</tr>
																
															
														</table>
													</td></tr>
													<tr><td>	

													<!--Início dos botoes na tela detalhes -->

													<?php 
			   //início verificar se tem acesso aos eventos.
			   if(fnAcesso('UF_eventos_log_List.php')){ ?>
				<input type='button' name='idVerEventos' style='display:none' class='btn btn-primary btn-sm mt-1' title='Ver todos os eventos e datas que foram feitos.' id='idVerEventos' value='Ver todos eventos' onClick='window.location="UF_eventos_log_List.php?SQ_CISTERNAS_UF_EVENTOS_LOG=<?php echo $rowp['SQ_CISTERNAS_UF_EVENTOS_LOG']; ?>";'/>
				<?php } 
				//fim verificar se tem acesso aos eventos. 
				?> 													
													
													<!--Fim dos botoes na tela detalhes -->

													</td></tr>
													<tr><td class=MensagemRodape colspan=100%>
													<hr/>
														
													<!--Início MensagemRodape na tela detalhes -->	

													<?php if (gt("TelaVinculada")<>"SIM"){ ?>UF<?php  }; ?>

													<!--Fim MensagemRodape na tela detalhes -->

													</td></tr>
												</table>
											</form>										
											</body>
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "rodape.php"; 
			?> <?php  }; ?>	
											<?php  }; //fim do while ?>
											</html>