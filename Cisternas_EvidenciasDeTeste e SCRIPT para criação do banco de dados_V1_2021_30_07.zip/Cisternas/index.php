<?php include_once 'menu.php'; ?>
                         <div class="carousel-centered">
                            <div class="margin-b-40">
                                <h1 class="carousel-title">Sistema Cisternas</h1>
                                <p> Para cadastros e consultas.</p>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="item">
                    <img class="img-responsive" src="layoutAssentus/img/1920x1080/01.jpg" alt="Slider Image">
                    <div class="container">
                        <div class="carousel-centered">
                            <div class="margin-b-40">
                                <h2 class="carousel-title">Cisternas</h2>
                                <p>.</p>
                            </div>
                            
                        </div>

			<?php if (gt('TelaVinculada')<>'SIM'){ ?>	
			<?php			
				include_once 'rodape.php'; 
			?> <?php  }; ?>											

    </body>
    <!-- END BODY -->
</html>