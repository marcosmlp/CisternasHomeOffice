  			
		<?php
				session_start();
				$mostrarLogs='NAO';
				$CLAUSULAWHERE='';
				include_once '_funcoesGlobais.php';
				include_once '_conexaoBanco.php';
				//NESSA PÁGINA QUE SOBE OS ARQUIVOS E FAZ O INSERT NA BASE 
				//fnAjustarArquivoInsert($tabelaGravar,$fileName,$fileNamePadrao,$Delimitador,$totalDelimitadorPorLinha,$strCabecalho,$NAOaceitaLinhaEmbranco)
				?>
											<html>  											
											<?php
				//se for alteração pega esse campo, se for vinculação também pega esse campo.			
				 $tabelaGravar= gt("tabelaGravar");				
				 $fileName= gt("fileName");
				 $fileNamePadrao= gt("fileNamePadrao");	
				 $Delimitador= gt("Delimitador");	
				 $totalDelimitadorPorLinha= gt("totalDelimitadorPorLinha");	
				 $strCabecalho= gt("strCabecalho");	
				 $strCabecalhoRegras= gt("strCabecalhoRegras");	
				 //tem que ter o campo aceita.
				 $NAOaceitaLinhaEmbranco= gt("NAOaceitaLinhaEmbranco");	
				 
				//se estiver dando apenas um refresh na tela, então envia esse campo informando, para não apagar os dados já preenchidos.
				$RETORNO_CAMPOS_SQ_SEFAZ_TIPODEIMPOSTOS= gt("RETORNO_CAMPOS_SQ_SEFAZ_TIPODEIMPOSTOS");
				// PODE SER UM RELOAD OU BACK NA PRÓPIA PÁGINA.
				if ($fileName<>""){	
				
					include "funcoes/Upload.class.php";
					
				
			
			
			//*********************TEMINA UPLOAD DO ARQUIVO*********************//
	
					if (! empty($_FILES['flArquivo'])){
						$upload = new UploadFile($_FILES['flArquivo'], 1000, 800, "upload/");
						$no_arquivo = $upload->salvar();
						echo $no_arquivo;
						$fileName = $no_arquivo;
						$fileNamePadrao = $no_arquivo;
						//formata o arquivo e envia para o servidor.
						$sqlInsertArquivo=fnAjustarArquivoInsert($tabelaGravar,$fileName,$fileNamePadrao,$Delimitador,$totalDelimitadorPorLinha,$strCabecalho,$NAOaceitaLinhaEmbranco,$strCabecalhoRegras);	
						
						if($sqlInsertArquivo<>''){
							$resp = mysqlexecuta($conexao,$sqlInsertArquivo);
							echo $sqlInsertArquivo;
							"<script> alert('Carga finalizada.');</script>";
						}
						
						//	echo "Arquivo salvo com sucesso.";
					} else {
						echo "Nenhum arquivo para efetuar a carga.";
					}

		
								
				} else {		
					//ainda não escolheu o arquivo nem o tipo de separador dos campos.
					//echo ".";
				}
				?>
<link href='css/bootstrap.css' rel='stylesheet'><link href='_css_estiloGeral.css' rel='stylesheet'>
												
			<script language=javaScript> 
				function fnSubmit(IeNew){					 
					document.formTipodeImpostos.fileName.value=document.formTipodeImpostos.flArquivo.name;
					if(document.formTipodeImpostos.fileName.value!=''){
						//Para validar se já quer voltar para tela de inclusão novamente para preencher os dados novamente.
						document.formTipodeImpostos.IeNew.value=IeNew;					
						document.formTipodeImpostos.submit();	
					} else {
						fnMensagem("Tem que subir o arquivo antes de solicitar a carga.");
						document.formTipodeImpostos.flArquivo.focus();
						return false;
					};
				};
			</script> 				
			<script language=javaScript> 
				function fnValidaCampo(campo,Mensagem,TipoDeValidacao,TipoDeCampo){
					if (TipoDeCampo='text'){
							if (campo.value==0){
								fnMensagem(Mensagem);
								campo.focus();
								return false;
							}
						}
					return true;
				}
			    function fnExcluir(LinkExclusao,MensagemPergunta){
					var retorno = confirm(MensagemPergunta);
					if (retorno){
						window.location=LinkExclusao;
						return true;
					} else {
						return false;
					}
				}
			    function fnAlterar(LinkAlteracao){
 					window.location=LinkAlteracao;
				}				
				function fnMensagem(Mensagem){
					//assim pode mudar em apenas um lugar e colocar em um div, ou no topo da página como o cliente desejar alterando só nesse arquivo.
					alert(Mensagem);
				}
	
			</script> 
					<!--AS JavaScript /AS-->
											<script language=javaScript></script>
											<body>
											<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "menu.php"; 
			?> <?php  }; ?>
								<form id='formTipodeImpostos'  enctype='multipart/form-data' name='formTipodeImpostos' action='uploadArquivoPg.php?TelaVinculada=<?php echo gt("TelaVinculada"); ?>'  method='POST'>
												<table class='clDetalhesIncluir'>
													<tr><td class='clTitulo' colspan=100%>
														<br/><br/>UPLOAD para carregar os dados de um arquivo no servidor de bando de dados.
													</td></tr>
													<tr><td>
														
									<tr>
										<td class='classLabel'>Descrição da carga.</td>
										<td><textarea 
													name='DE_DESCRICAO'
													class='classInput'
													
													id='DE_DESCRICAO'
													cols='-1'
													rows='-1'
													MaxLenght='100'><?php echo $DE_DESCRICAO;?></textarea>
   
										</td>
									</tr>				
									<tr>
										<td class='classLabel'>Tipo do separador dos campos</td>
										<td>
											<input class='classInput'  type='text' name='DE_NCM' 
													id='DE_NCM' 
													
													Width='-1'
													Height='-1'
													MaxLenght='100'	
													value=';'	 											
													>
													<input class='classInput'  type='hidden' name='tabelaGravar' 
													id='tabelaGravar' 
													value='<?php echo $tabelaGravar;?>'	 											
													>
										</td>
									</tr>
									<tr>
										<td class='classLabel'>Nome do arquivo</td>
										<td>
											<input class='classInput'  type='file' name='flArquivo' 
													id='flArquivo' onblur='document.getElementById["fileName"].value=document.getElementById["flArquivo"].value;'
													value='Procurar'	 											
													>
													<input  type='hidden' name='tabelaGravar' id='tabelaGravar' value='<?php echo $tabelaGravar;?>'	 />
													<input  type='hidden' name='fileName' id='fileName' value='<?php echo $fileName;?>'	 />
													<input  type='hidden' name='fileNamePadrao' id='fileNamePadrao' value='<?php echo $fileNamePadrao;?>'	 />
													<input  type='hidden' name='totalDelimitadorPorLinha' id='totalDelimitadorPorLinha' value='<?php echo $totalDelimitadorPorLinha;?>'	 />
													<input  type='hidden' name='strCabecalho' id='strCabecalho' value='<?php echo $strCabecalho;?>'	 />
													<input  type='hidden' name='NAOaceitaLinhaEmbranco' id='NAOaceitaLinhaEmbranco' value='<?php echo $NAOaceitaLinhaEmbranco;?>'	 />
													<input  type='hidden' name='strCabecalhoRegras' id='strCabecalhoRegras' value='<?php echo $strCabecalhoRegras;?>'	 />
													
													
										</td>
									</tr>									
																		
														
				<tr>		
					<td colspan=100%>
						<input class='botao' 	
								type='button' 
								name='btSubmit' 
								id='btSubmit'
								onClick='fnSubmit("N");'
								value='Efetuar carga no servidor'	 											
								>	
								&nbsp;&nbsp;&nbsp;&nbsp;
			
								<input type=hidden value='N' id='IeNew' name='IeNew'/>
  							   &nbsp;&nbsp;&nbsp;&nbsp;
									<input class='botao' 	
								type='button' 
								name='btVoltar' 
								onClick='history.go(-1);'
								id='btVoltar' 
								value='Voltar'	 											
								>
				
								
					</td>
				</tr>
													</td></tr>
													<tr><td colspan=100% >										
														
													</td></tr>
													<tr><td class='MensagemRodape' colspan=100%>
													<hr/>											
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>Efetua a carga de um arquivo na tabela do banco de dados.<br/>
													Para subir arquivos um arquivo com vários registros é necessário deixar ele no formato que separe os campos por virgula ou pelo delimitador informado no campo (Tipo do separador dos campos).<br/>
													Não é necessário enviar cabeçalho, só precisa enviar a quantidade de títulos iguais ao da tela de inclusão.<br/>
													Os campos tem que estar na mesma ordem da tela de inclusão.<br/>
													Exemplo de uma linha de um layout como o aquivo deve ser enviado,trocar os nomes por dados:<br/>
													<?php  
														echo str_replace("#","'",$strCabecalho);		
													}; ?>
													</td></tr>
												</table>
											</form>	
													<?php if (gt("TelaVinculada")<>"SIM"){ ?>	
			<?php			
				include_once "rodape.php"; 
			?> <?php  }; ?>											
											</body>
											</html>