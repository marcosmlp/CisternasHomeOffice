<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<script type="text/javascript" src="/ckeditor/ckeditor.js"></script>
<?php
/************************************************************************************************************************************************************************************************************************************* 
 
	* INICÍO DAS FUNÇÕES EM PHP

************************************************************************************************************************************************************************************************************************************ */

//PREENCHE NO RODAPÉ ESSA FUNÇÃO E SE TIVER INSERT OU DELETE OU UPDATE FAZ UMA VEZ E LIMPA A SESSÃO PARA SÓ EXECUTAR UMA VEZ ESSE COMANDO NA PÁGINA.
function fnSegurancaPost(){
	
		$mystring = strtolower($_SERVER["REQUEST_URI"]);
		$findme   = '_banco.php';
		$pos = strpos($mystring, $findme);

		// Note o uso de ===.  Simples == não funcionaria como esperado
		// se não tiver a palavra select então é um insert update ou delete, lógico que tem insert com select mas não nesse código.
		if ($pos === false) {
			//só deixa incluir ou atualizar uma vez e via post da página anterior e se não estiver na página que acessa o banco de dados.
			$_SESSION["HTTP_HOST_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["HTTP_HOST"];	
			$_SESSION["REQUEST_URI_ATUAL_REQUISICAO_SEGURANCA"]=$_SERVER["REQUEST_URI"];
		};
	
}; 

//PEGA O IP DO CLIENTE
function get_client_ip() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
		$ipaddress = 'INTERNET';
	if (trim($ipaddress) == ''){
		$ipaddress = 'INTERNET';
	}
	if (isset($_SESSION['EMAIL_USUARIO_LOGADO'])){
		if (trim($_SESSION['EMAIL_USUARIO_LOGADO'])!=""){
			$ipaddress ='</br> Responsável logado: '.$_SESSION['EMAIL_USUARIO_LOGADO'];
		}
	}
	
    return $ipaddress;
}
//**********************************************************************************************************************************************************************************************
// INÍCIO funções de HORA E DATA soma as horas e minutos até meia noite e passando para o outro dia retorna "00:00:00" pois ai a consulta já será marcada no outro dia.
//**********************************************************************************************************************************************************************************************
	
function fnSomaHora($horainicial,$horaSomar){
	$horainicialArray=explode(":",$horainicial);
	$horaSomarArray=explode(":",$horaSomar);
	$segundos=intval($horaSomarArray[2])+intval($horainicialArray[2]);
	$minutos=0;
	if ($segundos>=60){
		$segundos=$segundos-60;
		$minutos=1;
	};
	$minutos=intval($minutos)+intval($horaSomarArray[1])+intval($horainicialArray[1]);
	$horas=0;
	if ($minutos>=60){
		$minutos=$minutos-60;
		$horas=1;
	};	
	$horas=intval($horas)+intval($horaSomarArray[0])+intval($horainicialArray[0]);
	$dia=0;
	if ($horas>24){
		$horas=$horas-24;
		$dia=1;
	};	
	//até passar para o outro dia, influencia no loop onde é chamado essa função só para se chegar nesse ponto.
	if($dia==1){
		return "00:00:00";
	} else {
		return fnCompletazero($horas).":".fnCompletazero($minutos).":".fnCompletazero($segundos);	
	}
};	

//se a hora final for maior ou igual a hora atual retorna verdadeiro se for menor retorna falso.
function fnComparaHora($horainicial,$horafinal){
	$horainicialArray=explode(":",$horainicial);
	$horafinalArray=explode(":",$horafinal);
	
	if ( intval($horafinalArray[0])> intval($horainicialArray[0])){
		return true;
	} else {
		if (intval($horafinalArray[0])==intval($horainicialArray[0]) && intval($horafinalArray[1])>intval($horainicialArray[1]) ){
			return true;
		} else{
			if (intval($horafinalArray[0])==intval($horainicialArray[0]) && intval($horafinalArray[1])==intval($horainicialArray[1]) && intval($horafinalArray[2])>intval($horainicialArray[2])  ){				
				return true;
			} else {
				if (intval($horafinalArray[0])==intval($horainicialArray[0]) && intval($horafinalArray[1])==intval($horainicialArray[1]) && intval($horafinalArray[2])==intval($horainicialArray[2])  ){				
						return true;
				} else {
					return false;
				}
			}
		}
	}
		
};

//completa com zero a esquerda.
function fnCompletazero($tempo){
	if(strlen(trim($tempo))==1){
		return "0".trim($tempo);
	} else {
		return $tempo;
	};
};

function fnCopiar($fileName,$fileNameDestino){
	
	//COPIA E CRIA OS DIRETÓRIOS.
	$diretorio1=$fileName;
	//"C:\_sistemas\SIDES\implantacao\models\TESTE2\TSX.PHP";
    $DirDestino=substr($diretorio1,0,strripos($diretorio1,"/") );
	$nomeDoArquivo=str_replace($DirDestino,"",$diretorio1);
	$retorno =true;
	if(is_dir($DirDestino))
	{
		//echo "A Pasta Existe";
	}
	else
	{
		if(!mkdir($DirDestino, 0777, true)){
			//die('<br>Erro ao criar o diretório de destino:'.$DirDestino);
	              echo "<br>O diretório não foi criado, verificar as permissões da pasta.";		
				  $retorno =false;
			} else{
				//echo "<br>Foi o diretório criado:";			
			//	echo $DirDestino;
			}
	}		

		//abre o arquivo ATUAL  SÓ QUE COM O NOME CORRETO DELE QUE NÃO EXISTE SÓ PARA ADICIONAR O NOME AO ARQUIVO.
		$arquivoAtual = fopen($fileName, "rb");
			//			echo "<br>teste123abre o arquivr:<br>";		
	//le os dados do arquivo ATUAL .
		$strAtual = @fread($arquivoAtual, 99999999);
							//	echo "<br>teste1234abre o arquivr:<br>";		
		//echo("<br>Salvando o arquivo<br/><textarea>".$strAtual."</textarea>");	
	    $arquivoDestino = fopen($fileNameDestino, "w");
		//salva o arquivo no novo diretório.
		fwrite($arquivoDestino,$strAtual);	
	//	echo("<iframe src='".$fileName."'></iframe>");
		//TIRA ELE DA MEMÓRIA DO COMPUTADOR.
		fclose($arquivoAtual);
		//TIRA ELE DA MEMÓRIA DO COMPUTADOR.
		fclose($arquivoDestino);	

	   return $retorno;
}

function fnCriarArquivoComEsseTexto($fileName,$textoCompleto){

	$diretorio1=$fileName;
	//"C:\_sistemas\SIDES\implantacao\models\TESTE2\TSX.PHP";
    $DirDestino=substr($diretorio1,0,strripos($diretorio1,"/") );
	$nomeDoArquivo=str_replace($DirDestino,"",$diretorio1);
	
	if(!file_exists($DirDestino)) {
		if(!mkdir($DirDestino, 0777, true)){

		//die('<br>Erro ao criar o diretório de destino:'.$DirDestino);

		} else{
		echo $DirDestino;
		echo "<br>Foi o diretório criado para o arquivo:";
		echo $nomeDoArquivo;
		}

	}	   // $fp = @fopen($file, "rb"); 			
		//abre o arquivo ATUAL  SÓ QUE COM O NOME CORRETO DELE QUE NÃO EXISTE SÓ PARA ADICIONAR O NOME AO ARQUIVO.
		$arquivoAtual = @fopen($fileName, "w");
		//le os dados do arquivo ATUAL .
		$strAtual = @fread($arquivoAtual, 99999999);
		echo("<br>Salvando o arquivo<br/><textarea>".$textoCompleto."</textarea>");	
		//salva o arquivo
		fwrite($arquivoAtual,$textoCompleto);	
		echo("<iframe src='".$fileName."'></iframe>");
		//TIRA ELE DA MEMÓRIA DO COMPUTADOR.
		fclose($arquivoAtual);
	


return "Alterado com sucesso";
}

function fnTodosGtEPost(){
	$retorno="";
	foreach ($_POST as $campo => $valor) { 
	 $retorno.= $campo."=".$valor."&";
	}
	foreach ($_GET as $campo => $valor) { 
	 $retorno.= $campo."=".$valor."&";
	}
	return $retorno;
}

//RECEBE A INFORMAÇÕES E NÃO DÁ ERRO, E JÁ IMPEDE ATAQUE HACKER PARA ACESSAR AS TABELAS.
function gt($Param){
	$Dados="";
	if (isset($_POST[$Param])){
		$Dados=$_POST[$Param];		
	} else {
		if (isset($_GET[$Param])){
			$Dados=$_GET[$Param];		
		} else {
			$Dados="";
		}
	}
	return $Dados;
}	

function gtChat($Param){
	$Dados="";
	if (isset($_GET[$Param])){
		$Dados=$_GET[$Param];		
	};
	if (trim($Dados)==""){
		if (isset($_POST[$Param])){

			$Dados=$_POST[$Param];		
		} else {
			$Dados="";
		}
	}
	return $Dados;
}	
/*	//PROTEJE A APLICAÇÃO DE ATAQUES DE HACKER.
 //  $Dados = preg_replace(sql_regcase("/(from|select|create table|alter table|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"), "" ,$Dados);
   $Dados = trim($Dados);
   $Dados = strip_tags($Dados);
   $Dados = (get_magic_quotes_gpc()) ? $Dados : addslashes($Dados);
   return $Dados;	*/

function fnBusca($mystring,$findme){
  //  $mystring = 'abc';
  //  $findme   = 'a';
    $pos = strpos($mystring, $findme);

    // Note o uso de ===.  Simples == não funcionaria como esperado
    // por causa da posição de 'a' é 0 (primeiro) caractere.
    if ($pos === false) {
       // echo "A string '$findme' não foi encontrada na string '$mystring'";
        $posicao=-1;
    } else {
       // echo "A string '$findme' foi encontrada na string '$mystring'";
       // echo " e existe na posição $pos";
       $posicao=$pos;
    }
   return $posicao;
}


function pfnBuscarEntre($strTotal,$strInicial,$strFinal){
					if (($strTotal=='')||($strInicial=='')||($strFinal=='')){
						$strNova='';
					} else {											
						$strNova=substr ( $strTotal , stripos($strTotal,$strInicial), strlen($strTotal) );
						//	echo "<br>strNova<br>";
	//echo $strNova;
//	echo "<br>strInicial<br>";
//	echo stripos($strTotal,$strInicial);
						
						$strNova=substr($strNova,strlen($strInicial),stripos($strNova,$strFinal)-strlen($strInicial));
					}

			return $strNova;
}
function fnBuscarValorDaArray($posicao,$arrayP){
	return pfnBuscarEntre($arrayP,$posicao."=",";");

}
//RECEBE A INFORMAÇÕES E NÃO DÁ ERRO, E JÁ IMPEDE ATAQUE HACKER PARA ACESSAR AS TABELAS.
function  fnBLOQUEARSQLINJECTION($Param){
	   $Dados=$Param;
	   $Dados=str_replace(" from ","",$Dados);
	   $Dados=str_replace(" select ","",$Dados);
	   $Dados=str_replace("create table","",$Dados);	   
	   $Dados=str_replace("alter table","",$Dados);
	   $Dados=str_replace("insert","",$Dados);
	   $Dados=str_replace("drop","",$Dados);
	   $Dados=str_replace("delete","",$Dados);	 
	   $Dados=str_replace("drop table","",$Dados);		 
	   $Dados=str_replace("show tables","",$Dados);		 
	   $Dados=str_replace("where","",$Dados);		 
	 //  $Dados=str_replace("'","",$Dados);	 		 
	   $Dados=str_replace('"','',$Dados);		 		 
	   $Dados=str_replace('--','',$Dados);			 		 
	   $Dados=str_replace('\\','',$Dados);	  
	   
	   return $Dados;
}
function fnAcesso($Param){
	if ($_SESSION['PERFILADMINISTRADOR_SISTEMA_INTEIRO']=="SIM"){
		///Se for para todos ficarem visiveis tirar isso ao mandar para produçao
		return true;
	};
	//GCPHP/sistemas/ChatBot/
	// echo $_SERVER["REQUEST_URI"];
	$pagina=$_SERVER["REQUEST_URI"];
	//echo basename(__FILE__);
	$pagina=substr($pagina,0,strpos($pagina,".php")+4);
	$pagina=substr($pagina,strripos($pagina,"/")-strlen($pagina)+1);
	//$pagina=substr($pagina,0,strpos($pagina,".php")+4);
	//echo $pagina;
	//GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /geradorDe
	//echo $_SERVER['PATH'];
	//paginas que podem acessar sem login
	//$_SESSION=['PERFIL']=$_SESSION['PERFIL']
	$pagirnasquetemAcesso = "#testes##".$_SESSION['PERFIL'].'##login_banco.php#ClinicasTodas_List.php#Anamnese_EditPre.php#AnamneseEdit_banco.php#ClienteM1_Edit.php#ClienteEditM1_banco.php#Cliente_EditPrimeiroAcesso.php#ClienteEdit_banco.php#Cliente_Edit.php#Cliente_Edit.php#loginEspecial.php#login_banco_EscolhePerfil.php#ClinicasEdit_banco.php#Clinicas_Edit.php#loginRecuperarSenha.php#loginRecuperarSenha_banco.php#loginRecuperarSenhaEnviar.php#loginRecuperarSenhaEnviarServidor.php#login.php#Agenda_Edit.php#AgendaEdit_banco.php#index.php#chatWhatsAppMeio.php#chatWhatsApp.php#chatWhatsAppL.php##EnvioPagamentoPagSeguroLimpo.php#';
	$resultadoDaBusca=strpos(strtoupper($pagirnasquetemAcesso),strtoupper("#".$pagina."#"));
	if ($resultadoDaBusca>-1){
		//se achou está autorizado.
		//ai faz uma busca mostrando os campos que tem acesso.
		//campo tem o nome assim idclassTrDE_NOME e são escondidos na função na página rodapé com o nome fnCamposInvisiveis(); e cadastrado nas configurações com o nome:
	} else{
		//se não encontrou essa página no servidor, não pode navegar nela.
		echo "

		<script>
			window.location = 'login.php';
		</script>
		"	;
		//	exit();
		return false;
		
	}
    //se estiver no perfil visivel então mostra, aqui tem a página mas não pode ver algumas funcionalidades dela.
	//echo $Param;
	//echo $_SESSION["PERFIL"];
   IF (strpos(strtoupper($_SESSION['PERFIL']),strtoupper("#".$Param."#"))>-1){
	   //não mostra.
	  // echo "entrou aqui";
	   return true;
   } else{
		//se o menu não estiver no perfil então não mostra, na prática nem usa pois usamos um perfil não logado para quem não faz o login, isso é só se não tiver esse perfil algo bem especifico.
	   IF (strpos(strtoupper($_SESSION['PERFIL_INVISIVEL']),strtoupper("#".$Param."#"))>-1){
		   //não mostra.
		   return false;
	   };
   };
   //
};
function fnSubstituirTudo($str){
    $str=str_replace('=','KhrefIGUAL',$str);
    $str=str_replace('DOCTYPE','KDOCTIGUAL',$str);
    $str=str_replace('<','KmenorTIGUAL',$str);
    $str=str_replace('>','KmaiorTIGUAL',$str);
    return $str;
}
function fnAcessoCampoVisivel($sq,$Param){
	//if ($_SESSION['PERFILADMINISTRADOR_SISTEMA_INTEIRO']=="SIM"){
		///Se for para todos ficarem visiveis tirar isso ao mandar para produçao
	//	return true;
	//};
	//GCPHP/sistemas/ChatBot/
	// echo $_SERVER["REQUEST_URI"];
	$pagina=$_SERVER["REQUEST_URI"];
	//echo basename(__FILE__);
	$pagina=substr($pagina,0,strpos($pagina,".php")+4);
	$pagina=substr($pagina,strripos($pagina,"/")-strlen($pagina)+1);
	//$pagina=substr($pagina,0,strpos($pagina,".php")+4);
	//echo $pagina;
	//GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /GCPHP/sistemas/ChatBot/ /geradorDe
	//echo $_SERVER['PATH'];
	//paginas que podem acessar sem login
	//$_SESSION=['PERFIL']=$_SESSION['PERFIL']
	
	if (gt($sq)==""){
		$pagirnasquetemAcesso = "#testes##".$_SESSION['CAMPOSINVISIVEISInsert']."#Cliente_Edit.php=DE_SENHA#Cliente_Edit.php=DE_WHATSAPP#Cliente_Edit.php=DE_PROFISSAO#Cliente_Edit.php=DE_ALTURA#Cliente_Edit.php=DE_FOTO#Cliente_Edit.php=DE_PESO#Cliente_Edit.php=NU_ALERGIAS_A_ALGUM_MEDICAMENTO#Cliente_Edit.php=btUploadVariosArquivos#Cliente_Edit.php=btSubmitEnviarENovo#Cliente_Edit.php=btVoltar#";
		$resultadoDaBusca=strpos(strtoupper($pagirnasquetemAcesso),strtoupper("#".$pagina."=".$Param."#"));
		if ($resultadoDaBusca>-1){
			//se achou está autorizado.
			//ai faz uma busca mostrando os campos que tem acesso.
			//campo tem o nome assim idclassTrDE_NOME e são escondidos na função na página rodapé com o nome fnCamposInvisiveis(); e cadastrado nas configurações com o nome:
			//se achou é para tornar o campo invisível.
			return false;
		} else{
			//	exit();
			return true;
			
		};
	} else {
		$pagirnasquetemAcesso = "#testes##".$_SESSION['CAMPOSINVISIVEISUpdate'].'#';
		$resultadoDaBusca=strpos(strtoupper($pagirnasquetemAcesso),strtoupper("#".$pagina."=".$Param."#"));
		if ($resultadoDaBusca>-1){
			//se achou está autorizado.
			//ai faz uma busca mostrando os campos que tem acesso.
			//campo tem o nome assim idclassTrDE_NOME e são escondidos na função na página rodapé com o nome fnCamposInvisiveis(); e cadastrado nas configurações com o nome:
			//se achou é para tornar o campo invisível.
			return false;
		} else{
			//	exit();
			return true;
			
		};
	};

   //
};

function encryptinstaladll($mensagem, $a_chave_do_usuario){
	$salt = "b3jdh$4D8gkb#2T7&sM40bn4A7fvv35cf1b48On184c@623Vvf6vi37vb34@3kf%";
	$key = substr(hash('sha256', $salt.$key.$salt), 0, 32);
	$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
	$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
	$encrypted = base64_encode(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, $data, MCRYPT_MODE_ECB, $iv));
	return urlencode($encrypted);
}

function decryptinstaladll($mensagem, $a_chave_do_usuario){
	$salt =  "b3jdh$4D8gkb#2T7&sM40bn4A7fvv35cf1b48On184c@623Vvf6vi37vb34@3kf%";
	$key = substr(hash('sha256', $salt.$key.$salt), 0, 32);
	$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
	$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
	$decrypted = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $key, base64_decode($data), MCRYPT_MODE_ECB, $iv);

	return urldecode($decrypted);
}
/*
         $plaintext = 'Testing OpenSSL Functions';
        // $methods = openssl_get_cipher_methods();
         //$clefSecrete = 'flight';
         echo '<pre>';       
             $method='AES-256-CBC';
            // se quiser gerar um novo usar isso $ivlen = openssl_cipher_iv_length($method);
             $ivlen=base64_decode("MTY=");
            
             $clefSecrete = base64_decode("GBo5vQJsM9rSg6GLytkq0w==");
             // se quiser gerar um novo usar isso $clefSecrete = openssl_random_pseudo_bytes($ivlen);
             
             $iv =  base64_decode("UlPRGHc46/FjHyGMRPqPZg==");
             // se quiser gerar um novo usar isso $iv = openssl_random_pseudo_bytes($ivlen);
     
             $encrypted = openssl_encrypt($plaintext, $method, $clefSecrete, OPENSSL_RAW_DATA, $iv);

             $method='AES-256-CBC';
            // $ivlen = openssl_cipher_iv_length($method);
             $ivlen=base64_decode("MTY=");
            
             $clefSecrete = base64_decode("GBo5vQJsM9rSg6GLytkq0w==");
             //$clefSecrete = openssl_random_pseudo_bytes($ivlen);
             
             $iv =  base64_decode("UlPRGHc46/FjHyGMRPqPZg==");
             //$iv = openssl_random_pseudo_bytes($ivlen);             
             $decrypted = openssl_decrypt($encrypted, $method, $clefSecrete, OPENSSL_RAW_DATA, $iv);
             echo 'clefSecrete='.base64_encode($clefSecrete). "\n";
             echo 'iv='.base64_encode($iv). "\n";
             echo 'iv='.base64_encode($ivlen). "\n";
             
             echo 'cipher='.$method. "\n";
             echo 'plaintext='.$plaintext. "\n";
             echo 'encrypted to: '.$encrypted. "\n";
             echo 'decrypted to: '.$decrypted. "\n\n";
     
         echo '</pre>';

*/
function decrypt($mensagem, $a_chave_do_usuario){
	
	$mensagem=rawurldecode($mensagem);
	$mensagem= base64_decode($mensagem); 

	$method='AES-256-CBC';
	$ivlen = openssl_cipher_iv_length($method);

	$clefSecrete = base64_decode("GBo5vQJsM9rSg6GLytkq0w==");
	//$clefSecrete = openssl_random_pseudo_bytes($ivlen);
	
	$iv =  base64_decode("UlPRGHc46/FjHyGMRPqPZg==");
	//$iv = openssl_random_pseudo_bytes($ivlen);

	$decrypted = openssl_decrypt($mensagem, $method, $clefSecrete, OPENSSL_RAW_DATA, $iv);
	return $decrypted;

}

function encrypt($mensagem, $a_chave_do_usuario){

	$method='AES-256-CBC';
//	$ivlen = openssl_cipher_iv_length($method);
   
	$clefSecrete = base64_decode("GBo5vQJsM9rSg6GLytkq0w==");
	//$clefSecrete = openssl_random_pseudo_bytes($ivlen);
	
	$iv =  base64_decode("UlPRGHc46/FjHyGMRPqPZg==");
	//$iv = openssl_random_pseudo_bytes($ivlen);

	
	$encrypted = openssl_encrypt($mensagem, $method, $clefSecrete, OPENSSL_RAW_DATA, $iv);
	
	$encrypted= base64_encode($encrypted); 
	//codificada em base64 para conseguirmos enviá-la em transtornos
	return rawurlencode($encrypted);
}

//saida da função é "KvMVCrccROwq0+gq1xAqK1lXvNYsFWv7xGgmEPdyCts="
//include('Crypt/RSA.php');
class MyEncryption
{
	public	 $pubkey = '...public key here...';
	public	 $privkey = '...private key here...';

	public	 function encryptRSA($data)
    {
        if (openssl_public_encrypt($data, $encrypted, $this->pubkey))
            $data = base64_encode($encrypted);
        else
            throw new Exception('Unable to encrypt data. Perhaps it is bigger than the key size?');

        return $data;
    }

	public 	function decryptRSA($data)
    {
        if (openssl_private_decrypt(base64_decode($data), $decrypted, $this->privkey))
            $data = $decrypted;
        else
            $data = '';

        return $data;
    }
}



//função para fazer a criptografia 
function fnEncrypt($Param){
	//só quem tem permissão no campo DE_VER_DADOS_CRIPTOGRAFADOS na página Configuracoesdetodossistemas/Funcionalidades_List.php pode criptografar ou descriptografar informações.
	if($_SESSION["DE_VER_DADOS_CRIPTOGRAFADOS"]=="#Sim#"){
		//depois criptografa ele.
		return encrypt($Param,"yKwhaI@qvlh2cL((gLe^^4TXXC");
	} else {
		return $Param;
	};	

 }
 //função para desfazer a criptografia 
function fnDecrypt($Param){	
	if($_SESSION["DE_VER_DADOS_CRIPTOGRAFADOS"]=="#Sim#"){
			//depois descriptografa ele.
			return decrypt($Param,"yKwhaI@qvlh2cL((gLe^^4TXXC");
	} else {
		return $Param;
	};
 }

function fnPOSTSenhaCrip($Param){
	$Dados="";
	if (isset($_POST[$Param])){
		$Dados=$_POST[$Param];		
	} else {
		$Dados="";
	}
	$Dados=fnBLOQUEARSQLINJECTION(md5($Dados));
	//PROTEJE A APLICAÇÃO DE ATAQUES DE HACKER.
//   $Dados = preg_replace(sql_regcase("/(from|select|create table|alter table|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"), "" ,$Dados);
  // $Dados = trim($Dados);
  // $Dados = strip_tags($Dados);
 //  $Dados = (get_magic_quotes_gpc()) ? $Dados : addslashes($Dados);
   return $Dados;	
 }
function fnPOSTSenha($Param){
	$Dados="";
	if (isset($_POST[$Param])){
		$Dados=$_POST[$Param];		
	} else {
		$Dados="";
	}
	//QUE CONFERE SE A SENHA É A MESMA QUE A DIGITADA SE FOR NÃO CRIPTOGRAVA NOVAMENTE.
	$Param=$Param."_CONFERE";
	if (isset($_POST[$Param])){
		$DadosConfere=$_POST[$Param];		
	} else {
		$DadosConfere="";
	}
	if ($DadosConfere!=$Dados){
		//criptografa os dados da senha alterada em um só sentido.
		$Dados=md5($Dados);
	}
	
	
	$Dados=fnBLOQUEARSQLINJECTION($Dados);		

	//PROTEJE A APLICAÇÃO DE ATAQUES DE HACKER.
//   $Dados = preg_replace(sql_regcase("/(from|select|create table|alter table|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"), "" ,$Dados);
  // $Dados = trim($Dados);
  // $Dados = strip_tags($Dados);
 //  $Dados = (get_magic_quotes_gpc()) ? $Dados : addslashes($Dados);
   return $Dados;	
 }
 
function fnPOST($Param){
	$Dados="";
	if (isset($_POST[$Param])){
		$Dados=$_POST[$Param];		
	} else {
		$Dados="";
	}
	$Dados=fnBLOQUEARSQLINJECTION($Dados);
	//PROTEJE A APLICAÇÃO DE ATAQUES DE HACKER.
//   $Dados = preg_replace(sql_regcase("/(from|select|create table|alter table|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"), "" ,$Dados);
  // $Dados = trim($Dados);
  // $Dados = strip_tags($Dados);
 //  $Dados = (get_magic_quotes_gpc()) ? $Dados : addslashes($Dados);
   return $Dados;	
 }
 function fnPOSTDecode($Param){
	$Dados="";
	if (isset($_POST[$Param])){
		$Dados=$_POST[$Param];		
	} else {
		$Dados="";
	}
	//$Dados=fnBLOQUEARSQLINJECTION($Dados);
	//PROTEJE A APLICAÇÃO DE ATAQUES DE HACKER.
//   $Dados = preg_replace(sql_regcase("/(from|select|create table|alter table|insert|delete|where|drop table|show tables|#|\*|--|\\\\)/"), "" ,$Dados);
  // $Dados = trim($Dados);
  // $Dados = strip_tags($Dados);
 //  $Dados = (get_magic_quotes_gpc()) ? $Dados : addslashes($Dados);
   return $Dados;	
 }
 
  function fnDecode($Param){
   return urldecode($Param);	
 }

 ?>

<script type="text/javascript">

function aumentaOuDiminui(obj)
{	if (obj.height==200){
		obj.height=obj.height*4;
		obj.width=obj.width*4;
	} else {
		obj.height=200;
		obj.width=200;	
	}
}

function aumentaOuDiminuiObj(obj)
{	if (obj.height==200){
		obj.height=obj.height*4;
		obj.width=obj.width*4;
	} else {
		obj.height=200;
		obj.width=200;	
	}
}

</script>

<script language="javascript" type="text/javascript">

														var Slide = new Array("chat/fotos/1596433492.jpg", "chat/fotos/1609269939.jpg", "chat/fotos/1598761401.jpeg");
														var indSlide = 0;
														var ultSlide = Slide.length -1;
														// Função controla a seqüência de slides.
														function MostraSlide(direcao){
														indSlide = indSlide + direcao;
														if(indSlide > ultSlide){indSlide = 0};
														if(indSlide < 0) {indSlide = ultSlide};
														document.FigSlide.src = Slide[indSlide];
														};

														function aumentaOuDiminuiObjInteiro(fotoPrincipal,todasFotos)
														{	
															document.getElementById("outer2").style.display='block';
															document.getElementById("inner2").style.display='block';	
															document.FigSlide.src = fotoPrincipal;
															var windowWidth = window.innerWidth;
															var windowHeight = window.innerHeight;
															document.getElementById("inner2").style.height=windowHeight*0.8;
															document.getElementById("inner2").style.width=windowWidth*0.8;
														//	if (document.FigSlide.style.width*4<document.getElementById("inner2").style.width && document.FigSlide.style.height*4<document.getElementById("inner2").style.height){

															//}

														}
										
														</script>
														<style>
															#outer2{
																padding-left: 23px;
																position:absolute; 
																height:auto; 
																width:200px; 
																border: 1px solid red; 
															}
															#inner2{
																top:100;
																left:0;
																position:absolute; 
																height:721px; 
																width:800px; 
																border: 1px solid black; 
														}
														</style>
														<div id='outer2' style="display:none;z-index:999">
															<div id='inner2' style="z-index:999;  overflow:auto;background-color:black;" >
															<center>
																<table >
																<tr>
																		<td>
																			<a href="javascript:MostraSlide(-1)">
																			<b><font color="#800000">
																			<<</font></b></a>
																		</td>
																		<td>
																			<a href="#" onClick="document.getElementById('outer2').style.display='none';document.getElementById('inner2').style.display='none';">
																			<b><font color="#800000">
																			X</font></b></a>
																		</td>
																		<td>
																			<p align="right">
																			<a href="javascript:MostraSlide(1)">
																			<b><font color="#800000">
																			>></font></b></a>
																			</p>
																		</td>
																	</tr>		
																	<tr>
																		<td colspan="3" align="center">

																				<img src="chat/fotos/1609292690.jfif" style='width:"100%";height:"100%"' name="FigSlide" border="0" >

																		</td>
																	</tr>

																</table>

															</center>
																</div>
														</div>
 <?php
 
  function fnMostraFotos($Param){
				$FotoPosArray=explode("#",$Param);
				$keys = array_keys($FotoPosArray);

				$size = count($FotoPosArray);
				$quantidadeDeFotos=0;
					//value tem que estar preenchido.//verifica se tem foto.
					$valueTodasFotos="";
					$valuePrimeiraFoto="";				
				//loop no array de horas.
				for ($i = 0; $i < $size; $i++) {					
					$key   = $keys[$i];
									$_SESSION["LOG_CHAT"]=$_SESSION["LOG_CHAT"]."<BR/> key=> <BR/>".$key;		
					$value = $FotoPosArray[$key];
					$_SESSION["LOG_CHAT"]=$_SESSION["LOG_CHAT"]."<BR/> value=> <BR/>".$value;

					if (trim($value)!="" && trim($value)!="Erro 4"){
						$_SESSION['DE_FOTOFotoPosArray']=$_SESSION['DE_FOTOFotoPosArray']+1;
						if($valueTodasFotos==""){
							$valueTodasFotos=$valueTodasFotos.'#chat/'.$value.'#';	
							$valuePrimeiraFoto='chat/'.$value.'';	
							$quantidadeDeFotos=1;					
						} else{
							$quantidadeDeFotos=$quantidadeDeFotos+1;
							$valueTodasFotos=$valueTodasFotos.',#chat/'.$value.'#';
						}	
	
					};//verifica se tem foto.
				};//for
					$valueTudo=str_replace('##','#',$valueTodasFotos);	
					$DE_DESCRICAO='Quantidade de fotos:'.$quantidadeDeFotos.'</br>';
					if($quantidadeDeFotos>0){
											//var Slide = new Array("chat/fotos/1596433492.jpg", "chat/fotos/1609269939.jpg", "chat/fotos/1598761401.jpeg");			
											$resultadoDaBusca=strpos(strtoupper($valuePrimeiraFoto),strtoupper(".pdf"));
											if ($resultadoDaBusca>-1){
												if($valuePrimeiraFoto)
												$DE_DESCRICAO=$DE_DESCRICAO.'
												<a href="'.$valuePrimeiraFoto.'"   onclick="aumentaOuDiminuiObjInteiro(\''.$valuePrimeiraFoto.'\',\''.$valueTudo.'\');"   />Arquivo PDF</a>
												<script language="javascript" type="text/javascript">						
												var Slide = new Array('.str_replace('#','"',$valueTudo).');
												var indSlide = 0;
												var ultSlide = Slide.length -1;
												</script></br></br>
																	
												';
											} else{
												if($valuePrimeiraFoto)
												$DE_DESCRICAO=$DE_DESCRICAO.'
												<img heigth=200 width=200 src="'.$valuePrimeiraFoto.'"   onclick="aumentaOuDiminuiObjInteiro(\''.$valuePrimeiraFoto.'\',\''.$valueTudo.'\');"   />
												<script language="javascript" type="text/javascript">						
												var Slide = new Array('.str_replace('#','"',$valueTudo).');
												var indSlide = 0;
												var ultSlide = Slide.length -1;
												</script></br></br>
																	
												';
											}

					};

					
				return $DE_DESCRICAO;
 } 

 function fnMostraFotosSimples($Param){
	$FotoPosArray=explode("#",$Param);
	$keys = array_keys($FotoPosArray);

	$size = count($FotoPosArray);

	//loop no array de horas.
	//for ($i = $size; $i >=0 ; $i--) {	
	for ($i = 0; $i < $size; $i++) {							
		$key   = $keys[$i];
						$_SESSION["LOG_CHAT"]=$_SESSION["LOG_CHAT"]."<BR/> key=> <BR/>".$key;		
		$value = $FotoPosArray[$key];
		$_SESSION["LOG_CHAT"]=$_SESSION["LOG_CHAT"]."<BR/> value=> <BR/>".$value;
		//value tem que estar preenchido.//verifica se tem foto.
		if (trim($value)!="" && trim($value)!="Erro 4"){
			$_SESSION['DE_FOTOFotoPosArray']=$_SESSION['DE_FOTOFotoPosArray']+1;
			$DE_DESCRICAO=' 
			<img heigth=200 width=200 src="chat/'.$value.'"   onclick="aumentaOuDiminui(this);"   />	</br></br>
			';
		}//verifica se tem foto.
	};//for
	return $DE_DESCRICAO;
} 

function fnMostraFotosTamReal($Param,$heigth,$width){
	$FotoPosArray=explode("#",$Param);
	$keys = array_keys($FotoPosArray);

	$size = count($FotoPosArray);

	//loop no array de horas.
	for ($i = 0; $i < $size; $i++) {				
		$key   = $keys[$i];
						$_SESSION["LOG_CHAT"]=$_SESSION["LOG_CHAT"]."<BR/> key=> <BR/>".$key;		
		$value = $FotoPosArray[$key];
		$_SESSION["LOG_CHAT"]=$_SESSION["LOG_CHAT"]."<BR/> value=> <BR/>".$value;
		//value tem que estar preenchido.//verifica se tem foto.
		if (trim($value)!="" && trim($value)!="Erro 4" && trim($value)!="4" && trim($value)!="Erro"){
			$_SESSION['DE_FOTOFotoPosArray']=$_SESSION['DE_FOTOFotoPosArray']+1;
			if($heigth!="" && $width!=""){
			$DE_DESCRICAO=' 
			<img  heigth='.$heigth.' width='.$width.'  src="chat/'.$value.'"     />	</br>
			';
			} else {
				$DE_DESCRICAO=' 
				<img  src="chat/'.$value.'"    />	</br>
				';
			};
		}//verifica se tem foto.
	};//for
	return $DE_DESCRICAO;
} 
 function fnGET($Param){
	$Dados="";
	if (isset($_GET[$Param])){
		$Dados=$_GET[$Param];		
	} else {
		$Dados="";
	}
	
	//PROTEJE A APLICAÇÃO DE ATAQUES DE HACKER.
    $Dados=fnBLOQUEARSQLINJECTION($Dados);
   return $Dados;	
 }
function fnCriarArquivo($fileName,$textoCompleto){
	
	if(1==2){

		// verifica se o arquivo existe
  //  if (!file_exists($fileName)){
	    //abre o arquivo ATUAL SÓ QUE COM O NOME DE
		$arquivoAtual = fopen("sistemas\\".$fileName, "w");
		//le os dados do arquivo ATUAL .
		$strAtual = @fread($arquivoAtual, 99999999);	
		
		//ABRE O ARQUIVO ATUAL COM O NOME QUE SERÁ SALVO PARA BACKUP, SÓ PARA ADICIONAR O NOME AO ARQUIVO POIS ELE AINDA NAO EXISTE.
		//$arquivo = fopen("sistemas\backupArquivosAntigos\\".$fileName, "w");	
		//le os dados do arquivo ATUAL .
		$strAnterior = @fread($arquivoAnterior, 99999999);

//$origem="C:\xampp\htdocs\SIDES\application\models";
     $diretorio1="sistemas\backupArquivosAntigos\\".date(Y_m_d).time()."\\".$fileName;
	//"C:\_sistemas\SIDES\implantacao\models\TESTE2\TSX.PHP";
	$nomeDoArquivo=str_replace($DirDestino,"",$diretorio1);
		$diretorio1=$fileName;
		$DirDestino=substr($diretorio1,0,strripos($diretorio1,"/") );
		if(!is_dir($DirDestino)){
			if(!mkdir($DirDestino, 0777, true)){
				  echo "<br>O diretório não foi criado, verificar as permissões da pasta.";		
				}
		}		
		if ($strAnterior!=$strAtual){
			//ABRE O ARQUIVO ATUAL COM O NOME QUE SERÁ SALVO PARA BACKUP, SÓ PARA ADICIONAR O NOME AO ARQUIVO POIS ELE AINDA NAO EXISTE.
			$arquivo = fopen($diretorio1  	, "w");		
        //SALVA UM BACKUP DO ARQUIVO ATUAL
		fwrite($arquivo,$strAtual);					
		}
        //SALVA UM BACKUP DO ARQUIVO ATUAL
		//fwrite($arquivo,$strAtual);		
					//TIRA ELE DA MEMÓRIA DO COMPUTADOR.
		//fclose($arquivo);		

		//salva o arquivo 
		fwrite($arquivoAtual,$strAtual);	
				//TIRA ELE DA MEMÓRIA DO COMPUTADOR.
		fclose($arquivoAtual);	
		
	}else{		
		$diretorio1=$fileName;
		$DirDestino=substr($diretorio1,0,strripos($diretorio1,"/") );
		if(!is_dir($DirDestino)){
			if(!mkdir($DirDestino, 0777, true)){
				  echo "<br>O diretório não foi criado, verificar as permissões da pasta.";		
				}
		}				
		//abre o arquivo ATUAL  SÓ QUE COM O NOME CORRETO DELE QUE NÃO EXISTE SÓ PARA ADICIONAR O NOME AO ARQUIVO.
		$arquivoAtual = fopen("sistemas/".$fileName, "w");
		//le os dados do arquivo ATUAL .
		//$strAtual = @fread($arquivoAtual, 99999999);
		//echo("<br>Salvando o arquivo<br/><textarea>".$textoCompleto."</textarea>");	
		//salva o arquivo
		fwrite($arquivoAtual,$textoCompleto);	
		//echo("<iframe src='"."sistemas/".$fileName."'></iframe>");
		//TIRA ELE DA MEMÓRIA DO COMPUTADOR.
		fclose($arquivoAtual);
		
	}


return "Alterado com sucesso";
}

//fnAjustarArquivoInsert("SEFAZ_Empresa.txt","SEFAZ_Empresa.sql",",",8,"","NAO");
function fnAjustarArquivoInsert($tabelaGravar,$fileName,$fileNamePadrao,$Delimitador,$totalDelimitadorPorLinha,$strCabecalho,$NAOaceitaLinhaEmbranco){
	
	/*
	exemplo e explicação de cada parametro.
	total de delimitadores por linha, quantos campos tem separados por ponto e virgula.
	$totalDelimitadorPorLinha=43;
	qual o tipo de delimitador usado , ou ;
	$Delimitador =";";	
	se tiver cabeçalho e quiser subistituir por outro cabeçalho.
	$strCabecalho="ACORDO DE OBJETIVOS;Status;Status parcial;Avaliador;Mat.Avaliador;Avaliado;Mat.Avaliado;Coluna;ACORDO 2015 - OBJETIVOS INDIVIDUAIS;cExtra1;cExtra2;cExtra3;1 INSERIR OBJETIVOS INDIVIDUAIS;cExtra4;cExtra5;cExtra6;1.1 OBJETIVO INDIVIDUAL;cExtra7;cExtra8;cExtra9;1.2 OBJETIVO INDIVIDUAL;cExtra10;cExtra11;cExtra12;1.3 OBJETIVO INDIVIDUAL;cExtra13;cExtra14;cExtra15;1.4 OBJETIVO INDIVIDUAL;cExtra16;cExtra17;cExtra18;1.5 OBJETIVO INDIVIDUAL;cExtra19;cExtra20;cExtra21;1.6 OBJETIVO INDIVIDUAL;cExtra22;cExtra23;cExtra24;1.7 OBJETIVO INDIVIDUAL;cExtra25;cExtra26;cExtra27";
	nome do arquivo que é lido.
	$fileName="objIndividuaiscsvtexto.txt";	
	nome do arquivo que quer salvar por exemplo le arq.csv  e salva arquivo.TXT
    $fileNamePadrao="objIndividuaiscsvtextoNovo.txt"; 
*/
	/*$arquivo2 = fopen($fileName, "w");
	$str2 = @fread($arquivo2, 99999999);
	//$str2=str_replace ( "\r" , "\n" , $str2);
	$str2=str_replace ( "\n" , "" , $str2);
	fwrite($arquivo2, $str2);
	fclose($arquivo2);
	sleep(13);	*/
	
	$total = count(file($fileName));	
	$countlinhashandle=0;	
	$textoCompleto="";  

	$linhaOriginal="";
	$quantidadeDelimitadores="";
				for ($i = 0; $i < $totalDelimitadorPorLinha; $i++){ 
					$quantidadeDelimitadores=$quantidadeDelimitadores.$Delimitador;
				}
				
				


       // $str = @fread($fp, 999999); 
		//echo $str;
       // $number_of_occurences = strpos_count($str,"\n");
	//echo $number_of_occurences					
	for($i = 0; $i <= $total; $i++)
		 {
			 echo "<br><br>PLinhaOriginal:<br>";
			 //se quiser um cabeçalho diferente do original como por exemplo com nomes de campos preenchidos que vieram em branco.
		 
			   $linhaOriginal=getLine($fileName,$i);
			   $countlinhashandle=$countlinhashandle+1;
			   $linhaEmBranco="ACEITA";
				if($NAOaceitaLinhaEmbranco){
					$linhaEmBranco=trim($linhaOriginal);
				}

				$number_of_occurences = strpos_count($linhaOriginal,";"); 
				//	 echo "<br><br>Quantidade de ocorrencias:<br>";			
			//	echo $number_of_occurences;

			if ($number_of_occurences != $totalDelimitadorPorLinha) {
				$quantosDelimitadoresFaltam=$number_of_occurences-$totalDelimitadorPorLinha;
				echo "<br><br>Quantos faltam:<br>";			
				echo $quantosDelimitadoresFaltam;	
				//adicina os delimitadores que faltavam			
				$linhaNova = $linhaOriginal.substr($quantidadeDelimitadores, $quantosDelimitadoresFaltam);
			}			

					 echo "<br><br>Presultado:<br>";
							   echo $linhaNova;
							   // caso queira adicionar br no lugar da quebra de linha $linhaNova=nl2br($linhaNova);							   
							   //tira a quebra de linha do meio do arquivo;
							   $linhaNova=str_replace ( "\n" , "" , $linhaNova);
							   $linhaNova=str_replace ( "'" , "" , $linhaNova);
							   $linhaNova=str_replace ( '"' , "" , $linhaNova);
							   $linhaNova=str_replace ( "\r" , "" , $linhaNova);	
							   //fazendo os inserts, 
							   $linhaNova=str_replace ( "," , "','" , $linhaNova);	


						if ($i == 0){
									if ($strCabecalho!=""){
										$linhaNova="insert into $tabelaGravar ($strCabecalho) values ('"; 
							  										
									}
						}
						if($linhaEmBranco!=""){
							if ($i == $total){
							// não adiciona a quebra de linha no final se for o último arquivo.
								$textoCompleto=$textoCompleto.$linhaNova."'); ";
							} else {
								$textoCompleto=$textoCompleto.$linhaNova."'), ('";	
							}
						}

		//escreve o arquivo novo.					   
	//$arquivo = fopen("objIndividuaiscsvtexto.txt", "w");						   
					   
	  //echo $countlinhashandle;
  
  //echo getStrLine("objIndividuaiscsvtexto.txt",$i);
       //    $linha = "teste";
         //  if($i == $id);
         //  else
          //       fwrite($novo, $linha);
    }
	$arquivo = fopen($fileNamePadrao, "w");	
	fwrite($arquivo, $textoCompleto);		
	//tira o arquivo da memória do computador.
fclose($arquivo);
return "Alterado com sucesso para insert.";
}


	
function fnAjustarArquivo($fileName,$fileNamePadrao,$Delimitador,$totalDelimitadorPorLinha,$strCabecalho,$NAOaceitaLinhaEmbranco){
	
	/*
	exemplo e explicação de cada parametro.
	total de delimitadores por linha, quantos campos tem separados por ponto e virgula.
	$totalDelimitadorPorLinha=43;
	qual o tipo de delimitador usado , ou ;
	$Delimitador =";";	
	se tiver cabeçalho e quiser subistituir por outro cabeçalho.
	$strCabecalho="ACORDO DE OBJETIVOS;Status;Status parcial;Avaliador;Mat.Avaliador;Avaliado;Mat.Avaliado;Coluna;ACORDO 2015 - OBJETIVOS INDIVIDUAIS;cExtra1;cExtra2;cExtra3;1 INSERIR OBJETIVOS INDIVIDUAIS;cExtra4;cExtra5;cExtra6;1.1 OBJETIVO INDIVIDUAL;cExtra7;cExtra8;cExtra9;1.2 OBJETIVO INDIVIDUAL;cExtra10;cExtra11;cExtra12;1.3 OBJETIVO INDIVIDUAL;cExtra13;cExtra14;cExtra15;1.4 OBJETIVO INDIVIDUAL;cExtra16;cExtra17;cExtra18;1.5 OBJETIVO INDIVIDUAL;cExtra19;cExtra20;cExtra21;1.6 OBJETIVO INDIVIDUAL;cExtra22;cExtra23;cExtra24;1.7 OBJETIVO INDIVIDUAL;cExtra25;cExtra26;cExtra27";
	nome do arquivo que é lido.
	$fileName="objIndividuaiscsvtexto.txt";	
	nome do arquivo que quer salvar por exemplo le arq.csv  e salva arquivo.TXT
    $fileNamePadrao="objIndividuaiscsvtextoNovo.txt"; 
*/
	/*$arquivo2 = fopen($fileName, "w");
	$str2 = @fread($arquivo2, 99999999);
	//$str2=str_replace ( "\r" , "\n" , $str2);
	$str2=str_replace ( "\n" , "" , $str2);
	fwrite($arquivo2, $str2);
	fclose($arquivo2);
	sleep(13);	*/
	
	$total = count(file($fileName));	
	$countlinhashandle=0;	
	$textoCompleto="";  

	$linhaOriginal="";
	$quantidadeDelimitadores="";
				for ($i = 0; $i < $totalDelimitadorPorLinha; $i++){ 
					$quantidadeDelimitadores=$quantidadeDelimitadores.$Delimitador;
				}
				
				


       // $str = @fread($fp, 999999); 
		//echo $str;
       // $number_of_occurences = strpos_count($str,"\n");
	//echo $number_of_occurences					
	for($i = 0; $i <= $total; $i++)
		 {
			 echo "<br><br>PLinhaOriginal:<br>";
			 //se quiser um cabeçalho diferente do original como por exemplo com nomes de campos preenchidos que vieram em branco.
		 
			   $linhaOriginal=getLine($fileName,$i);
			   $countlinhashandle=$countlinhashandle+1;
			   $linhaEmBranco="ACEITA";
				if($NAOaceitaLinhaEmbranco){
					$linhaEmBranco=trim($linhaOriginal);
				}

				$number_of_occurences = strpos_count($linhaOriginal,";"); 
				//	 echo "<br><br>Quantidade de ocorrencias:<br>";			
			//	echo $number_of_occurences;

			if ($number_of_occurences != $totalDelimitadorPorLinha) {
				$quantosDelimitadoresFaltam=$number_of_occurences-$totalDelimitadorPorLinha;
				echo "<br><br>Quantos faltam:<br>";			
				echo $quantosDelimitadoresFaltam;	
				//adicina os delimitadores que faltavam			
				$linhaNova = $linhaOriginal.substr($quantidadeDelimitadores, $quantosDelimitadoresFaltam);
			}			

					 echo "<br><br>Presultado:<br>";
							   echo $linhaNova;
							   // caso queira adicionar br no lugar da quebra de linha $linhaNova=nl2br($linhaNova);							   
							   //tira a quebra de linha do meio do arquivo;
							   $linhaNova=str_replace ( "\n" , "" , $linhaNova);
							   $linhaNova=str_replace ( "'" , "" , $linhaNova);
							   $linhaNova=str_replace ( '"' , "" , $linhaNova);
							   $linhaNova=str_replace ( "\r" , "" , $linhaNova);							   



						if ($i == 0){
									if ($strCabecalho!=""){
									$linhaNova=$strCabecalho; 								
									}
						}
						if($linhaEmBranco!=""){
							if ($i == $total){
							// não adiciona a quebra de linha no final se for o último arquivo.
								$textoCompleto=$textoCompleto.$linhaNova."";
							} else {
								$textoCompleto=$textoCompleto.$linhaNova."\n";	
							}
						}

		//escreve o arquivo novo.					   
	//$arquivo = fopen("objIndividuaiscsvtexto.txt", "w");						   
					   
	  //echo $countlinhashandle;
  
  //echo getStrLine("objIndividuaiscsvtexto.txt",$i);
       //    $linha = "teste";
         //  if($i == $id);
         //  else
          //       fwrite($novo, $linha);
    }
	$arquivo = fopen($fileNamePadrao, "w");	
	fwrite($arquivo, $textoCompleto);		
	//tira o arquivo da memória do computador.
fclose($arquivo);
return "Alterado com sucesso";
}
//Apaga um arquivo!!!
//unlink("editantoArquivoantigo.txt");

function strpos_count($haystack, $needle, $i = 0) { 
    while (strpos($haystack,$needle) !== false) {$haystack = substr($haystack, (strpos($haystack,$needle) + 1)); $i++;} 
    return $i; 
} 


function getLine($file,$line=1){ 
    $occurence = 0; 
    $contents = ''; 
    $startPos = -1; 
	// verifica se o arquivo existe
    if (!file_exists($file)) return ''; 
	//abre o arquivo.
    $fp = @fopen($file, "rb"); 
    if (!$fp) return ''; 

	//enquanto o arquivo não estiver vazio.
    while (!@feof($fp)) {
       // na pratica esse é o comando correto para ler a linha atual $str = fgetc($fp);
        $str = @fread($fp, 99999999); 
	    $str=str_replace ( "\r\n" , "\n" , $str);	
	    $str=str_replace ( "\n\r" , "\n" , $str);	
     	$str=str_replace ( "\r" , "\n" , $str);			
    	// NO ARQUIVO TEM QUEBRA DE LINHA DENTRO DOS CAMPOS AI NÃO PODE DEFINIR A LINHA PELA SIMPLES QUEBRA DE LINHA MAS PELO PRIMEIRO NOME NO PROXIMO CAMPO.
        $number_of_occurences = strpos_count($str,"\nACORDO");

        if ($number_of_occurences == 0) {if ($start_pos != -1) {$contents .= $str;}} 
        else { 
            $lastPos = 0; 
            for ($i = 0; $i < $number_of_occurences; $i++){ 
                $pos = strpos($str,"\nACORDO", $lastPos); 
				
                $occurence++; 
                if ($occurence == $line) { 
                    $startPos = $pos; 
                    if ($i == $number_of_occurences - 1) {$contents = substr($str, $startPos + 1);} 
                } elseif ($occurence == $line + 1) { 
                    if ($i == 0) {$contents .= substr($str, 0, $pos);} else {$contents = substr($str, $startPos, $pos - $startPos);} 
                    $occurence = 0; 
                    break; 
                } 
                $lastPos = $pos + 1; 
            } 
        } 
    } 
    @fclose($fp); 
    $contents=str_replace ( "\n" , "" , $contents);
    return $contents; 
} 
function fnRemoveAsterisco($str){
	 // assume $str esteja em UTF-8

		$str=str_replace ( '#' , '',$str);	
		$str=str_replace ( '$' , '',$str);	
		$str=str_replace ( '%' , '',$str);	
		$str=str_replace ( '^' , '',$str);	
		$str=str_replace ( '&' , '',$str);	
		$str=str_replace ( '*' , '',$str);	
		$str=str_replace ( '=' , '',$str);	
		$str=str_replace ( '+' , '',$str);	
		$str=str_replace ( '~' , '',$str);		
		$str=str_replace ( "'" , "",$str);		
		$str=str_replace ( '-' , '',$str);		
		$str=str_replace ( '"' , '',$str);
	 return $str;	
	 
}
function fnFormataMoedaDBPTela($str){
	// assume $str esteja em UTF-8

	   $str=str_replace ( ',' , '#',$str);	
	   $str=str_replace ( '.' , ',',$str);	
	   $str=str_replace ( '#' , '.',$str);		   
	return $str;	
	
}

?>
  					<?php function fnBuscaTabela($sqlSelect,$clausulaWhere,$valorSelecionado,$nomeCampo,$parametrosAdicionais){
						$sqlSelect= $sqlSelect.$clausulaWhere;
						$respSelect = mysqlexecuta($conexao,$sqlSelect);
						
						echo '<select class="clSelect" name="'.$nomeCampo.'" id="'.$nomeCampo.'" '.$parametrosAdicionais.' >';
							echo '<option value=""></options>';		
							while ($rowSelect = fnmysqli_fetch_array($respSelect)) { 
								//faz todo o loop consultando os campos.
								?>
									<option <?php if($valorSelecionado==$rowSelect[0]){echo "selected";}; ?> 
									value="<?php echo $rowSelect[0]; ?>"><?php echo $rowSelect[0]; ?></options>
								<?php
							} //fim do while.
							?>
					</select>
				<?php
					} //fim da função.
					?>	
					<?php //select 's' as t, 'b' as value union select 'se' as t, 'bf' as value ; 
					function fnSelect($tabela,$campoValor,$CampoDescricao,$clausulaWhere,$valorSelecionado,$nomeCampo,$parametrosAdicionais){
						$sqlSelect= "SELECT ".$campoValor." as Valor, ".$CampoDescricao." as Descricao  FROM ".$tabela." ".$clausulaWhere." ";
						$respSelect = mysqlexecuta($conexao,$sqlSelect);
					//	echo($sqlSelect);
						echo '<select  name="'.$nomeCampo.'" id="'.$nomeCampo.'" '.$parametrosAdicionais.' >';
							echo '<option value=""></options>';					
							while ($rowSelect = fnmysqli_fetch_array($respSelect)) { 
								//faz todo o loop consultando os campos.
								?>
									<option <?php if($valorSelecionado==$rowSelect['Valor']){echo "selected";}; ?> 
									value="<?php echo $rowSelect['Valor']; ?>"><?php echo $rowSelect['Descricao']; ?></options>
								<?php
							} //fim do while.
							?>
					</select>
				<?php
					} //fim da função.
					?>	
	  					<?php function fnInput($valorSelecionado,$nomeCampo,$parametrosAdicionais){
						$sqlSelect= $sqlSelect.$clausulaWhere;
						$respSelect = mysqlexecuta($conexao,$sqlSelect);
						
						echo '<input type=text class="clSelect" name="'.$nomeCampo.'" id="'.$nomeCampo.'"  value="'.$valorSelecionado.'" '.$parametrosAdicionais.' />';

						?>

				<?php
					} //fim da função.
					?>	
					<?php function fnRadio($tabela,$campoValor,$CampoDescricao,$clausulaWhere,$valorSelecionado,$nomeCampo,$parametrosAdicionais){
						$sqlSelect= "SELECT ".$campoValor." as Valor, ".$CampoDescricao." as Descricao  FROM ".$tabela." ".$clausulaWhere." ";
						$respSelect = mysqlexecuta($conexao,$sqlSelect);
					//	echo($sqlSelect);
						echo '<input type radio  name="'.$nomeCampo.'" id="'.$nomeCampo.'" '.$parametrosAdicionais.' >';
							echo '<option value=""></options>';					
							while ($rowSelect = fnmysqli_fetch_array($respSelect)) { 
								//faz todo o loop consultando os campos.
								?>
									<option <?php if($valorSelecionado==$rowSelect['Valor']){echo "selected";}; ?> 
									value="<?php echo $rowSelect['Valor']; ?>"><?php echo $rowSelect['Descricao']; ?></options>
								<?php
							} //fim do while.
							?>
					</select>
				<?php
					} //fim da função.
					?>		
					<?php function fnOptions($tabela,$campoValor,$CampoDescricao,$clausulaWhere,$valorSelecionado,$nomeCampo,$parametrosAdicionais){
						$sqlSelect= "SELECT ".$campoValor." as Valor, ".$CampoDescricao." as Descricao  FROM ".$tabela." ".$clausulaWhere." ";
						$respSelect = mysqlexecuta($conexao,$sqlSelect);
					//	echo($sqlSelect);
						echo '<select  name="'.$nomeCampo.'" id="'.$nomeCampo.'" '.$parametrosAdicionais.' >';
							echo '<option value=""></options>';					
							while ($rowSelect = fnmysqli_fetch_array($respSelect)) { 
								//faz todo o loop consultando os campos.
								?>
									<option <?php if($valorSelecionado==$rowSelect['Valor']){echo "selected";}; ?> 
									value="<?php echo $rowSelect['Valor']; ?>"><?php echo $rowSelect['Descricao']; ?></options>
								<?php
							} //fim do while.
							?>
					</select>
				<?php
					} //fim da função.
					?>									
					

<?php

// remove arquivos de um diretório com arquivos.
function rrmdir($dir) {
  if (is_dir($dir)) {
    $files = scandir($dir);
    foreach ($files as $file)
    if ($file != "." && $file != "..") rrmdir("$dir/$file");
    rmdir($dir);
  }
  else if (file_exists($dir)) unlink($dir);
} 

// copia arquivos para um diretório com arquivos.
function rcopy($src, $dst) {
  if (file_exists($dst)) rrmdir($dst);
  if (is_dir($src)) {
    mkdir($dst);
    $files = scandir($src);
    foreach ($files as $file)
    if ($file != "." && $file != "..") rcopy("$src/$file", "$dst/$file"); 
  }
  else if (file_exists($src)) copy($src, $dst);
}

function ParaBDDT($Param){
	$Dados="";

		if (trim($Param)!=""){
			$Dados="'".$Param."'";		
		} else {
			$Dados="NULL";
		}
	
   
	 return $Dados;
}
//coloca no formato americano PARA INSERIR NO BANCO DE DADOS.
//entra 31/12/2019 00:00:00
//sai 2019-12-31  
function fnFormataDtBd($Param){
	$Dados="";

		if (trim($Param)!=""){
			$ParamArray=explode("/",$Param);	
			//as vezes vem no formato de ano data e hora
			$anoEhora=explode(" ",$ParamArray[2]." 00:00:00");			
			$Dados="'".$anoEhora[0]."-".$ParamArray[1]."-".$ParamArray[0]."'";		
		} else {
			$Dados="NULL";
		}
		$Dados=str_replace ( "--" , "" , $Dados);		
   
	 return $Dados;
}

//coloca no formato americano PARA MOSTRAR NA PÁGINA.
//entra 2019-12-31 00:00:00
//sai 31/12/2019
function fnFormataDtBdParaTela($Param){
	$Dados="";

		if (trim($Param)!=""){
			$Param=str_replace(" 00:00:00","",$Param);  
			$ParamArray=explode('-',$Param);	
			$Dados=$ParamArray[2]."/".$ParamArray[1]."/".$ParamArray[0];		
		} else {
			$Dados="";
		}
	
   
	 return $Dados;
}

//coloca no formato americano PARA MOSTRAR NA PÁGINA.
//entra 2019-12-31 00:00:00
//sai 31/12/2019
function fnFormataDtBdParaTelaCalendario($Param){
	

		if (trim($Param)!=""){
			$Param=str_replace(" 00:00:00","",$Param);  
		//	$ParamArray=explode('-',$Param);	
		//	$Dados=$ParamArray[2]."/".$ParamArray[1]."/".$ParamArray[0];		
		} else {
			$Param="";
		}
	
   
	 return $Param;
}

function GTDT($Param){
	$Dados="";
	if (isset($_POST[$Param])){
		$Dados="'".trim($_POST[$Param])."'";		
	} else {
		if (isset($_GET[$Param])){
			$Dados="'".trim($_GET[$Param])."'";		
		} else {
			$Dados="NULL";
		}
	}	
	//$Dados=fnBLOQUEARSQLINJECTION($Dados);
		//PROTEJE A APLICAÇÃO DE ATAQUES DE HACKER.
	 //  $Dados = preg_replace(sql_regcase("(from|select|create table|alter table|insert|delete|where|drop table|show tables|#|\*|--|\\\\)"), "" ,$Dados);
	 //  $Dados = trim($Dados);
	 //  $Dados = strip_tags($Dados);
	 //  $Dados = (get_magic_quotes_gpc()) ? $Dados : addslashes($Dados);
	 if (trim($Dados)==""){
		 $Dados="NULL";
	 }
     
	 return $Dados;
}

function GTDecimal($Param){
	$Dados="";
	if (isset($_POST[$Param])){
		$Dados="'".$_POST[$Param]."'";		
	} else {
		if (isset($_GET[$Param])){
			$Dados="'".$_GET[$Param]."'";		
		} else {
			$Dados="";
		}
	}	
		//PROTEJE A APLICAÇÃO DE ATAQUES DE HACKER.
     $Dados=fnBLOQUEARSQLINJECTION($Dados);
   //tira os pontos.
	$Dados=str_replace(".","",$Dados);  
   //subistitui as vírculas por pontos.
	$Dados=str_replace(",",".",$Dados);
 //se vir em branco tem que enviar null para inserir ou dá erro no sistema.	
	IF ($Dados==""){
		$Dados=" null ";
	}
	//Retorna no formato que pode ser inserido na base de dados sem erros.												
   return $Dados;
};


function ceil_dec($number,$precision,$separator)
{
    $numberpart=explode($separator,$number); 
$numberpart[1]=substr_replace($numberpart[1],$separator,$precision,0);
    if($numberpart[0]>=0)
    {$numberpart[1]=ceil($numberpart[1]);}
    else
    {$numberpart[1]=floor($numberpart[1]);}

    $ceil_number= array($numberpart[0],$numberpart[1]);
    return implode($separator,$ceil_number);
}

function fnDecimalBDParaTela($Param){

		//PROTEJE A APLICAÇÃO DE ATAQUES DE HACKER.
	// $Dados=fnBLOQUEARSQLINJECTION($Dados);
	if ($Param==null){
		$Param="0.00";
	}else{
		//arredonda o valor.
		$Param=ceil_dec($Param,2,".");
	}
	
   //tira os pontos.
	$Dados=str_replace(",","",$Param);  
   //subistitui as vírculas por pontos.
	$Dados=str_replace(".",",",$Dados);
 //se vir em branco tem que enviar null para inserir ou dá erro no sistema.	
	IF ($Dados==""){
		$Dados=" null ";
	}
	//Retorna no formato que pode ser inserido na base de dados sem erros.												
   return $Dados;
};
//servidor não aceita o campo DATA POR ACHAR QUE É SQL INJECTION.
function fnFormatarTextbd($texto){
	$formatado=strip_tags($texto);
	$formatado=str_replace('DATA:','DT:',$formatado);
	$formatado=str_replace('Á','&Aacute;',$formatado);
	$formatado=str_replace('á','&aacute;',$formatado);
	$formatado=str_replace('Â','&Acirc;',$formatado);
	$formatado=str_replace('â','&acirc;',$formatado);
	$formatado=str_replace('À','&Agrave;',$formatado);
	$formatado=str_replace('à','&agrave;',$formatado);
	$formatado=str_replace('Å','&Aring;',$formatado);
	$formatado=str_replace('å','&aring;',$formatado);
	$formatado=str_replace('Ã','&Atilde;',$formatado);
	$formatado=str_replace('ã','&atilde;',$formatado);
	$formatado=str_replace('Ä','&Auml;',$formatado);
	$formatado=str_replace('ä','&auml;',$formatado);
	$formatado=str_replace('Æ','&AElig;',$formatado);
	$formatado=str_replace('æ','&aelig;',$formatado);
	$formatado=str_replace('É','&Eacute;',$formatado);
	$formatado=str_replace('é','&eacute;',$formatado);
	$formatado=str_replace('Ê','&Ecirc;',$formatado);
	$formatado=str_replace('ê','&ecirc;',$formatado);
	$formatado=str_replace('È','&Egrave;',$formatado);
	$formatado=str_replace('è','&egrave;',$formatado);
	$formatado=str_replace('Ë','&Euml;',$formatado);
	$formatado=str_replace('ë','&euml;',$formatado);
	$formatado=str_replace('Ð','&ETH;',$formatado);
	$formatado=str_replace('ð','&eth;',$formatado);
	$formatado=str_replace('Í','&Iacute;',$formatado);
	$formatado=str_replace('í','&iacute;',$formatado);
	$formatado=str_replace('Î','&Icirc;',$formatado);
	$formatado=str_replace('î','&icirc;',$formatado);
	$formatado=str_replace('Ì','&Igrave;',$formatado);
	$formatado=str_replace('ì','&igrave;',$formatado);
	$formatado=str_replace('Ï','&Iuml;',$formatado);
	$formatado=str_replace('ï','&iuml;',$formatado);
	$formatado=str_replace('Ó','&Oacute;',$formatado);
	$formatado=str_replace('ó','&oacute;',$formatado);
	$formatado=str_replace('Ô','&Ocirc;',$formatado);
	$formatado=str_replace('ô','&ocirc;',$formatado);
	$formatado=str_replace('Ò','&Ograve;',$formatado);
	$formatado=str_replace('ò','&ograve;',$formatado);
	$formatado=str_replace('Ø','&Oslash;',$formatado);
	$formatado=str_replace('ø','&oslash;',$formatado);
	$formatado=str_replace('Õ','&Otilde;',$formatado);
	$formatado=str_replace('õ','&otilde;',$formatado);
	$formatado=str_replace('Ö','&Ouml;',$formatado);
	$formatado=str_replace('ö','&ouml;',$formatado);
	$formatado=str_replace('Ú','&Uacute;',$formatado);
	$formatado=str_replace('ú','&uacute;',$formatado);
	$formatado=str_replace('Û','&Ucirc;',$formatado);
	$formatado=str_replace('û','&ucirc;',$formatado);
	$formatado=str_replace('Ù','&Ugrave;',$formatado);
	$formatado=str_replace('ù','&ugrave;',$formatado);
	$formatado=str_replace('Ü','&Uuml;',$formatado);
	$formatado=str_replace('ü','&uuml;',$formatado);
	$formatado=str_replace('Ç','&Ccedil;',$formatado);
	$formatado=str_replace('ç','&ccedil;',$formatado);
	$formatado=str_replace('Ñ','&Ntilde;',$formatado);
	$formatado=str_replace('ñ','&ntilde;',$formatado);
	$formatado=str_replace('<','&lt;',$formatado);
	$formatado=str_replace('>','&gt;',$formatado);
	//$formatado=str_replace('&','&amp;',$formatado);
	$formatado=str_replace('"','&quot;',$formatado);
	$formatado=str_replace('®','&reg;',$formatado);
	$formatado=str_replace('©','&copy;',$formatado);
	$formatado=str_replace('Ý','&Yacute;',$formatado);
	$formatado=str_replace('ý','&yacute;',$formatado);
	$formatado=str_replace('Þ','&THORN;',$formatado);
	$formatado=str_replace('þ','&thorn;',$formatado);
	$formatado=str_replace('ß','&szlig;',$formatado);
	return $formatado;
	}
	
	function fnFormatarTextGeral($texto){
	$formatado=strip_tags($texto);
	$formatado=str_replace('<','&lt;',$formatado);
	$formatado=str_replace('>','&gt;',$formatado);
	$formatado=str_replace('Á','&Aacute;',$formatado);
	$formatado=str_replace('á','&aacute;',$formatado);
	$formatado=str_replace('Â','&Acirc;',$formatado);
	$formatado=str_replace('â','&acirc;',$formatado);
	$formatado=str_replace('À','&Agrave;',$formatado);
	$formatado=str_replace('à','&agrave;',$formatado);
	$formatado=str_replace('Å','&Aring;',$formatado);
	$formatado=str_replace('å','&aring;',$formatado);
	$formatado=str_replace('Ã','&Atilde;',$formatado);
	$formatado=str_replace('ã','&atilde;',$formatado);
	$formatado=str_replace('Ä','&Auml;',$formatado);
	$formatado=str_replace('ä','&auml;',$formatado);
	$formatado=str_replace('Æ','&AElig;',$formatado);
	$formatado=str_replace('æ','&aelig;',$formatado);
	$formatado=str_replace('É','&Eacute;',$formatado);
	$formatado=str_replace('é','&eacute;',$formatado);
	$formatado=str_replace('Ê','&Ecirc;',$formatado);
	$formatado=str_replace('ê','&ecirc;',$formatado);
	$formatado=str_replace('È','&Egrave;',$formatado);
	$formatado=str_replace('è','&egrave;',$formatado);
	$formatado=str_replace('Ë','&Euml;',$formatado);
	$formatado=str_replace('ë','&euml;',$formatado);
	$formatado=str_replace('Ð','&ETH;',$formatado);
	$formatado=str_replace('ð','&eth;',$formatado);
	$formatado=str_replace('Í','&Iacute;',$formatado);
	$formatado=str_replace('í','&iacute;',$formatado);
	$formatado=str_replace('Î','&Icirc;',$formatado);
	$formatado=str_replace('î','&icirc;',$formatado);
	$formatado=str_replace('Ì','&Igrave;',$formatado);
	$formatado=str_replace('ì','&igrave;',$formatado);
	$formatado=str_replace('Ï','&Iuml;',$formatado);
	$formatado=str_replace('ï','&iuml;',$formatado);
	$formatado=str_replace('Ó','&Oacute;',$formatado);
	$formatado=str_replace('ó','&oacute;',$formatado);
	$formatado=str_replace('Ô','&Ocirc;',$formatado);
	$formatado=str_replace('ô','&ocirc;',$formatado);
	$formatado=str_replace('Ò','&Ograve;',$formatado);
	$formatado=str_replace('ò','&ograve;',$formatado);
	$formatado=str_replace('Ø','&Oslash;',$formatado);
	$formatado=str_replace('ø','&oslash;',$formatado);
	$formatado=str_replace('Õ','&Otilde;',$formatado);
	$formatado=str_replace('õ','&otilde;',$formatado);
	$formatado=str_replace('Ö','&Ouml;',$formatado);
	$formatado=str_replace('ö','&ouml;',$formatado);
	$formatado=str_replace('Ú','&Uacute;',$formatado);
	$formatado=str_replace('ú','&uacute;',$formatado);
	$formatado=str_replace('Û','&Ucirc;',$formatado);
	$formatado=str_replace('û','&ucirc;',$formatado);
	$formatado=str_replace('Ù','&Ugrave;',$formatado);
	$formatado=str_replace('ù','&ugrave;',$formatado);
	$formatado=str_replace('Ü','&Uuml;',$formatado);
	$formatado=str_replace('ü','&uuml;',$formatado);
	$formatado=str_replace('Ç','&Ccedil;',$formatado);
	$formatado=str_replace('ç','&ccedil;',$formatado);
	$formatado=str_replace('Ñ','&Ntilde;',$formatado);
	$formatado=str_replace('ñ','&ntilde;',$formatado);
	$formatado=str_replace('<','&lt;',$formatado);
	$formatado=str_replace('>','&gt;',$formatado);
	//$formatado=str_replace('&','&amp;',$formatado);
	$formatado=str_replace('"','&quot;',$formatado);
	$formatado=str_replace('®','&reg;',$formatado);
	$formatado=str_replace('©','&copy;',$formatado);
	$formatado=str_replace('Ý','&Yacute;',$formatado);
	$formatado=str_replace('ý','&yacute;',$formatado);
	$formatado=str_replace('Þ','&THORN;',$formatado);
	$formatado=str_replace('þ','&thorn;',$formatado);
	$formatado=str_replace('ß','&szlig;',$formatado);
	return $formatado;
	}

function fnFormatarTextHtml($texto){
	$formatado=strip_tags($texto);
	$formatado=str_replace('Á','&Aacute;',$formatado);
	$formatado=str_replace('á','&aacute;',$formatado);
	$formatado=str_replace('Â','&Acirc;',$formatado);
	$formatado=str_replace('â','&acirc;',$formatado);
	$formatado=str_replace('À','&Agrave;',$formatado);
	$formatado=str_replace('à','&agrave;',$formatado);
	$formatado=str_replace('Å','&Aring;',$formatado);
	$formatado=str_replace('å','&aring;',$formatado);
	$formatado=str_replace('Ã','&Atilde;',$formatado);
	$formatado=str_replace('ã','&atilde;',$formatado);
	$formatado=str_replace('Ä','&Auml;',$formatado);
	$formatado=str_replace('ä','&auml;',$formatado);
	$formatado=str_replace('Æ','&AElig;',$formatado);
	$formatado=str_replace('æ','&aelig;',$formatado);
	$formatado=str_replace('É','&Eacute;',$formatado);
	$formatado=str_replace('é','&eacute;',$formatado);
	$formatado=str_replace('Ê','&Ecirc;',$formatado);
	$formatado=str_replace('ê','&ecirc;',$formatado);
	$formatado=str_replace('È','&Egrave;',$formatado);
	$formatado=str_replace('è','&egrave;',$formatado);
	$formatado=str_replace('Ë','&Euml;',$formatado);
	$formatado=str_replace('ë','&euml;',$formatado);
	$formatado=str_replace('Ð','&ETH;',$formatado);
	$formatado=str_replace('ð','&eth;',$formatado);
	$formatado=str_replace('Í','&Iacute;',$formatado);
	$formatado=str_replace('í','&iacute;',$formatado);
	$formatado=str_replace('Î','&Icirc;',$formatado);
	$formatado=str_replace('î','&icirc;',$formatado);
	$formatado=str_replace('Ì','&Igrave;',$formatado);
	$formatado=str_replace('ì','&igrave;',$formatado);
	$formatado=str_replace('Ï','&Iuml;',$formatado);
	$formatado=str_replace('ï','&iuml;',$formatado);
	$formatado=str_replace('Ó','&Oacute;',$formatado);
	$formatado=str_replace('ó','&oacute;',$formatado);
	$formatado=str_replace('Ô','&Ocirc;',$formatado);
	$formatado=str_replace('ô','&ocirc;',$formatado);
	$formatado=str_replace('Ò','&Ograve;',$formatado);
	$formatado=str_replace('ò','&ograve;',$formatado);
	$formatado=str_replace('Ø','&Oslash;',$formatado);
	$formatado=str_replace('ø','&oslash;',$formatado);
	$formatado=str_replace('Õ','&Otilde;',$formatado);
	$formatado=str_replace('õ','&otilde;',$formatado);
	$formatado=str_replace('Ö','&Ouml;',$formatado);
	$formatado=str_replace('ö','&ouml;',$formatado);
	$formatado=str_replace('Ú','&Uacute;',$formatado);
	$formatado=str_replace('ú','&uacute;',$formatado);
	$formatado=str_replace('Û','&Ucirc;',$formatado);
	$formatado=str_replace('û','&ucirc;',$formatado);
	$formatado=str_replace('Ù','&Ugrave;',$formatado);
	$formatado=str_replace('ù','&ugrave;',$formatado);
	$formatado=str_replace('Ü','&Uuml;',$formatado);
	$formatado=str_replace('ü','&uuml;',$formatado);
	$formatado=str_replace('Ç','&Ccedil;',$formatado);
	$formatado=str_replace('ç','&ccedil;',$formatado);
	$formatado=str_replace('Ñ','&Ntilde;',$formatado);
	$formatado=str_replace('ñ','&ntilde;',$formatado);
	$formatado=str_replace('<','&lt;',$formatado);
	$formatado=str_replace('>','&gt;',$formatado);
	//$formatado=str_replace('&','&amp;',$formatado);
	$formatado=str_replace('"','&quot;',$formatado);
	$formatado=str_replace('®','&reg;',$formatado);
	$formatado=str_replace('©','&copy;',$formatado);
	$formatado=str_replace('Ý','&Yacute;',$formatado);
	$formatado=str_replace('ý','&yacute;',$formatado);
	$formatado=str_replace('Þ','&THORN;',$formatado);
	$formatado=str_replace('þ','&thorn;',$formatado);
	$formatado=str_replace('ß','&szlig;',$formatado);
	return $formatado;
	}
//Função para mesmo que a pessoa escreva com erros graves de português o sistema use inteligência artificial para entender e ir aprendendo.
function fnFormatarTextoChatBot($texto){
	
	$formatado=strip_tags($texto);
	$formatado=trim($formatado);
	$formatado=strtoupper($formatado);
	$formatado=str_replace('Á','A',$formatado);
	$formatado=str_replace('á','A',$formatado);
	$formatado=str_replace('Â','A',$formatado);
	$formatado=str_replace('â','A',$formatado);
	$formatado=str_replace('À','A',$formatado);
	$formatado=str_replace('à','A',$formatado);
	$formatado=str_replace('Å','A',$formatado);
	$formatado=str_replace('å','A',$formatado);
	$formatado=str_replace('Ã','A',$formatado);
	$formatado=str_replace('ã','A',$formatado);
	$formatado=str_replace('Ä','A',$formatado);
	$formatado=str_replace('ä','A',$formatado);
	$formatado=str_replace('Æ','A',$formatado);
	$formatado=str_replace('æ','A',$formatado);
	$formatado=str_replace('É','E',$formatado);
	$formatado=str_replace('é','E',$formatado);
	$formatado=str_replace('Ê','E',$formatado);
	$formatado=str_replace('ê','E',$formatado);
	$formatado=str_replace('È','E',$formatado);
	$formatado=str_replace('è','E',$formatado);
	$formatado=str_replace('Ë','E',$formatado);
	$formatado=str_replace('ë','E',$formatado);
	$formatado=str_replace('Ð','D',$formatado);
	$formatado=str_replace('ð','E',$formatado);
	$formatado=str_replace('Í','I',$formatado);
	$formatado=str_replace('í','I',$formatado);
	$formatado=str_replace('Î','I',$formatado);
	$formatado=str_replace('î','I',$formatado);
	$formatado=str_replace('Ì','I',$formatado);
	$formatado=str_replace('ì','I',$formatado);
	$formatado=str_replace('Ï','I',$formatado);
	$formatado=str_replace('ï','I',$formatado);
	$formatado=str_replace('Ó','O',$formatado);
	$formatado=str_replace('ó','O',$formatado);
	$formatado=str_replace('Ô','O',$formatado);
	$formatado=str_replace('ô','O',$formatado);
	$formatado=str_replace('Ò','O',$formatado);
	$formatado=str_replace('ò','O',$formatado);
	$formatado=str_replace('Ø','O',$formatado);
	$formatado=str_replace('ø','O',$formatado);
	$formatado=str_replace('Õ','O',$formatado);
	$formatado=str_replace('õ','O',$formatado);
	$formatado=str_replace('Ö','O',$formatado);
	$formatado=str_replace('ö','O',$formatado);
	$formatado=str_replace('Ú','U',$formatado);
	$formatado=str_replace('ú','U',$formatado);
	$formatado=str_replace('Û','U',$formatado);
	$formatado=str_replace('û','U',$formatado);
	$formatado=str_replace('Ù','U',$formatado);
	$formatado=str_replace('ù','U',$formatado);
	$formatado=str_replace('Ü','U',$formatado);
	$formatado=str_replace('ü','U',$formatado);
	$formatado=str_replace('Ç','C',$formatado);
	$formatado=str_replace('ç','C',$formatado);
	$formatado=str_replace('Ñ','N',$formatado);
	$formatado=str_replace('ñ','N',$formatado);
	$formatado=str_replace('<','&lt;',$formatado);
	$formatado=str_replace('>','&gt;',$formatado);
	$formatado=str_replace('&','&amp;',$formatado);
	$formatado=str_replace('"','&quot;',$formatado);
	$formatado=str_replace('®','&reg;',$formatado);
	$formatado=str_replace('©','&copy;',$formatado);
	$formatado=str_replace('Ý','&Yacute;',$formatado);
	$formatado=str_replace('ý','&yacute;',$formatado);
	$formatado=str_replace('Þ','&THORN;',$formatado);
	$formatado=str_replace('þ','&thorn;',$formatado);
	$formatado=str_replace('ß','&szlig;',$formatado);
	$formatado=str_replace('Á','&Aacute;',$formatado);
	$formatado=str_replace('á','&aacute;',$formatado);

	//FORMATAÇÃO HTML PARA LETRAS.
	$formatado=str_replace('&Acirc;','A',$formatado);
	$formatado=str_replace('&acirc;','A',$formatado);
	$formatado=str_replace('&Agrave;','A',$formatado);
	$formatado=str_replace('&agrave;','A',$formatado);
	$formatado=str_replace('&Aring;','A',$formatado);
	$formatado=str_replace('&aring;','A',$formatado);
	$formatado=str_replace('&Atilde;','A',$formatado);
	$formatado=str_replace('&atilde;','A',$formatado);
	$formatado=str_replace('&Auml;','A',$formatado);
	$formatado=str_replace('&auml;','A',$formatado);
	$formatado=str_replace('&AElig;','A',$formatado);
	$formatado=str_replace('&aelig;','A',$formatado);
	$formatado=str_replace('&Eacute;','E',$formatado);
	$formatado=str_replace('&eacute;','E',$formatado);
	$formatado=str_replace('&Ecirc;','E',$formatado);
	$formatado=str_replace('&ecirc;','E',$formatado);
	$formatado=str_replace('&Egrave;','E',$formatado);
	$formatado=str_replace('&egrave;','E',$formatado);
	$formatado=str_replace('&Euml;','E',$formatado);
	$formatado=str_replace('&euml;','E',$formatado);
	$formatado=str_replace('&ETH;','D',$formatado);
	$formatado=str_replace('&eth;','E',$formatado);
	$formatado=str_replace('&Iacute;','I',$formatado);
	$formatado=str_replace('&iacute;','I',$formatado);
	$formatado=str_replace('&Icirc;','I',$formatado);
	$formatado=str_replace('&icirc;','I',$formatado);
	$formatado=str_replace('&Igrave;','I',$formatado);
	$formatado=str_replace('&igrave;','I',$formatado);
	$formatado=str_replace('&Iuml;','I',$formatado);
	$formatado=str_replace('&iuml;','I',$formatado);
	$formatado=str_replace('&Oacute;','O',$formatado);
	$formatado=str_replace('&oacute;','O',$formatado);
	$formatado=str_replace('&Ocirc;','O',$formatado);
	$formatado=str_replace('&ocirc;','O',$formatado);
	$formatado=str_replace('&Ograve;','O',$formatado);
	$formatado=str_replace('&ograve;','O',$formatado);
	$formatado=str_replace('&Oslash;','O',$formatado);
	$formatado=str_replace('&oslash;','O',$formatado);
	$formatado=str_replace('&Otilde;','O',$formatado);
	$formatado=str_replace('&otilde;','O',$formatado);
	$formatado=str_replace('&Ouml;','O',$formatado);
	$formatado=str_replace('&ouml;','O',$formatado);
	$formatado=str_replace('&Uacute;','U',$formatado);
	$formatado=str_replace('&uacute;','U',$formatado);
	$formatado=str_replace('&Ucirc;','U',$formatado);
	$formatado=str_replace('&ucirc;','U',$formatado);
	$formatado=str_replace('&Ugrave;','U',$formatado);
	$formatado=str_replace('&ugrave;','U',$formatado);
	$formatado=str_replace('&Uuml;','U',$formatado);
	$formatado=str_replace('&uuml;','U',$formatado);
	$formatado=str_replace('&Ccedil;','C',$formatado);
	$formatado=str_replace('&ccedil;','C',$formatado);
	$formatado=str_replace('&Ntilde;','N',$formatado);
	$formatado=str_replace('&ntilde;','N',$formatado);


	//AGORA VEM FRASES USADAS 
	$formatado=str_replace('VOCE','VC',$formatado);

	$formatado=str_replace('Z','S',$formatado);
	$formatado=str_replace('CI','SI',$formatado);
	$formatado=str_replace('CEM','100',$formatado);
	$formatado=str_replace('CE','SE',$formatado);
	$formatado=str_replace('SS','S',$formatado);



	$formatado=str_replace('UM','1',$formatado);
	$formatado=str_replace('UMA','1',$formatado);
	$formatado=str_replace('DOIS','2',$formatado);
	$formatado=str_replace('TRES','3',$formatado);
	$formatado=str_replace('QUATRO','4',$formatado);
	$formatado=str_replace('SINCO','5',$formatado);
	$formatado=str_replace('SEIS','6',$formatado);
	$formatado=str_replace('SETE','7',$formatado);
	$formatado=str_replace('OITO','8',$formatado);
	$formatado=str_replace('NOVE','9',$formatado);
	$formatado=str_replace('DES','10',$formatado);
	$formatado=str_replace('ONSE','11',$formatado);
	$formatado=str_replace('DOSE','12',$formatado);
	$formatado=str_replace('TRESE','13',$formatado);
	$formatado=str_replace('QUATORSE','14',$formatado);
	$formatado=str_replace('CATORSE','14',$formatado);
	$formatado=str_replace('QUINSE','15',$formatado);
	$formatado=str_replace('DESESEIS','16',$formatado);
	$formatado=str_replace('DESESETE','17',$formatado);
	$formatado=str_replace('DESOITO','18',$formatado);
	$formatado=str_replace('DESENOVE','19',$formatado);
	$formatado=str_replace('VINTE','20',$formatado);
	$formatado=str_replace('TRINTA','30',$formatado);
	$formatado=str_replace('QUARENTA','40',$formatado);
	$formatado=str_replace('SINQUENTA','50',$formatado);
	$formatado=str_replace('SESENTA','60',$formatado);
	$formatado=str_replace('SETENTA','70',$formatado);
	$formatado=str_replace('OITENTA','80',$formatado);
	$formatado=str_replace('NOVENTA','90',$formatado);

	$formatado=str_replace('MIL','1000',$formatado);
	$formatado=str_replace('ZERO','0',$formatado);

	//TIRA OS ESPAÇOS
	$formatado=str_replace(' ','',$formatado);

	$formatado=str_replace('NUNCA','NAO',$formatado);
	$formatado=str_replace('JAMAIS','NAO',$formatado);
	$formatado=str_replace('NAOCONCORDO','NAO',$formatado);
	$formatado=str_replace('DEFORMANENHUMA','NAO',$formatado);
	$formatado=str_replace('NAOGOSTEI','NAO',$formatado);
	$formatado=str_replace('NAOQUERO','NAO',$formatado);
	$formatado=str_replace('NAOESTOUDEACORDO','NAO',$formatado);
	$formatado=str_replace('NAOFECHADO','NAO',$formatado);

	$formatado=str_replace('OK','SIM',$formatado);
	$formatado=str_replace('YES','SIM',$formatado);
	$formatado=str_replace('CONCORDO','SIM',$formatado);
	$formatado=str_replace('ACEITO','SIM',$formatado);
	$formatado=str_replace('GOSTEI','SIM',$formatado);
	$formatado=str_replace('QUERO','SIM',$formatado);
	$formatado=str_replace('DEACORDO','SIM',$formatado);
	$formatado=str_replace('FECHADO','SIM',$formatado);

	if ($texto==""){
		$formatado=" ";
	}

	return $formatado;
};


/************************************************************************************************************************************************************************************************************************************* 
 
	* FIM  DAS FUNÇÕES EM PHP

************************************************************************************************************************************************************************************************************************************ */

?>







<script type="text/javascript">
//*************************************************************************************************************
/**
@name pfnTrim
@description Elimina caracteres em branco do lado direito e esquerdo de uma string (enters, tabs, tabs verticais 
 e espa�os)
@created 31/12/2003
@param str: a string da qual se quer retirar os espa�os em branco
@return a string passada sem nenhum espa�o nas extremidades

*/
function pfnTrim(str)
{
    return str.replace(/(\s)*$|^(\s)*/g, "");
}
/**
@name fnRetornaIdade
@description onblur=fnPreencheIdade(idade(31/12/1980,txIdade)); //  33
@created 11/05/2021
@param ano mês e dia.
@return retorna a idade já calculada e preeche o campo.

*/

function fnPreencheIdade(data1,campoDestino) {
	if (pfnTrim(data1) == ""){
		return true;
	} 
	else{

		// recupere e quebre as datas
		var partesDt1 = data1.split("-");
		var dia1 = partesDt1[2];
		var mes1 = partesDt1[1];
		var ano1 = partesDt1[0];
		
		var idade = fnRetornaIdade(ano1, mes1, dia1);

		document.getElementById(campoDestino).value=idade;
	};
};
/**@name fnRetornaIdade
@description console.fnRetornaIdade(idade(1980, 12, 11)); //  33
@created 11/05/2021
@param ano mês e dia.
@return retorna a idade já calculada.

*/
function fnRetornaIdade(ano_aniversario, mes_aniversario, dia_aniversario) {
    var d = new Date,
        ano_atual = d.getFullYear(),
        mes_atual = d.getMonth() + 1,
        dia_atual = d.getDate(),

        ano_aniversario = +ano_aniversario,
        mes_aniversario = +mes_aniversario,
        dia_aniversario = +dia_aniversario,

        quantos_anos = ano_atual - ano_aniversario;

    if (mes_atual < mes_aniversario || mes_atual == mes_aniversario && dia_atual < dia_aniversario) {
        quantos_anos--;
    }

    return quantos_anos < 0 ? 0 : quantos_anos;
}

</script>


<script type="text/javascript">

/************************************************************************************************************************************************************************************************************************************* 
 
	* INÍCIO  DAS FUNÇÕES EM JAVA SCRIPT

************************************************************************************************************************************************************************************************************************************ */

/**


@name GeneralLib.js
@description Fornece m�todos de utilidade geral
@methods 
	BloqueiaAspas, 
	pfnCancelar, 
	pfnLTrim, 
	pfnMensagemErro,
	pfnInserirOption(PCampo,PValue,PText),
	pfnIsNumeric, 
	pfnNormalize, 
	pfnPreecheRB, 
	pfnRTrim, 
	pfnSubmit, 
	pfnSelecioneRadio,
	pfnTrim
@created 05/11/2003

*/


//*************************************************************************************************************
/**
@name BloqueiaAspas
@description Bloqueia o usu�rio de digitar aspas simples ou duplas em um campo
@created 27/11/2003
@param e: o evento que representa a tecla digitada
@return true, se a tecla digitada for diferente de uma aspa simples ou dupla, false, caso contr�rio

*/
function BloqueiaAspas(e)
{
    var tecla = event.keyCode;
    // bloqueie aspas simples e dupla e sustenido
    if (tecla == 39 || tecla == 34 || tecla == 35 || tecla == 92) 
        event.keyCode = 0;
}

//*************************************************************************************************************
/**
@name BloqueiaCaracteresEspecificos
@description Bloqueia o usu�rio de digitar caracteres que n�o forem alfa n�mericos.
@created 27/11/2006
@param e: o evento que representa a tecla digitada
@return true, se a tecla digitada for diferente dos caracteres Alfa N�mericos
*/
function BloqueiaCaracteresEspecificos()
{
    var tecla = event.keyCode;
    // bloqueie caracteres especiais, s� deixa letra e n�mero.
    if ((tecla < 48) ||(tecla > 57 && tecla < 65) || (tecla > 90 && tecla < 97) || (tecla > 122)) 
        event.keyCode = 0;
}
//*************************************************************************************************************
/**
@name pfnBuscarEntre
@description Retorna a string que est� entre determinado dados.
@created 19/12/2005
@param StrInicial O valor inicial de onde deve iniciar a busca
@param StrFinal O valor final at� onde retornar
@param StringCompleta A string completa.
@return a string que est� entre os dois valores.

*/
//*************************FAZER CONSULTA PARA ENCONTRAR ALGO ENTRE DETERMINADOS CAMPOS, 
function fnPesquisarEntreCampos($CampoA,$CampoB,$CampoMax){

	//pega a primeira posição
	$posA      = stripos($CampoMax, $CampoA);

	if( $posA== false){
		return "";
	} else{
		//pega o restante
		$CampoMax=substr($CampoMax,$posA,strlen($CampoMax));
		if($posB== false){
			return "";
		} else{
			//pega a posição do restante.
			$posB      = stripos($CampoMax,$CampoB);

			//pega o valor do retorno
			return substr($CampoMax,strlen($CampoA),$posB-strlen($CampoB)+1);
		};
	};
};
//igual essa 
function pfnBuscarEntre(StringCompleta,StrInicial,StrFinal)
{
	if(StringCompleta.indexOf(StrInicial)==-1){
		StringCompleta="";
	}
	StringCompleta2=substring(StringCompleta,StringCompleta.indexOf(StrInicial)+StrInicial.length,StringCompleta.length);
	if(StringCompleta2.indexOf(StrFinal)==-1){
		StringCompleta2="";
	}
	//agora a partir daquele ponto.
	StringCompleta3=substring(StringCompleta2,0,StringCompleta2.indexOf(StrFinal));
	return StringCompleta3;
}
function pfnBuscarEntre2(StringCompleta,StrInicial,StrFinal)
{
	return StringCompleta.substring(StringCompleta.indexOf(StrInicial)+StrInicial.length,StringCompleta.indexOf(StrFinal));
}
//*************************************************************************************************************
/**
@name checkForEnter
@description Simula um click no bot�o espeficificado quando o usu�rio aperta enter
@created 18/08/2004
@param buttonName: o nome do bot�o a ser clicado

*/
function checkForEnter(buttonName)
{
	// o return est� aqui porque, em campos onde a valida��o � feita no onblur,
	// a valida��o geral do formul�rio est� interferindo. Quando os erros forem
	// exibidos por meio de spans, retire o return.
	return;
    // recupere o bot�o especificado
    var button = document.getElementById(buttonName);
    if (event.keyCode == 13)
        button.click(); 
}


//*************************************************************************************************************
/**
@name checkForEnterFocus
@description D� foco em um input quando o usu�rio aperta enter em algum input
@created 19/10/2004
@param inputName: o nome do input que receber� o foco

*/
function checkForEnterFocus(inputName)
{
    // recupere o bot�o especificado
    var input = document.getElementById(inputName);
    if (event.keyCode == 13 && input != null && input.style.visibility != "hidden" && 
      input.style.display != "none" && !input.disabled)
    {
        input.focus();
    }
}


//*************************************************************************************************************
/**
@name pfnCancelar
@description Pergunta ao usu�rio se deseja cancelar uma opera��o qualquer e, caso
 afirmativo, o redireciona � p�gina especificada pelo usu�rio
@created 05/11/2003
@param paginaRedirecionar: p�gina � qual o usu�rio ser� redirecionado caso deseje cancelar a opera��o
@param mensagem: A mensagem que ser� mostrada ao usu�rio perguntando se ele deseja cancelar a opera��o
@return N�o retorna nada

*/
function pfnCancelar(paginaRedirecionar, mensagem)
{
    // assuma que o redirecionamento acontecer�
    var doRedirect = true;
    
    // verifique se h� alguma mensagem a ser mostrada
    if (mensagem != "")
    {
        // somente se houver uma mensagem a ser mostrada e o usu�rio n�o confirmar o redirecionamento, este
        // n�o dever� ocorrer
        if (!confirm(mensagem))
            doRedirect = false;
    }
    
    // antes de redirecionar o usu�rio, verifique se a p�gina de redirecionamento n�o � vazia
    if (doRedirect && paginaRedirecionar != "")
        window.location = paginaRedirecionar;
}

    
//*************************************************************************************************************
/**
@name pfnEnable
@description Habilita ou desabilita um campo
@created 27/05/2004
@param inputName: o campo que ser� habilitado ou n�o
@param toggle: determina se o campo ser� habilitado ou desabilitado
@param onclickName: o nome do evento onclick a ser atribu�do ao elemento

*/
function pfnEnable(inputName, toggle, onclickName)
{
 	var input = document.getElementById(inputName);
 	if (input != null)
 	{
	 	input.disabled = !toggle;
		if (onclickName != '')
			document.getElementById(inputName).onclick = onclickName;
	}
}

//*************************************************************************************************************
/**
@name pfnFormataTelefone
@description Formata o telefone � medida que os caracteres s�o digitados
 Inclui as barras. N�o permite a digita��o de caracteres que n�o sejam n�meros
 Deve ser usada no evento onKeyPress
@created 30/10/2003
@param input: o campo onde o telefone � digitado
@return N�o retorna nada
@author Marcos Lopes Conde
*/
function pfnFormataTelefone(input)
{
	if (event.keyCode < 48 || event.keyCode > 57)
		event.returnValue = false;
	else
	{
		var data = input.value;
		// verifique se todos os n�meros fora as barras s�o de fato n�mero
		if(data.length == 1)
		{
			data = input.value;
			data = data.replace("(","");
			data = "(" + data;
			input.value = data;
		}
		
		if(data.length == 3)
			input.value = input.value + ")";
		if(data.length == 8)
			input.value = input.value + "-";
	}
}

//*************************************************************************************************************
/**
@name pfnFormataTelefone
@description Formata o telefone quando perde o foco.
 Inclui as barras. N�o permite a digita��o de caracteres que n�o sejam n�meros
 Deve ser usada no evento onBlur
@created 30/10/2003
@param input: o campo onde o telefone � digitado
@return N�o retorna nada
@author Marcos Lopes Conde
*/
function pfnFormataeValidaTelefone(input,mensagem)
{

	try 
	{
	if (input.value!='') 
	{
		if (mensagem=='')
			mensagem = 'Valor inv�lido';
				
			var dataInicial = input.value;
			var data = dataInicial.replace("(","");
			data = data.replace(")","");
			data = data.replace("-","");
			if(data.length != 10)
			 { 
				alert(mensagem);
				//para focar no final
				input.value= input.value+ "";
				return false;
			 }
			 input.value = data;
			//essa fun��o est� na valida��o de n�mero.
			if (!pfnValideNumeric(input, mensagem))
			{
				input.value = dataInicial;
				return false;
			}
			input.value = "("+ data.substring(0, 2)+ ")"+data.substring(2, 6) + "-" + data.substring(6, 10);
		}						
	}
	catch(e) 
	{						// Caso ocorra algum erro.
		alert(e);
		return(e + " ocorreu um erro ao execultar a fun��o.");		// Retorna a mensagem de erro.
	}
}



//*************************************************************************************************************
/**
@name pfnFocus
@description Focaliza o input com o id especificado
@created 09/11/2004
@return inputName: the id of the element to focus

*/
function pfnFocus(inputId)
{
  if (document.getElementById(inputId) != null)
  {
    document.getElementById(inputId).focus();
  }
}


//*************************************************************************************************************
/**
@name pfnGoTo
@description Redireciona o usu�rio para a p�gina especificada
@created 29/04/2004
@return target: a p�gina para a qual o usu�rio ser� redirecionado

*/
function pfnGoTo(target)
{
    window.location = target;
}

//*************************************************************************************************************
/**
@name pfnInserirOption
@description Inclui um novo option no select.
@created 05/12/2005
@param PCampo: O campo que ser� select que ser� inserido o option. Ex document.frmPrincipal.ipslLog ou document.getElementById("ipslLog")
@param PValue: O campo value que fica oculto mas ser� enviado pelo form para a pr�xima p�gina.
@param PText : O campo de texto que ser� mostrado ao cliente.
@return N�o retorna nada
@author Marcos Lopes Conde.
*/
function pfnInserirOption(PCampo,PValue,PText)
{
	if (PCampo != undefined)
	{
		// INSERE UM NOVO CAMPO.
		// Cria um elemento select.
		var oOption = document.createElement("OPTION");
		// Insere o texto.
		oOption.text=PValue;
		// Insere o value.
		oOption.value=PText;
		// Insere a op��o no select.
		PCampo.add(oOption);
	}
}
//*************************************************************************************************************
/**
@name pfnIsAlphaNumeric
@description Determina se a �ltima tecla digitada � um d�gito ou uma letra (e opcionalmente um espa�o)
@created 10/04/2003
@return true, se a tecla for um d�gito ou letra (ou espa�o), false, caso contr�rio

*/
function pfnIsAlphaNumeric(permiteEspaco)
{
    var code = event.keyCode;
    if ((code == 32 && !permiteEspaco) || (code < 48 && code != 32) || (code > 57 && code < 65) || (code > 90 && code < 97) || code > 122)
    {
        event.returnValue = false;
        return false;
    }
    else
    {
        event.returnValue = true;
        return true;
    }
}   


//*************************************************************************************************************
/**
@name pfnLTrim
@description Elimina caracteres em branco do lado esquerdo de uma string (enters, tabs, tabs verticais e espa�os)
@created 31/12/2003
@param str: a string da qual se quer retirar os espa�os em branco
@return a string passada sem nenhum espa�o do lado esquerdo

*/
function pfnLTrim(str)
{
    return str.replace(/^(\s)*/g, "");
}

//*************************************************************************************************************
/**
@name pfnMensagemErro
@description Mostra a mensagem de erro ao cliente.
@Mensagem : A mensagem que ser� exibida ao cliente.
@Form: O nome do form onde est� o campo que ser� focado.
@CampoFocar: O nome do campo que ser� focado.
@Div : Se a mensagem for aparecer em um Div.
@created 05/12/2005
@return N�o retorna nada
@author Marcos Lopes Conde.
*/
function pfnMensagemErro(Mensagem,Form,CampoFocar,Div)
{
	if (Div=='')
	{
		alert(Mensagem);
	}
	else
	{
	   eval(Div + '.innerHTML = ' + Mensagem);
	}
	if (CampoFocar!=''&& Form!='')
	{
		eval('document.' + Form + '.' + CampoFocar + '.focus();');
	}
}

/**
@name pfnValidaCampo(Campo,Mensagem,TipoValidacao)
@description Valida os campos.
@params Campo : Pega o campo
@params Mensagem: A mensagem que ser� mostrada ao usu�rio, se vier em branco mostra a mensagem padr�o.
@params TipoValidacao: Tipo de valida��o para o usu�rio.
@params Div: Se tem algum div especifico para mostrar a mensagem.
@created 11/02/2006
@return N�o retorna nada
*/
function pfnValidaCampo(Campo,Mensagem,TipoValidacao,Div)
{
	try
	{
        switch (TipoValidacao.toUpperCase()) 
        {
			case "OBRIGAT�RIO":
			case "OBRIGATORIO":
				//Verifica se est� escrito obrigat�rio ou obrigatorio e entra nesta condi��o.
				//Verifica se o campo existe.
				if (Campo!=undefined)
				{
				
					var TipoCampo = Campo.type;
					//Deixa o tipo no formato minusculo.			
					TipoCampo = TipoCampo.toLowerCase();
					//Se for campo select.
					if (TipoCampo == 'select-one')				
					{	
						//Retira os espa�os e verifica se o campo est� em branco.
						if (Campo.selectedIndex == 0)
						{
							//Define este campo para receber o foco.
							campoToFocus = Campo;
							//Verifica se tem mensagem se n�o tiver coloca a mensagem padr�o de erro.
  							if (pfnTrim(Mensagem) !='')
  							{
  								throw Mensagem;
  							}
  							else
  							{
  								throw "Preenchimento do campo obrigat�rio.";
  							}
  						}
  					}
  					else
  					{
						//Retira os espa�os e verifica se o campo est� em branco.
						if (pfnTrim(Campo.value) == '')
						{
							//Define este campo para receber o foco.
							campoToFocus = Campo;
							//Verifica se tem mensagem se n�o tiver coloca a mensagem padr�o de erro.
  							if (pfnTrim(Mensagem) !='')
  							{
  								throw Mensagem;
  							}
  							else
  							{
  								throw "Preenchimento do campo obrigat�rio.";
  							}
  						}
					}
  				}
  				else
  				{
  					throw "Campo inexistente."+Mensagem;  			
					// se for um campo inexistente pode ser porque o usu�rio n�o tem permiss�o para ver o campo, ai ficou inexistente
					//return false;// se retornar assim � porque est� correto.
  				}
			case "MAIORMENOR":
			case "NUMERICO":
			case "LETRA":
			default:
        }
	}
	catch (e)
	{
		//Verifica se ocorreu algum erro no servidor.
		if (pfnTrim(e)=='')
		{
			alert('E00 - Ocorreu um erro no servidor:' + e.description)
		}
		else	
		{
			// Mostra a mensagem de erro.
			alert(e);
			var TipoCampo = campoToFocus.type;
			
			//Deixa o tipo no formato minusculo.			
			TipoCampo = TipoCampo.toLowerCase()
			if ((TipoCampo != 'hidden') && (campoToFocus.style.visible != 'none'))
			{
				//Se for estes tipos pode receber foco.
				if (	
						TipoCampo == 'button'	||
						TipoCampo == 'submit'	||
						TipoCampo == 'text'		||
						TipoCampo == 'textarea' ||				
						TipoCampo == 'reset'
					)				
					{	
						campoToFocus.focus();
					}
				//Se for campo select.
				if (TipoCampo == 'select-one')				
					{	
						campoToFocus.focus();
					}			

			}	
		}
		//retorno verdadeiro, deu erro, o padr�o � retornar falso..
		return true;
	}
	
}

//*************************************************************************************************************
/**
@name pfnNormalize
@description Completa uma string o n�mero especificado de d�gitos. Se a string passada contiver menos
 d�gitos do que o especificado, completa a string � esquerda com a string passada
 A string passada precisa ter um caractere, caso contr�rio nada � feito e original � retornado
 Se original contiver length ou mais caracteres, nada � feito e original � retornado
@created 31/12/2003
@param original: a string original
@param length: o tamanho desejado da string final
@param strToReplace: a string a completar original
@param left: se for true, strToReplace � concatenada � esquerda, caso
 contr�rio � concatenada � direita
@return a string passada sem nenhum espa�o nas extremidades
*/
function pfnNormalize(original, length, strToReplace, left)
{
    if (strToReplace.length != 1 || original.length >= length)
        return original;
    else
    {
        var strToConcatenate = "";
        for (i = 0; i < length - original.length; i++)
            strToConcatenate = strToConcatenate + strToReplace;
        
        if (left)
            return strToConcatenate + original;
        else
            return original + strToConcatenate;
    }
}


//*************************************************************************************************************
/**
@name pfnPreencheHidden
@description Preenche um input hidden com o valor text do index especificado de um campo select
@param inputHdId: o id do input hidden
@param select: o elemento select
@return N�o retorna nada
@author Marcos Lopes Conde.
*/
function pfnPreencheHidden(inputHdId, select)
{
	var input = document.getElementById(inputHdId);
	if (input != null)
    input.value = select.options[select.selectedIndex].text;
}
//*************************************************************************************************************
/**
@name fnPreencheCBAutomaticamente
@description Ao focar um campo de texto seleciona automaticamente o RB
@created 15/01/2004
@param pNomeform: O nome do Form
@param pNomeCampo: O nome do Campo Radio n�o � o nome do campo texto
@param preencheRBNumero: O N�mero do r�dio button que vc deseja selecionar
@return N�o retorna nada
@author Marcos Condes Lopes
*/
function fnPreencheCBAutomaticamente(campoSelecionado,NomeCampoHDSelect,valor)
{
	//alert(document.getElementById(NomeCampoHDSelect).value);
   // var valoratual;
    //pega o valor do Radio para verificar se j� est� checado.
   // eval('valoratual = document.' + pNomeform + '.' + pNomeCampo + '[' + preencheRBNumero + '].checked;');
    //se n�o fizer este if e dar checkin duas vezes d� um erro no java script.
  //  if( valoratual == false)
    //    eval('document.' + pNomeform + '.' + pNomeCampo + '[' + preencheRBNumero + '].checked = true;');   
	//alert(campoSelecionado.checked);
	if(campoSelecionado.checked)
	{
		//adiciona.
		document.getElementById(NomeCampoHDSelect).value = document.getElementById(NomeCampoHDSelect).value+'#'+valor+'#';
	}
	else
	{
	//exclui
				data = document.getElementById(NomeCampoHDSelect).value;
				data = data.replace('#'+valor+'#','');
				document.getElementById(NomeCampoHDSelect).value =data;
	} 
	//alert(NomeCampoHDSelect);
	//alert(document.getElementById(NomeCampoHDSelect).value);
}
//*************************************************************************************************************
/**
@name fnPreencheCBAutomaticamenteDpreenchimento
@description Ao focar um campo de texto seleciona automaticamente o RB
@created 15/01/2004
@param valor: valor para ser gravado
@param NomeCampoHDSelect: Campo exclu�do
@param ipSegundoCampo: � um segundo campo no qual a pessoa digita uma informa��o.
@return N�o retorna nada
@author Marcos Condes Lopes
*/
function fnPreencheCBAutomaticamenteDpreenchimento(campoSelecionado,NomeCampoHDSelect,valor,NomeCampoHDSelect2,ipSegundoCampo)
{
	
	if(campoSelecionado.checked)
	{
		//adiciona o id do campo
		document.getElementById(NomeCampoHDSelect).value = document.getElementById(NomeCampoHDSelect).value+'#'+valor+'#';
		//adiciona o valor do segundo campo.
		document.getElementById(NomeCampoHDSelect2).value = document.getElementById(NomeCampoHDSelect2).value+'#'+ipSegundoCampo+'#';
		document.getElementById(ipSegundoCampo).disabled = false;
	}
	else
	{
	//exclui
		document.getElementById(ipSegundoCampo).disabled = true;	
		data = document.getElementById(NomeCampoHDSelect).value;
		data = data.replace('#'+valor+'#','');
		document.getElementById(NomeCampoHDSelect).value =data;
		
		data = document.getElementById(NomeCampoHDSelect2).value;
		data = data.replace('#'+ipSegundoCampo+'#','');
		document.getElementById(NomeCampoHDSelect2).value =data;
		//limpa o campo que estava escrito.
		document.getElementById(ipSegundoCampo).value="";		
		
		//gravar os nomes dos campos e enviar eles document.getElementById(NomeCampoHDSelect2).value = document.getElementById(NomeCampoHDSelect2).value+'#'+document.getElementById(ipSegundoCampo).value+'#';				
	} 
	//alert(NomeCampoHDSelect);
	//alert(document.getElementById(NomeCampoHDSelect).value);
}
//*************************************************************************************************************
/**
@name fnPreencheCBAutomaticamenteDpreenchimento
@description Ao focar um campo de texto seleciona automaticamente o RB
@created 15/01/2004
@param valor: valor para ser gravado
@param NomeCampoHDSelect: Campo exclu�do
@param ipSegundoCampo: � um segundo campo no qual a pessoa digita uma informa��o.
@return N�o retorna nada
@author Marcos Condes Lopes
*/
function fnPreencheCBAutomaticamenteOnBlur(campoSelecionado,NomeCampoHDSelect,valor,NomeCampoHDSelect2,ipSegundoCampo,checkBox)
{
	//adiciona os valores
	if(campoSelecionado.value=="")
	{
		//adiciona os campos
		document.getElementById(checkBox).checked = false;
		//adiciona o id do campo
		document.getElementById(NomeCampoHDSelect).value = document.getElementById(NomeCampoHDSelect).value+'#'+valor+'#';
		//adiciona o valor do segundo campo.
		document.getElementById(NomeCampoHDSelect2).value = document.getElementById(NomeCampoHDSelect2).value+'#'+ipSegundoCampo+'#';
	}
	else
	{
		//exclui os valores
		document.getElementById(checkBox).checked = true;
		data = document.getElementById(NomeCampoHDSelect).value;
		data = data.replace('#'+valor+'#','');
		document.getElementById(NomeCampoHDSelect).value =data;
		
		data = document.getElementById(NomeCampoHDSelect2).value;
		data = data.replace('#'+ipSegundoCampo+'#','');
		document.getElementById(NomeCampoHDSelect2).value =data;
		
		//gravar os nomes dos campos e enviar eles document.getElementById(NomeCampoHDSelect2).value = document.getElementById(NomeCampoHDSelect2).value+'#'+document.getElementById(ipSegundoCampo).value+'#';				
	} 
	//alert(NomeCampoHDSelect);
	//alert(document.getElementById(NomeCampoHDSelect).value);
}
//*************************************************************************************************************
/**
@name fnPreencheCBEnviaOsCampos
@description Ao focar um campo de texto seleciona automaticamente o RB
@created 15/01/2004
@param valor: valor para ser gravado
@param NomeCampoHDSelect: Campo exclu�do
@param ipSegundoCampo: � um segundo campo no qual a pessoa digita uma informa��o.
@return N�o retorna nada
@author Marcos Condes Lopes
*/
function fnPreencheCBEnviaOsCampos(NomeCampoHDSelect2)
{
	//alert("TodosOsCamposSelecionados");
	TodosOsCamposSelecionados =document.getElementById(NomeCampoHDSelect2).value;
	TodosOsValores="";	
   // var valoratual;
    //pega o valor do Radio para verificar se j� est� checado.
   // eval('valoratual = document.' + pNomeform + '.' + pNomeCampo + '[' + preencheRBNumero + '].checked;');
    //se n�o fizer este if e dar checkin duas vezes d� um erro no java script.
  //  if( valoratual == false)
    //    eval('document.' + pNomeform + '.' + pNomeCampo + '[' + preencheRBNumero + '].checked = true;');   
	//alert(TodosOsCamposSelecionados);
	while(TodosOsCamposSelecionados!="")
	{
		//pega o campo
		//StringCompleta.substring(StringCompleta.indexOf(StrInicial)+StrInicial.length,StringCompleta.indexOf(StrFinal))
		ipSegundoCampo = TodosOsCamposSelecionados.substring(1,TodosOsCamposSelecionados.length);
	//	alert("ipSegundoCampo");		
	//	alert(ipSegundoCampo);
	//	alert(ipSegundoCampo.indexOf("#"));
		ipSegundoCampo = ipSegundoCampo.substring(0,ipSegundoCampo.indexOf("#"));		
	//	alert("ipSegundoCampo");		
	//	alert(ipSegundoCampo);
		//adiciona ele na vari�vel
		TodosOsValores = TodosOsValores+'#'+document.getElementById(ipSegundoCampo).value+'#';		
	//			alert("TodosOsValores");
	//	alert(TodosOsValores);		
		if (pfnValidaCampo(document.getElementById(ipSegundoCampo),'O preenchimento do campo Quantidade de HST � obrigat�rio, quando a op��o � selecionada.','OBRIGATORIO','')){return false;}; 
		//exclui
		data = TodosOsCamposSelecionados;
		data = data.replace('#'+ipSegundoCampo+'#','');
		TodosOsCamposSelecionados =data;
	}
	//alert("fora do for TodosOsCamposSelecionados");
	//alert(TodosOsCamposSelecionados);
	document.getElementById(NomeCampoHDSelect2).value =TodosOsValores;
	return true;
}
//*************************************************************************************************************
/**
@name pfnPreecheRB
@description Ao focar um campo de texto seleciona automaticamente o RB
@created 15/01/2004
@param pNomeform: O nome do Form
@param pNomeCampo: O nome do Campo Radio n�o � o nome do campo texto
@param preencheRBNumero: O N�mero do r�dio button que vc deseja selecionar
@return N�o retorna nada
@author Marcos Condes Lopes
@exemplo <input onClick="fnGeneralLibJSPodeCancelar('deseja cancelar','inicio.asp');"></input>
*/
function pfnPreecheRB(pNomeform,pNomeCampo,preencheRBNumero)
{
    var valoratual;
    //pega o valor do Radio para verificar se j� est� checado.
    eval('valoratual = document.' + pNomeform + '.' + pNomeCampo + '[' + preencheRBNumero + '].checked;');
    //se n�o fizer este if e dar checkin duas vezes d� um erro no java script.
    if( valoratual == false)
        eval('document.' + pNomeform + '.' + pNomeCampo + '[' + preencheRBNumero + '].checked = true;');    
}


//*************************************************************************************************************
/**
@name pfnRTrim
@description Elimina caracteres em branco do lado direito de uma string (enters, tabs, tabs verticais e espa�os)
@created 31/12/2003
@param str: a string da qual se quer retirar os espa�os em branco
@return a string passada sem nenhum espa�o do lado direito

*/
function pfnRTrim(str)
{
    return str.replace(/(\s)*$/g, "");
}


//*************************************************************************************************************
/**
@name pfnSelecioneRadio
@description Seleciona ou deseleciona o input type radio especificado, no index especificado
 O par�metro seleciona determina se a op��o ser� selecionada ou deselecionada
@created 05/12/2003
@param radioName: o nome do input
@param index: o index da op��o (0-based)
@param seleciona: um boolean (ou string "true" ou "false") que determina se a op��o ser� selecionada
 ou deselecionada
@return N�o retorna nada

*/
function pfnSelecioneRadio(radioName, index, seleciona)
{
    // primeiro verifique se o radio existe, e se o index do radio existe
    eval("var existe = document.all('" + radioName + "') != null;");
    eval("existe = existe && (document.all('" + radioName + "')[" + index + "] != null);");
    // se ele existir
    if (existe)
    {
        var statement = "document.all('" + radioName + "')[" + index + "].checked = " + seleciona + ";";
        eval(statement);
    }
}

//*************************************************************************************************************
/**
@name pfnReplaceAll(StringOriginal,StringSubstituir,StringSubstituirPor)
@description Substitui todas as palavras em uma string.
@created 31/12/2005
@param StringOriginal: a string da qual ser� substitu�da.
@param StringSubstituir: a express�o a ser procurada e substitu�da.
@param StringSubstituirPor: a express�o a ser colocada no lugar da palavra substitu�da.
@return a string passada totalmente substitu�da, pois o replace s� substitui a primeira ocorr�ncia.
@author Marcos Lopes Conde
*/
function pfnReplaceAll(StringOriginal,StringSubstituir,StringSubstituirPor)
{
	var ResultadoStr = '';
	var i;
	// quebre a lista
	var ids = StringOriginal.split(StringSubstituir);
	// procure por selected na lista
	for (i = 0; i < ids.length; i++)
	{
		if (ids.length-1 == i)	
		{	
			ResultadoStr = ResultadoStr + ids[i];
		}
		else
		{
			ResultadoStr = ResultadoStr + ids[i] + StringSubstituirPor;
		}		
	}	
	return ResultadoStr; 
}
//*************************************************************************************************************
/**
@name pfnSubmit
@description Submete o formul�rio para a p�gina especificada, e antes armazena no elemento especificado o 
 nome do elemento que submeteu o formul�rio
@created 17/12/2003
@param target: o nome da p�gina que ser� atribu�do ao par�metro action do formul�rio
@param formName: o nome do formul�rio
@param holdingElement: o nome do elemento que armazenar� o nome do elemento que fez com que o
 foruml�rio fosse submetido
@param causeElementName: o nome do elemento que fez com que o formul�rio fosse submetido
@return N�o retorna nada

*/
function pfnSubmit(target, formName, holdingElement, causeElementName)
{
    // s� atribua a causa ao elemento caso o elemento que armazena a raz�o e o nome do elemento que causou
    // a submiss�o tenham sido especificados
    if (causeElementName != "" && holdingElement != "")
    {
        eval("document.all.item('" + holdingElement + "').value = '" + causeElementName + "';");
    }
    // s� atribua o target do formul�rio caso este par�metro tenha sido especificado
    if (target != "")
    {
        eval("document." + formName + ".action = '" + target + "';");
    }
    
    // submeta o formul�rio
    eval("document." + formName + ".submit();");
}


//*************************************************************************************************************
/**
@name pfnSubmitConfirmation
@description Submete o formul�rio para a p�gina especificada se o usu�rio confirmar a opera��o
@created 06/10/2004
@param target: o nome da p�gina que ser� atribu�do ao par�metro action do formul�rio
@param formName: o nome do formul�rio
@param holdingElement: o nome do elemento que armazenar� o nome do elemento que fez com que o
 foruml�rio fosse submetido
@param causeElementName: o nome do elemento que fez com que o formul�rio fosse submetido
@param mensagem: A mensagem a ser exibida ao usu�rio
@return N�o retorna nada

*/
function pfnSubmitConfirmation(target, formName, holdingElement, causeElementName, mensagem)
{
    if (confirm(mensagem))
	 	pfnSubmit(target, formName, holdingElement, causeElementName);
}





//*************************************************************************************************************
/**
@name pfnValideAspas
@description Verifica se existem caracteres proibidos no campos especificado
@created 20/10/2004
@param input: o campo a ser validado
@param msgErro: a mensagem de erro a ser exibida. Se estiver vazia, n�o exibe nada
@return true, se a valida��o tiver sucesso, ou false, caso contr�rio

*/
function pfnValideAspas(input, msgErro)
{
	if (input != null)
	{
	   var matches = input.value.match(/[\'#\\\"]/g);
		if (matches != null && matches.length > 0)
		{
			if (msgErro != "")
			{
				alert(msgErro);
				input.select();
				input.focus();
				return false;
			}
		}
	}
	return true;
}

//*************************************************************************************************************
/**
@name pfnValideCaracteresEspeciais()
@description Verifica se existem caracteres que n�o s�o letras ou n�meros
@created 20/10/2007
@param input: o campo a ser validado
@param msgErro: a mensagem de erro a ser exibida. Se estiver vazia, n�o mostra nada.
@return true, se a valida��o tiver sucesso, ou false, caso contr�rio
*/
function pfnValideCaracteresEspeciais(input, msgErro)
{
	if (input != null)
	{
		var ipText = input.value;
		for (var x = 0 ; x < ipText.length ; x++)
		{
			var tecla = new String(ipText.charCodeAt(x));
			if ((tecla < 48) ||(tecla > 57 && tecla < 65) || (tecla > 90 && tecla < 97) || (tecla > 122)) 
			{
				if (msgErro != "")
				{
					alert(msgErro);
					input.select();
					input.focus();
					return false;
				}
			}
		}
	}
	return true;
}

//*************************************************************************************************************
/**
@name pfnValideEmail
@description Verifica se o e-mail digitado no campo especificado � v�lido e exibe,
 opcionalmente, a mensagem de erro especificada
@created 03/11/25004
@param input: o campo que cont�m o e-mail a ser validado
@param msgErro: a mensagem de erro a ser exibida. Se estiver vazia, n�o exibe nada
@return true, se a valida��o tiver sucesso, ou false, caso contr�rio

*/
function pfnValideEmail(input, msgErro)
{
	// recupere o e-mail
	var email = pfnTrim(input.value);
	if (email != "")
	{
		// a express�o regular para um e-mail v�lido
		var re = /\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/gi;
		var matches = re.exec(email);

		// deve existir exatamente um e-mail
		if (matches == null || email != matches[0])
	   {

			if (msgErro != "")
			{
				alert(msgErro);
				input.select();
				input.focus();
				return false;
			}
			return false;
		}
	}
   return true;
}

//Para debulgar o Java Script.
function d(Mensagem)
{
	try 
	{
		alert(Mensagem);
		//document.frmPrincipal.textarea1.value =document.frmPrincipal.textarea1.value + '\n' + Mensagem;
		//<textarea id=textarea1 name=textarea1></textarea>
	}
	catch(e) 
	{						// Caso ocorra algum erro.
		alert(e);
		return(e + " ocorreu um erro ao execultar a fun��o.");		// Retorna a mensagem de erro.
	}
}

function fnVerificaSeOCEPENumerico(input)// e formata
{
 	    if (((event.keyCode<48)||(event.keyCode>57))&&((event.keyCode<95)||(event.keyCode>105))&&(event.keyCode!=8)&&(event.keyCode!=46))
  	    {
		    event.returnValue = false;
		}
        else
        {
			if((event.keyCode!=8)&&(event.keyCode!=46))
			{
				if(input.value.length==2)
				{
					input.value=input.value + "." ;
				}		
				if(input.value.length==6)
				{
					input.value=input.value + "-" ;
				}
			}
	    }


        //**************************

}
//valida o CPF ao sair do foco onblur='funcoesGlobaisValidarCPF("CPF inválido",this);'
function funcoesGlobaisValidarCPF(Mensagem,campo)
		if (!validarCPF(campo.value,'')){
           if (Mensagem==''){
			  Mensagem= 'Campo CPF inválido.'
			}			  
			alertM(Mensagem,campo);
			return false;
		}
		return true;		
}	
</script>

<script language='JavaScript'>
function validarCPF(cpf) {
 
    cpf = cpf.replace(/[^\d]+/g,'');
 
    if(cpf == '') return false;
 
    // Elimina CPFs invalidos conhecidos
    if (cpf.length != 11 || 
        cpf == "00000000000" || 
        cpf == "11111111111" || 
        cpf == "22222222222" || 
        cpf == "33333333333" || 
        cpf == "44444444444" || 
        cpf == "55555555555" || 
        cpf == "66666666666" || 
        cpf == "77777777777" || 
        cpf == "88888888888" || 
        cpf == "99999999999")
        return false;
     
    // Valida 1o digito
    add = 0;
    for (i=0; i < 9; i ++)
        add += parseInt(cpf.charAt(i)) * (10 - i);
    rev = 11 - (add % 11);
    if (rev == 10 || rev == 11)
        rev = 0;
    if (rev != parseInt(cpf.charAt(9)))
        return false;
     
    // Valida 2o digito
    add = 0;
    for (i = 0; i < 10; i ++)
        add += parseInt(cpf.charAt(i)) * (11 - i);
    rev = 11 - (add % 11);
    if (rev == 10 || rev == 11)
        rev = 0;
    if (rev != parseInt(cpf.charAt(10)))
        return false;
         
    return true;
    
}
</script>

<script language='JavaScript'>
//valida o cnpj ao sair do foco onblur='funcoesGlobaisValidarCNPJ("cnpj inválido",this);'
function funcoesGlobaisValidarCNPJ(Mensagem,campo)
		if (!validarCNPJ(campo.value,'')){
           if (Mensagem==''){
			  Mensagem= 'Campo CNPJ inválido.'
			}			  
			alertM(Mensagem,campo);
			return false;
		}
		return true;		
}	
//valida o cnpj ao sair do foco onblur='funcoesGlobaisValidarCNPJ("cnpj inválido",this);'
function funcoesGlobaisValidarInscricaoEstadual(Mensagem,campo)
		if (!validarInscricaoEstadual(campo.value,'')){
           if (Mensagem==''){
			  Mensagem= 'Incrição estadual inválida.'
			}			  
			alertM(Mensagem,campo);
			return false;
		}
		return true;		
}	

	
//onblur="checkInscEstadual(this,document.getElementById("estado").value);"
function validarInscricaoEstadual(theField,estado) {
		//checkInscEstadual(theField,estado)
	//São validações diferentes para cada estado.
	//esta bloqueando a validação
	return true;

    var inscEst=retiraCaracteresInvalidos(theField.value);
    if (inscEst!="") {
        var dig8 = "/BA*/RJ*";
        var dig9 = "/AL*/AP*/AM*/CE*/ES*/GO*/MA*/MS*/PA*/PB*/PI*/RN*/RR*/SC*/SE*/TO*";
        var dig10 ="/PR*/RS*";
        var dig11 ="/MT*";
        var dig12 ="/SP*";
        var dig13 ="/AC*/MG*/DF*";
        var dig14 ="/PE*/RO*";
       
        if (dig8.indexOf("/"+estado+"*") != -1) {
            inscEst=inscEst.substr(0,8);
            tam=8;
        }
        else if (dig9.indexOf("/"+estado+"*") != -1) {
            inscEst=inscEst.substr(0,9);
            tam=9;
        }
        else if (dig10.indexOf("/"+estado+"*") != -1) {
            inscEst=inscEst.substr(0,10);
            tam=10;
        }
        else if (dig11.indexOf("/"+estado+"*") != -1) {
            inscEst=inscEst.substr(0,11);
            tam=11;
        }
        else if (dig12.indexOf("/"+estado+"*") != -1) {
            inscEst=inscEst.substr(0,12);
            tam=12;
        }
        else if (dig13.indexOf("/"+estado+"*") != -1) {
            inscEst=inscEst.substr(0,13);
            tam=13;
        }
        else if (dig14.indexOf("/"+estado+"*") != -1) {
            inscEst=inscEst.substr(0,14);
            tam=14;
        }
        else {
            inscEst="";
            inscEstadual.disabled = true;
            tam=0;
        }
    }
    if (inscEst!="") {
        if (estado=="AC") {
            inscEst=strzero(inscEst,13);
            primDigito=0;
            seguDigito=0;
            pesos="43298765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=11-(soma%11);
            if (primDigito>9)
                primDigito=0;
            pesos="543298765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            seguDigito=11-(soma%11);
            if (seguDigito>9)
                seguDigito=0;
               
            if ((parseInt(inscEst.substr(11,1))!=primDigito) || (parseInt(inscEst.substr(12,1))!=seguDigito)) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="AL") {
            inscEst=strzero(inscEst,9);
            primDigito=0;
            pesos="98765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            soma=soma*10;
            primDigito=soma%11;
            if (primDigito>9)
                primDigito=0;
            if (parseInt(inscEst.substr(8,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="AP") {
            inscEst=strzero(inscEst,9);
            if (inscEst.substr(0,2) != "03") {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else {
                if (parseFloat(inscEst.substr(0,8))<3017000) {
                    p=5;
                    d=0;
                }
                else if (parseFloat(inscEst.substr(0,8))<3019022) {
                    p=9;
                    d=1;
                }
                else {
                    p=0;
                    d=0;   
                }
                primDigito=0;
                pesos="98765432";
                soma=p;
                for(i=0;i<pesos.length;i++) {
                    soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
                }
                primDigito=11-(soma%11);
                if (primDigito==10)
                    primDigito=0;
                else if (primDigito==11)
                    primDigito=d;
                if (parseInt(inscEst.substr(8,1))!=primDigito) {
                    alert("Insc. Estadual inválida");
                    theField.select();
                    theField.focus();
                }
                else
                    theField.value=inscEst;
            }
        }
        else if (estado=="AM") {
            inscEst=strzero(inscEst,9);
            primDigito=0;
            pesos="98765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            if (soma<11)
                primDigito=11-soma;
            else {
                primDigito=soma%11;
                if (primDigito<2)
                    primDigito=0;
                else
                    primDigito=11-primDigito;
            }
            if (parseInt(inscEst.substr(8,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="BA") {
            inscEst=strzero(inscEst,8);
            primDigito=0;
            seguDigito=0;
            if ((parseInt(inscEst.substr(0,1))<6) || (parseInt(inscEst.substr(0,1))==8))
                modulo=10;
            else
                modulo=11;
            pesos="765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            seguDigito=modulo-(soma%modulo);
            if (seguDigito>9)
                seguDigito=0;
            var inscEstAux=inscEst;
            inscEst=inscEst.substr(0,6) + "" + inscEst.substr(7,1) + "" + inscEst.substr(6,1);
            pesos="8765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=modulo-(soma%modulo);
            if (primDigito>9)
                primDigito=0;
            inscEst=inscEst.substr(0,6) + "" + inscEst.substr(7,1) + "" + inscEst.substr(6,1);
            if ((parseInt(inscEst.substr(6,1))!=primDigito) || (parseInt(inscEst.substr(7,1))!=seguDigito)) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="CE") {
            inscEst=strzero(inscEst,9);
            primDigito=0;
            pesos="98765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=11-(soma%11);
            if (primDigito>9)
                primDigito=0;
            if (parseInt(inscEst.substr(8,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="DF") {
            inscEst=strzero(inscEst,13);
            if (inscEst.substr(0,2) != "07") {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else {
                primDigito=0;
                seguDigito=0;
                pesos="43298765432";
                soma=0;
                for(i=0;i<pesos.length;i++) {
                    soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
                }
                primDigito=11-(soma%11);
                if (primDigito>9)
                    primDigito=0;
                pesos="543298765432";
                soma=0;
                for(i=0;i<pesos.length;i++) {
                    soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
                }
                seguDigito=11-(soma%11);
                if (seguDigito>9)
                    seguDigito=0;
                   
                if ((parseInt(inscEst.substr(11,1))!=primDigito) || (parseInt(inscEst.substr(12,1))!=seguDigito)) {
                    alert("Insc. Estadual inválida");
                    theField.select();
                    theField.focus();
                }
                else
                    theField.value=inscEst;
            }
        }
        else if (estado=="ES") {
            inscEst=strzero(inscEst,9);
            primDigito=0;
            pesos="98765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=11-(soma%11);
            if (primDigito>9)
                primDigito=0;
            if (parseInt(inscEst.substr(8,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="GO") {
            inscEst=strzero(inscEst,9);
            primDigito=0;
            pesos="98765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=11-(soma%11);
            if (inscEst.substr(0,8)=="11094402") {
                if ((parseInt(inscEst.substr(8,1))!="0") && (parseInt(inscEst.substr(8,1))!="1")) {
                    alert("Insc. Estadual inválida");
                    theField.select();
                    theField.focus();
                }
            }
            else {
                if (primDigito==11)
                    primDigito=0;
                else if (primDigito==10) {
                    if ((parseFloat(inscEst.substr(0,8))>=10103105) && (parseFloat(inscEst.substr(0,8))<=10119997))
                        primDigito=1;
                    else
                        primDigito=0;
                }
                if (parseInt(inscEst.substr(8,1))!=primDigito) {
                    alert("Insc. Estadual inválida");
                    theField.select();
                    theField.focus();
                }
                else
                    theField.value=inscEst;
            }
        }
        else if (estado=="MA") {
            inscEst=strzero(inscEst,9);
            if (inscEst.substr(0,2) != "12") {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else {
                primDigito=0;
                pesos="98765432";
                soma=0;
                for(i=0;i<pesos.length;i++) {
                    soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
                }
                primDigito=11-(soma%11);
                if (primDigito>9)
                    primDigito=0;
                if (parseInt(inscEst.substr(8,1))!=primDigito) {
                    alert("Insc. Estadual inválida");
                    theField.select();
                    theField.focus();
                }
                else
                    theField.value=inscEst;
            }
        }
        else if (estado=="MT") {
            inscEst=strzero(inscEst,11);
            primDigito=0;
            pesos="3298765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=11-(soma%11);
            if (primDigito>9)
                primDigito=0;
            if (parseInt(inscEst.substr(10,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="MS") {
            inscEst=strzero(inscEst,9);
            if (inscEst.substr(0,2) != "28") {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else {
                primDigito=0;
                pesos="98765432";
                soma=0;
                for(i=0;i<pesos.length;i++) {
                    soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
                }
                primDigito=11-(soma%11);
                if (primDigito>9)
                    primDigito=0;
                if (parseInt(inscEst.substr(8,1))!=primDigito) {
                    alert("Insc. Estadual inválida");
                    theField.select();
                    theField.focus();
                }
                else
                    theField.value=inscEst;
            }
        }
        else if (estado=="MG") {
            inscEst=strzero(inscEst,13);
            inscEst=inscEst.substr(0,3)+"0"+inscEst.substr(3);
            primDigito=0;
            seguDigito=0;
            pesos="121212121212";
            soma=0;
            resultado=0;
            for(i=0;i<pesos.length;i++) {
                resultado=parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1));
                resultado=resultado+"";
                for(j=0;j<resultado.length;j++) {
                    soma=soma+(parseInt(resultado.substr(j,1)));
                }
            }
            somaAux=soma+"";
            primDigito=parseInt((parseInt(somaAux.substr(0,1))+1)+"0")-soma;
            if (primDigito>9)
                primDigito=0;
            inscEst=inscEst.substr(0,3)+inscEst.substr(4);
            pesos="321098765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                mult=parseInt(pesos.substr(i,1));
                if ((i>1) && (i<4))
                    mult=parseInt(pesos.substr(i,1))+10;
                soma=soma+(parseInt(inscEst.substr(i,1))*mult);
            }
            seguDigito=11-(soma%11);
            if (seguDigito>9)
                seguDigito=0;
               
            if ((parseInt(inscEst.substr(11,1))!=primDigito) || (parseInt(inscEst.substr(12,1))!=seguDigito)) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
       
       

        else if (estado=="PA") {
            inscEst=strzero(inscEst,9);
            if (inscEst.substr(0,2) != "15") {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else {
                primDigito=0;
                pesos="98765432";
                soma=0;
                for(i=0;i<pesos.length;i++) {
                    soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
                }
                primDigito=11-(soma%11);
                if (primDigito>9)
                    primDigito=0;
                if (parseInt(inscEst.substr(8,1))!=primDigito) {
                    alert("Insc. Estadual inválida");
                    theField.select();
                    theField.focus();
                }
                else
                    theField.value=inscEst;
            }
        }
        else if (estado=="PB") {
            inscEst=strzero(inscEst,9);
            primDigito=0;
            pesos="98765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=11-(soma%11);
            if (primDigito>9)
                primDigito=0;
            if (parseInt(inscEst.substr(8,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="PR") {
            inscEst=strzero(inscEst,10);
            primDigito=0;
            seguDigito=0;
            pesos="32765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=11-(soma%11);
            if (primDigito>9)
                primDigito=0;
            pesos="432765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            seguDigito=11-(soma%11);
            if (seguDigito>9)
                seguDigito=0;
               
            if ((parseInt(inscEst.substr(8,1))!=primDigito) || (parseInt(inscEst.substr(9,1))!=seguDigito)) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="PE") {
            inscEst=strzero(inscEst,14);
            primDigito=0;
            pesos="5432198765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=11-(soma%11);
            if (primDigito>9)
                primDigito=primDigito-10;
            if (parseInt(inscEst.substr(13,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="PI") {
            inscEst=strzero(inscEst,9);
            primDigito=0;
            pesos="98765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=11-(soma%11);
            if (primDigito>9)
                primDigito=0;
            if (parseInt(inscEst.substr(8,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="RJ") {
            inscEst=strzero(inscEst,8);
            primDigito=0;
            pesos="2765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=11-(soma%11);
            if (primDigito>9)
                primDigito=0;
            if (parseInt(inscEst.substr(7,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="RN") {
            inscEst=strzero(inscEst,9);
            primDigito=0;
            pesos="98765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            soma=soma*10;
            primDigito=soma%11;
            if (primDigito>9)
                primDigito=0;
            if (parseInt(inscEst.substr(8,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="RS") {
            inscEst=strzero(inscEst,10);
            primDigito=0;
            pesos="298765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=11-(soma%11);
            if (primDigito>9)
                primDigito=0;
            if (parseInt(inscEst.substr(9,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="RO") {
            inscEst=strzero(inscEst,14);
            primDigito=0;
            pesos="6543298765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            primDigito=11-(soma%11);
            if (primDigito>9)
                primDigito-=10;
            if (parseInt(inscEst.substr(13,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="RR") {
            inscEst=strzero(inscEst,9);
            primDigito=0;
            pesos="12345678";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            soma=soma*10;
            primDigito=soma%9;
            if (parseInt(inscEst.substr(8,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="SC") {
            inscEst=strzero(inscEst,9);
            primDigito=0;
            pesos="98765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            soma=soma*10;
            primDigito=soma%11;
            if (primDigito>9)
                primDigito=0;
            if (parseInt(inscEst.substr(8,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="SP") {
            inscEst=strzero(inscEst,12);
            primDigito=0;
            seguDigito=0;
            pesos="13456780";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                mult=parseInt(pesos.substr(i,1));
                if (i==7)
                    mult=10;
                soma=soma+(parseInt(inscEst.substr(i,1))*mult);
            }
            primDigito=soma%11;
            if (primDigito>9)
                primDigito=0;
            pesos="32098765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                mult=parseInt(pesos.substr(i,1));
                if (i==2)
                    mult=10;
                soma=soma+(parseInt(inscEst.substr(i,1))*mult);
            }
            seguDigito=soma%11;
            if (seguDigito>9)
                seguDigito=0;
               
            if ((parseInt(inscEst.substr(8,1))!=primDigito) || (parseInt(inscEst.substr(11,1))!=seguDigito)) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="SE") {
            inscEst=strzero(inscEst,9);
            primDigito=0;
            pesos="98765432";
            soma=0;
            for(i=0;i<pesos.length;i++) {
                soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
            }
            soma=soma*10;
            primDigito=11-(soma%11);
            if (primDigito>9)
                primDigito=0;
            if (parseInt(inscEst.substr(8,1))!=primDigito) {
                alert("Insc. Estadual inválida");
                theField.select();
                theField.focus();
            }
            else
                theField.value=inscEst;
        }
        else if (estado=="TO") {
            inscEst=strzero(inscEst,9); // 11 Se tiver 2 algarismos
            //if ((inscEst.substr(2,2) != "01") && (inscEst.substr(2,2) != "02") && (inscEst.substr(2,2) != "03") && (inscEst.substr(2,2) != "99")) {
            //    alert("Insc. Estadual inválida");
            //    theField.select();
            //    theField.focus();
            //}
            //else {
                primDigito=0;
                //pesos="9800765432";
                pesos="98765432";
                soma=0;
                for(i=0;i<pesos.length;i++) {
                    soma=soma+(parseInt(inscEst.substr(i,1))*parseInt(pesos.substr(i,1)));
                }
                primDigito=11-(soma%11);
                if (primDigito>9)
                    primDigito=0;
                if (parseInt(inscEst.substr(8,1))!=primDigito) {
                    alert("Insc. Estadual inválida");
                    theField.select();
                    theField.focus();
                }
                else
                    theField.value=inscEst;
            //}
        }
    }
}

function validarCNPJ(cnpj) {
 
    cnpj = cnpj.replace(/[^\d]+/g,'');
 
    if(cnpj == '') return false;
     
    if (cnpj.length != 14)
        return false;
 
    // Elimina CNPJs invalidos conhecidos
    if (cnpj == "00000000000000" || 
        cnpj == "11111111111111" || 
        cnpj == "22222222222222" || 
        cnpj == "33333333333333" || 
        cnpj == "44444444444444" || 
        cnpj == "55555555555555" || 
        cnpj == "66666666666666" || 
        cnpj == "77777777777777" || 
        cnpj == "88888888888888" || 
        cnpj == "99999999999999")
        return false;
         
    // Valida DVs
    tamanho = cnpj.length - 2
    numeros = cnpj.substring(0,tamanho);
    digitos = cnpj.substring(tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
      soma += numeros.charAt(tamanho - i) * pos--;
      if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(0))
        return false;
         
    tamanho = tamanho + 1;
    numeros = cnpj.substring(0,tamanho);
    soma = 0;
    pos = tamanho - 7;
    for (i = tamanho; i >= 1; i--) {
      soma += numeros.charAt(tamanho - i) * pos--;
      if (pos < 2)
            pos = 9;
    }
    resultado = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (resultado != digitos.charAt(1))
          return false;
           
    return true;
    
}
//--->Fun��o para a formata��o dos camposCPF, CNPJ, TELEFONE, DATA e CEP
//Como chamar <input name="cep" type="text" id="cep" maxlength="9" size="8" onKeyPress="return digitos(event, this);" onKeyUp="MascaraGeral('CEP',this,event);">
</script>
<script>

function MascaraGeral(tipo, campo,teclaPress) {
		 funcoesGlobaisMascaraGeral(tipo, campo,teclaPress);
}
function funcoesGlobaisFormataOnBlur(tipo, campo) {
	var s = new String(campo.value);
	// Remove todos os caracteres � seguir: ( ) / - . e espaço, para tratar a string denovo.
	s = s.replace(/(\.|\(|\)|\/|\-| )+/g,'');
 
	tam = s.length + 1;
 
		switch (tipo)
		{
		case 'INTEGER' :
			if (tam > 1 ){
				campo.value =s;
			}
		break;			
		case 'CPF' :
			if (tam > 3 && tam < 7)
				campo.value = s.substr(0,3) + '.' + s.substr(3, tam);
			if (tam >= 7 && tam < 10)
				campo.value = s.substr(0,3) + '.' + s.substr(3,3) + '.' + s.substr(6,tam-6);
			if (tam >= 10 && tam < 12)
				campo.value = s.substr(0,3) + '.' + s.substr(3,3) + '.' + s.substr(6,3) + '-' + s.substr(9,tam-9);
		break;
 		case 'DECIMAL' :
			pfnFormateMoedaOnBlur(campo);
		break;
		case 'CNPJ' :
 
			if (tam > 2 && tam < 6)
				campo.value = s.substr(0,2) + '.' + s.substr(2, tam);
			if (tam >= 6 && tam < 9)
				campo.value = s.substr(0,2) + '.' + s.substr(2,3) + '.' + s.substr(5,tam-5);
			if (tam >= 9 && tam < 13)
				campo.value = s.substr(0,2) + '.' + s.substr(2,3) + '.' + s.substr(5,3) + '/' + s.substr(8,tam-8);
			if (tam >= 13 && tam < 15)
				campo.value = s.substr(0,2) + '.' + s.substr(2,3) + '.' + s.substr(5,3) + '/' + s.substr(8,4)+ '-' + s.substr(12,tam-12);
		break;
 
		case 'PhoneNumber' :
			if (tam > 2 && tam < 4)
				campo.value = '(' + s.substr(0,2) + ') ' + s.substr(2,tam);
			if (tam >= 7 && tam < 11)
				campo.value = '(' + s.substr(0,2) + ') ' + s.substr(2,5) + '-' + s.substr(7,tam-7);
		break;
 
		case 'DATA' :
			funcoesGlobaisValidaData('',campo);
		break;
		
		case 'CEP' :
			if (tam > 5 && tam == 7)
				campo.value = s.substr(0,5) + '-' + s.substr(5, tam);
		break;
		}

}
</script>



<script>
//onKeyPress="return digitos(event, this);" 
//onKeyUp="funcoesGlobaisMascaraGeral(\'DECIMAL\',this,event);"
function funcoesGlobaisMascaraGeral(tipo, campo,teclaPress) {

	if (window.event)
	{
		var tecla = teclaPress.keyCode;
	} else {
		tecla = teclaPress.which;
	}

	var s = new String(campo.value);
	// Remove todos os caracteres � seguir: ( ) / - . e espa�o, para tratar a string denovo.
	s = s.replace(/(\.|\(|\)|\/|\-| )+/g,'');
 
	tam = s.length + 1;
 
	if ( tecla != 9 && tecla != 8 ) {
		switch (tipo)
		{
		case 'CPF' :
			if (tam > 3 && tam < 7)
				campo.value = s.substr(0,3) + '.' + s.substr(3, tam);
			if (tam >= 7 && tam < 10)
				campo.value = s.substr(0,3) + '.' + s.substr(3,3) + '.' + s.substr(6,tam-6);
			if (tam >= 10 && tam < 12)
				campo.value = s.substr(0,3) + '.' + s.substr(3,3) + '.' + s.substr(6,3) + '-' + s.substr(9,tam-9);
		break;
 		case 'DECIMAL' :
			pfnFormataMoeda(campo, teclaPress);
		break;
		case 'CNPJ' :
 
			if (tam > 2 && tam < 6)
				campo.value = s.substr(0,2) + '.' + s.substr(2, tam);
			if (tam >= 6 && tam < 9)
				campo.value = s.substr(0,2) + '.' + s.substr(2,3) + '.' + s.substr(5,tam-5);
			if (tam >= 9 && tam < 13)
				campo.value = s.substr(0,2) + '.' + s.substr(2,3) + '.' + s.substr(5,3) + '/' + s.substr(8,tam-8);
			if (tam >= 13 && tam < 15)
				campo.value = s.substr(0,2) + '.' + s.substr(2,3) + '.' + s.substr(5,3) + '/' + s.substr(8,4)+ '-' + s.substr(12,tam-12);
		break;
		case 'InscricaoEstadual' :
			//9999999999-9
			if (tam > 10 && tam <12)
				campo.value = s.substr(0,10) + '-' + s.substr(10, tam);
		break;
		case 'PhoneNumber' :
			if (tam > 2 && tam < 4)
				campo.value = '(' + s.substr(0,2) + ') ' + s.substr(2,tam);
			if (tam >= 7 && tam < 11)
				campo.value = '(' + s.substr(0,2) + ') ' + s.substr(2,5) + '-' + s.substr(7,tam-7);
		break;
 
		case 'DATASEMTYPEIGUALADATE' :
			if (tam > 2 && tam < 4)
				campo.value = s.substr(0,2) + '/' + s.substr(2, tam);
			if (tam > 4 && tam < 11)
				campo.value = s.substr(0,2) + '/' + s.substr(2,2) + '/' + s.substr(4,tam-4);
		break;
		
		case 'CEP' :
		//70010-629
			if (tam > 5 && tam < 7)
				campo.value = s.substr(0,5) + '-' + s.substr(5, tam);
		break;
		}
	}
}
</script>































<script type="text/javascript">
//--->Fun��o para verificar se o valor digitado � n�mero...<---
function digitos(event){
	if (window.event) {
		// IE
		key = event.keyCode;
	} else if ( event.which ) {
		// netscape
		key = event.which;
	}
	if ( key != 8 || key != 13 || key < 48 || key > 57 )
		return ( ( ( key > 47 ) && ( key < 58 ) ) || ( key == 8 ) || ( key == 13 ) );
	return true;
}
</script>
<script>
//para criar uma mensagem de valida��o na p�gina mais bonita, e que ande na tela. incluir o <link href="css/estilo.css" rel="stylesheet" type="text/css">
	//alertM('Campo carga hor�ria (obrigat�rio)','cargaHoraria');
			//	<div id="feedback" style="display:none"> 
		//	 </br></br>Clique em salvar. </br></br> <input type=button value='FECHAR (X)' onClick='javascript:fechar();'>
		//	</div>
function redirecionadorProvisorio(campo){
document.location = 'usuarioConsultar.php';
document.getElementById("feedback").style.display = 'none'; 
document.getElementById("geralDesabilitando").style.display = 'none';
alertN('<br><b>Processando...</b>', '');  
					
}	
    function fechar(campo){ 
			var browser=navigator.appName;
		if (browser=='Microsoft Internet Explorer')
		{
			//se for internet explorer n�o aceita transparente, impedindo de digitar.
		//	document.getElementById('geralDesabilitando').style.background ='#C0C0C0';
		}		
        document.getElementById("feedback").style.display = 'none'; 
        document.getElementById("geralDesabilitando").style.display = 'none'; 		
		if (campo!=''){
			document.getElementById(campo).focus();
		}
		document.getElementById("feedback").style.backgroundColor ='blue';

    }
    function alertM(mensagem,campo) { 
		document.getElementById("feedback").style.backgroundColor ='red';
		document.getElementById("feedback").innerHTML ="</br></br>"+mensagem+"</br></br> <input type=button id=btPopupFechar value='FECHAR' onClick='javascript:fechar(\""+campo+"\");'>";
        document.getElementById("feedback").style.display = ''; 
        document.getElementById("geralDesabilitando").style.display = ''; 		
		document.getElementById("btPopupFechar").focus();
    }
	
    function alertMnis(mensagem,campo) { 
		document.getElementById("feedback").style.backgroundColor ='red';
		document.getElementById("feedback").innerHTML ="</br>"+mensagem+"</br></br><input type=button id=btPopupFechar value='VOLTAR' onClick='redirecionadorProvisorio(\""+campo+"\");'>";
        document.getElementById("feedback").style.display = ''; 
        document.getElementById("geralDesabilitando").style.display = ''; 		
		document.getElementById("btPopupFechar").focus();
    }	
	
	function alertMblue(mensagem,campo) { 
		document.getElementById("feedback").style.backgroundColor ='blue';
		document.getElementById("feedback").innerHTML ="</br></br>"+mensagem+"</br></br> <input type=button id=btPopupFechar value='FECHAR' onClick='javascript:fechar(\""+campo+"\");'>";
        document.getElementById("feedback").style.display = ''; 
        document.getElementById("geralDesabilitando").style.display = ''; 		
		document.getElementById("btPopupFechar").focus();
    }

    function alertN(mensagem,campo) { 
		document.getElementById("feedback").style.backgroundColor ='blue';
		document.getElementById("feedback").innerHTML ="</br></br>"+mensagem+"</br></br>";
        document.getElementById("feedback").style.display = ''; 
        document.getElementById("geralDesabilitando").style.display = ''; 
    }		
	//exemplo : <input name="cep" type="text" id="cep" onkeypress="return MM_formtCep(event,this,'#####-###');" size="10" maxlength="9">
function MM_formtCep(e,src,mask) {
        if(window.event) { 
			_TXT = e.keyCode; 
		} 
        else if(e.which) { 
			_TXT = e.which; 
		}
        if(_TXT > 47 && _TXT < 58) { 
			var i = src.value.length; var saida = mask.substring(0,1); var texto = mask.substring(i)
			if (texto.substring(0,1) != saida) { 
				src.value += texto.substring(0,1); 
			} 
			return true; 
		} else { 
			if (_TXT != 8) { return false; 
			} else { 
				return true; 
			}
		}
}
</script>































<script type="text/javascript">
/**
@name ValidacaoNumero
@description Valida números e valores em moeda
@methods 
@created 02/12/2003
*/


//*************************************************************************************************************
/**
@name Normalize
@description Retira os zeros da esquerda de uma string e a preenche com zeros � direita de forma
 que ela ter� pelo menos tr�s caracteres
@created 02/12/2003
@param valor: o valor a ser normalizado
@return a string normalizada

*/
function Normalize(valor)
{
	var number;
	var vlNormalizado;

	// verifique se o valor � zero - eu testo se o valor � vazio porque se eu converter vazio para um n�mero
	// o resultado � zero
	if (new Number(valor).valueOf() == 0 && valor != "")
	{
		return "000";
	}
	else
	{
		// tire os zeros da esquerda do n�mero
		while(valor.substr(0,1) == "0")
			valor = valor.substr(1, valor.length - 1)

		// se o n�mero s� tiver 1 d�gito, preencha-o com 2 zeros � esquerda
		if (valor.length == 1)
			vlNormalizado = "00" + valor;
		// se o n�mero tiver 2 d�gitos, preencha-o com 1 d�gito � esquerda
		else if (valor.length == 2)
			vlNormalizado = "0" + valor;
		// se o n�mero tiver mais do que 2 d�gitos, ele j� est� normalizado
		else
			vlNormalizado = valor;

		return vlNormalizado;
	}

}

//*************************************************************************************************************
/**
@name pfnFormataMoeda
@description Formata um n�mero como moeda � medida que ele � digitado
 N�o impede o usu�rio de teclar d�gitos, apenas n�o realiza a formata��o caso a tecla digitada n�o seja um d�gito
@created 02/12/2003
@param field: o campo onde o n�mero est� sendo digitado
@return N�o retorna nada
*/

function pfnFormataMoeda(field, evento)
{
	var tecla = evento.keyCode;
	if(tecla == 0) tecla = evento.charCode;
	
	// s� prossiga se a tecla pressionada foi um d�gito ou a tecla BACKSPACE e caso haja algum valor inserido no campo
	if (((tecla >= 48 && tecla <= 57) || (tecla >= 96 && tecla <= 105) || tecla == 8 || tecla == 46) && field.value.length != 0)
	{
		pfnFormateMoedaOnBlur(field);
	}
}
/**
@name fnFormataMoeda
@description Formata um n�mero como moeda � medida que ele � digitado
 N�o impede o usu�rio de teclar d�gitos, apenas n�o realiza a formata��o caso a tecla digitada n�o seja um d�gito
@created 02/12/2003
@param field: o campo onde o n�mero est� sendo digitado
@return N�o retorna nada

*/
function fnFormataMoeda(field)
{
    // s� prossiga se a tecla pressionada foi um d�gito ou a tecla BACKSPACE e caso haja algum valor inserido no campo
    if (((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 8 || event.keyCode == 46) && field.value.length != 0)
    {
        pfnFormateMoedaOnBlur(field);
    }
}
//Impossibilita a inser��o de caracteres especiais.
function pfnToSubstituir(campo)
{

    numeroBr = campo.value;
    numeroBr = numeroBr.replace('!', '');
    numeroBr = numeroBr.replace('@', '');
    numeroBr = numeroBr.replace("#", "");
    numeroBr = numeroBr.replace("$", "");
    numeroBr = numeroBr.replace("%", "");
    numeroBr = numeroBr.replace("�", "");
    numeroBr = numeroBr.replace("&", "");
    numeroBr = numeroBr.replace("*", "");
    numeroBr = numeroBr.replace("(", "");
    numeroBr = numeroBr.replace(")", "");
    numeroBr = numeroBr.replace("~", "");
    numeroBr = numeroBr.replace("^", "");
    numeroBr = numeroBr.replace("]", "");
    numeroBr = numeroBr.replace("}", "");
    numeroBr = numeroBr.replace("[", "");
    numeroBr = numeroBr.replace("{", "");
    numeroBr = numeroBr.replace("�", "");
    numeroBr = numeroBr.replace("`", "");
    numeroBr = numeroBr.replace("a", "");
    numeroBr = numeroBr.replace("b", "");
    numeroBr = numeroBr.replace("c", "");
    numeroBr = numeroBr.replace("d", "");
    numeroBr = numeroBr.replace("e", "");
    numeroBr = numeroBr.replace("f", "");
    numeroBr = numeroBr.replace("g", "");
    numeroBr = numeroBr.replace("h", "");
    numeroBr = numeroBr.replace("i", "");
    numeroBr = numeroBr.replace("j", "");
    numeroBr = numeroBr.replace("k", "");
    numeroBr = numeroBr.replace("l", "");
    numeroBr = numeroBr.replace("m", "");
    numeroBr = numeroBr.replace("n", "");
    numeroBr = numeroBr.replace("o", "");
    numeroBr = numeroBr.replace("p", "");
    numeroBr = numeroBr.replace("q", "");	
    numeroBr = numeroBr.replace("r", "");
    numeroBr = numeroBr.replace("s", "");
    numeroBr = numeroBr.replace("t", "");
    numeroBr = numeroBr.replace("u", "");
    numeroBr = numeroBr.replace("v", "");
    numeroBr = numeroBr.replace("w", "");
    numeroBr = numeroBr.replace("x", "");
    numeroBr = numeroBr.replace("y", "");
    numeroBr = numeroBr.replace("z", "");		
    campo.value=numeroBr ;

}

//*************************************************************************************************************
/**
@name pfnSomenteNumerosOnBlur
@description Elimina caracteres n�o numericos de um campo.
 Deve ser usada no evento onBlur (apropriada para valores inseridos atrav�s de "cola")
@created 27/04/2011
@param input: o campo onde a data est� sendo digitada
@return N�o retorna nada
@author Aline Goulart
*/
function pfnSomenteNumerosOnBlur(campo)
{
	campo.value = campo.value.replace(/[^\d]+/g, '');
}


//*************************************************************************************************************
/**
@name pfnFormateMoedaOnBlur
@description Formata um campo como moeda (usado no evento onBlur)
@created 04/02/2004
@param field: o campo onde o n�mero que deve ser formatado est�
@return N�o retorna nada

*/

function pfnFormateMoedaOnBlur(field)
{
	field.value = field.value.replace(/[^\d]+/g, ''); 
	field.value = pfnFormateValorMoeda(field.value);
}

function fnIsNumeric()
{
    if (((event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105) || event.keyCode == 8 || event.keyCode == 46 || event.keyCode == 13) )
    {
        event.returnValue = true;
        return true;        

    }
    else
    {
        event.returnValue = false;
        return false;
    }
}
//*************************************************************************************************************
/**
@name pfnFormateValorMoeda
@description Formata um n�mero como moeda
@created 04/02/2004
@param valor: o valor a ser formatado
@return O valor formatado

*/
function pfnFormateValorMoeda(valor_)
{
	// a pr�xima convers�o � para compatibilidade com p�ginas em vbscript, para ter certeza que valor ser�
	// uma string UTF-8
	var valor;
	valor = new String(valor_);
	
	// o valor digitado sem formata��o
	var valorSemFormatacao; 
	// o valor final a ser mostrado ao usu�rio
	var valorFinal;
	// o n�mero de conjuntos de tr�s n�meros antes da parte decimal do n�mero
	var casas;
	// determine o n�mero de d�gitos que sobram por n�o completar grupos de 3 d�gitos 
	var casasIncompletas;
	// determina se o valor digitado � um n�mero negativo
	var numeroNegativo = false;
	
	//tire qualquer espa�o do come�o e fim de valor
	valor = valor.replace(/(\s)*$|^(\s)*/g, "");
	
	//Se for um n�mero s� ap�s a virgula.
	//if (valor.indexOf(',') == valor.length-2 && valor.length != 0)
	//	valor = valor + '0';
	
	// tire os pontos e troque as v�rgulas pelos pontos para transformar o n�mero brasileiro em um n�mero americano
	valorSemFormatacao = pfnToNumeroAmericano(valor);
	
	// verifique se o n�mero � v�lido
	if (isNaN(valorSemFormatacao))
		return valor;
	
	// verifique se o n�mero � negativo
	if (valorSemFormatacao.substr(0, 1) == "-")
		numeroNegativo = true;

	// agora retire todos os pontos e tra�o (do n�mero negativo) para format�-lo
	valorSemFormatacao = valorSemFormatacao.replace(/[.-]/g, "");
		
	// o primeiro d�gito que o usu�rio digita � especial - coloque os zeros � esquerda e saia
	if (valor.length == 1)
	{
		valor = "0,0" + valor;
		return valor;
	}
	
	// coloque ou tire os zeros necess�rios da esquerda
	valorSemFormatacao = Normalize(valorSemFormatacao);
	
	// aqui h� outro caso especial: se o resultado dessa fun��o � uma string vazia, ent�o s�
	// havia zeros na string digitada, ent�o retorne um 0 formatado e saia
	if (valorSemFormatacao.length == 0)
	{
		valor = ""
		return valor;
	}
	
	// determine quantos conjuntos de tr�s d�gitos h� no n�mero
	// n�o leve em conta os dois �ltimos n�meros dos centavos
	casas = Math.floor((valorSemFormatacao.length - 2)/3);
	casasIncompletas = (valorSemFormatacao.length - 2) % 3;

	// comece colocando os d�gitos � esqeuerda do valor original que n�o completam um grupo de tr�s d�gitos
	valorFinal = valorSemFormatacao.substr(0, casasIncompletas);

	for (i = 0; i < casas; i++)
	{	
		// pegue grupos de 3 d�gitos seguidos do valor original e adicione-os ao valor final acrescentando os pontos
		if (i != 0 || ( i == 0 && casasIncompletas > 0))
			valorFinal = valorFinal + ".";
		valorFinal = valorFinal + valorSemFormatacao.substr(casasIncompletas + i * 3, 3);
	}

	// termine colocando os d�gitos equivalentes aos centavos
	valorFinal = valorFinal + "," + valorSemFormatacao.substr(valorSemFormatacao.length - 2, 2);
	
	// se o n�mero for negativo, recoloque o sinal
	if (numeroNegativo)
		valorFinal = "-" + valorFinal;
		
	return valorFinal;
}
//onkeypress="fnSomenteNumero(this.id);"
function fnSomenteNumero(id1){
    var tecla=(window.event)?event.keyCode:e.which;   
    if((tecla>47 && tecla<58)) return true;
    else{
        if (tecla==8 || tecla==0) return true;
    else  return false;
    }
}

//*************************************************************************************************************
/**
@name pfnIsNumeric
@description Determina se a �ltima tecla digitada no teclado � um d�gito
@created 24/11/2003
@return true, se a tecla for um d�gito, false, caso contr�rio
*/
function pfnIsNumeric(campo, evento)
{
	var tecla = evento.keyCode;

    if(tecla == 0) tecla = evento.charCode;
	
	if((tecla < 48 || tecla > 57) && tecla != 8 && tecla != 9 && !evento.ctrlKey)
    {
        evento.returnValue = false;
        return false;
    }
    else
    {
        evento.returnValue = true;
        return true;
    }
}

//*************************************************************************************************************
/**
@name pfnValideFormateMoeda
@description Valida e formata um n�mero. A valida��o verifica se o n�mero cont�m apenas caracters num�ricos 
 (d�gitos, e opcionalmente pontos e uma v�rgula), se ele � maior ou igual a zero e se ele � menor do que o 
 tamanho m�ximo permitido
@created 10/03/2004
@param valor: o n�mero (ou string equivalente ao n�mero) a ser validado
@param mensagemErro: a mensagem a ser exibida se a valida��o falhar
@return O n�mero formatado, caso a valida��o tenha sucesso, ou o n�mero passado como par�metro, caso contr�rio

*/
function pfnValideFormateMoeda(valor, mensagemErro)
{
	if (pfnValideValorMaximo(valor, mensagemErro) && pfnValideNumeroNaoNegativo(valor, mensagemErro, true))
		return pfnFormateValorMoeda(valor);
	else
		return valor;
}


//*************************************************************************************************************
/**
@name pfnValideFormateMoedaOnBlur
@description Valida e formata um n�mero quando um campo perde o foco. A valida��o verifica se um n�mero cont�m
 apenas caracters num�ricos (d�gitos, e opcionalmente pontos e uma v�rgula), se ele � maior ou igual a zero e
 se ele � menor do que o tamanho m�ximo permitido
@created 10/03/2004
@param input: o campo onde o valor foi digitado
@param mensagemErro: a mensagem a ser exibida se a valida��o falhar
@return N�o retorna nada

*/
function pfnValideFormateMoedaOnBlur(input, mensagemErro)
{
	if (pfnValideValorMaximo(input.value, mensagemErro) && pfnValideNumeroNaoNegativo(input.value, mensagemErro, true))
		pfnFormateMoedaOnBlur(input);
	else
	{
		input.select();
		input.focus();
	}
}


//*************************************************************************************************************
/**
@name pfnValideNumeric
@description Valida se um campo cont�m somente caracteres num�ricos, exibe a mensagem de erro (se esta for n�o-vazia)
 e focaliza o campo
@created 28/04/2004
@param campo: o campo que cont�m o texto a ser validado
@param mensagem: a mensagem de erro a ser exibida - se for vazia, nada � exibido
@return true, se o campo s� tiver caracteres num�ricos, false, caso contr�rio

*/
function pfnValideNumeric(campo, mensagem)
{
    // assuma que a valida��o ter� sucesso
    var resultado = true;

    // verifique se o campo � non-null
    if (campo != null)
    {
        // recupere o texto digitado
        var texto = campo.value;
        // verifique se algo foi digitado
        if (pfnTrim(texto).length > 0)
        {
            // se h� caracteres n�o-num�ricos, h� um erro
            if (texto.search(/\D/g, "") != -1)
            {
                // verifique se uma mensagem deve ser exibida
                if (mensagem != "")
                    alert(mensagem);
                // selecione o campo
                campo.select();
                campo.focus();
                resultado = false;
            }
        }
    }
    // retorne o resultado
    return resultado;
}


//*************************************************************************************************************
/**
@name pfnToNumeroAmericano
@description Transforma um n�mero brasileiro em um n�mero americano sem separadores de casas decimais,
 para que possa ser tratado no javascript. Tira todos os pontos (os separadores de casas decimais no Brasil, 
 e troca as v�rgulas por pontos (os separadores de decimais).
@created 04/02/2004
@param numeroBr: o n�mero no formato brasileiro
@return o n�mero no formato americano

*/
function pfnToNumeroAmericano(numeroBr)
{
	return numeroBr.replace(/\./g, "").replace(/\,/g, ".");
}


//*************************************************************************************************************
/**
@name ValideNumeroMaximo
@description Verifica se um n�mero � maior que o m�ximo especificado. Se for, opcionalmente exibe mensagem de erro.
@created 28/07/2004
@param input: o input onde o n�mero est� sendo digitado
@param valorMaximo: o n�mero m�ximo
@param msgErroValorMaximo: a mensagem de erro a ser exibida se o valor m�ximo for excedido. Se for uma string 
 vazia e houver um errro, n�o exiba nada
@param msgErroValorInvalido: a mensagem de erro a ser exibida se o valor for inv�lido. Se for uma string 
 vazia e houver um errro, n�o exiba nada
@return true, se o valor do input for v�lido e menor ou igual ao valor m�ximo e false, caso contr�rio. 
 Se algum dos par�metros  for inv�lido, o retorno ser� undefined, para facilitar o debugging.

*/
function ValideNumeroMaximo(input, valorMaximo, msgErroValorMaximo, msgErroValorInvalido)
{	
  if (input != null)
  {
    var valor = input.value;
    if (pfnTrim(valor) != "")
    {
    	// primeiro verifique se o input � v�lido e se h� d�gitos no campo
    	if (!isNaN(valor) && !isNaN(valorMaximo))
    	{
    		var numero = pfnToNumeroAmericano(pfnTrim(valor));
    		// verifique se o n�mero � v�lido
    		var numObject = new Number(numero);
    		if (!isNaN(numObject))
    		{
    			// se o n�mero for maior que o permitido e houver uma mensagem de erro, exiba a mensagem
    			if (numObject > valorMaximo && msgErroValorMaximo != "")
    			{
    				alert(msgErroValorMaximo);
    				input.select();
    				input.focus();
    			}
    			// retorne o resultado
    			return numObject > valorMaximo;
    		}
    	}
    	else if (msgErroValorInvalido != "")
    	{
    		alert(msgErroValorInvalido);
    		input.select();
    		input.focus();
    		return false;
    	}
    }
  }
}

//*************************************************************************************************************
/**
@name pfnValideNumeroNaoNegativo
@description Verifica se um n�mero � n�o-negativo. Exibe a mensagem de erro caso valor contenha qualquer 
 caractere n�o-num�rico ou se for um n�mero negativo. N�o exibe uma mensagem de erro se o par�metro permiteVazio 
 for verdadeiro e o n�mero for equivalente a uma string vazia
@created 08/03/2004
@param valor: o n�mero (ou string correspondente ao n�mero) a ser validado
@param mensagemErro: a mensagem a ser exibida caso a verifica��o falhe. S� exibe a mensagem se mensagemErro n�o 
 for uma string vazia
@param permiteVazio: se for verdadeiro e o n�mero for equivalente a uma string vazia, n�o exibe a mensagem de erro.
@return true, se a valida��o tiver sucesso, ou seja, valor for um n�mero v�lido e n�o-negativo; false, caso contr�rio.

*/
function pfnValideNumeroNaoNegativo(valor, mensagemErro, permiteVazio)
{
	// converta o valor para uma string
	var str = new String(valor);
	if (str == "")
	{
		if (!permiteVazio)
		{	
			if (mensagemErro != "")
				alert(mensagemErro);
			return false;
		}
		else
			return true;
	}
	else
	{
		var numero = new Number(pfnToNumeroAmericano(str)).valueOf();
		if (isNaN(numero) || numero < 0)
		{
			if (mensagemErro != "")
				alert(mensagemErro);
			return false;
		}
	}
	// nesse ponto a valida��o teve sucesso
	return true;
}
			
	
/*************************************************************************************************************
/**
@name pfnValideNumeroNaoNegativoOnBlur
@description Verifica se um input cont�m um n�mero n�o-negativo. Exibe a mensagem de erro caso a string do
 input tenha qualquer caractere n�o-num�rico ou se for um n�mero negativo. N�o exibe uma mensagem de erro
 se o par�metro permiteVazio for verdadeiro e o input estiver vazio
@created 08/03/2004
@param input: O input html que cont�m a string a ser validada
@param mensagemErro: a mensagem a ser exibida caso a verifica��o falhe. S� exibe a mensagem se mensagemErro n�o
 for uma string vazia
@param permiteVazio: se for verdadeiro e o input estiver vazio, n�o exibe a mensagem de erro
@return N�o retorna nada

*/
function pfnValideNumeroNaoNegativoOnBlur(input, mensagemErro, permiteVazio)
{
	if (!pfnValideNumeroNaoNegativo(input.value, mensagemErro, permiteVazio))
	{
		input.focus();
	}
}


//*************************************************************************************************************
/**
@name pfnValideValorMaximo
@description Verifica se um n�mero � v�lido, ou seja, s� cont�m caracteres num�ricos (e uma v�rgula e pontos, 
 opcionais) e n�o � maior que o valor m�ximo permitido no site da cobran�a
@created 10/03/2004
@param valor: o n�mero a ser validado
@param mensagemErro: a mensagem a ser exibida caso a verifica��o falhe. A mensagem s� � exibida se for diferente
 de uma string vazia
@return true, se a valida��o tiver sucesso; false, caso contr�rio

*/
function pfnValideValorMaximo(valor, mensagemErro)
{
	// converta o n�mero para o formato americano
	var numero = new Number(pfnToNumeroAmericano(valor)).valueOf();
	
	// verifique se o n�mero � v�lido ou maior do que o m�ximo permitido
	if (isNaN(numero) || numero > 99999999.99)
	{
		if (mensagemErro != "")
			alert(mensagemErro);
		return false;
	}
	return true;
}


//*************************************************************************************************************
/**
@name pfnValideValorMaximoOnBlur
@description Verifica se um n�mero � v�lido, ou seja, s� cont�m caracteres num�ricos (e �ma v�rgula e pontos, 
 opcionais) e n�o � maior que o valor m�ximo permitido no site da cobran�a
@created 10/03/2004
@param input: o campo onde o n�mero foi digitado
@param mensagemErro: a mensagem a ser exibida caso a verifica��o falhe. A mensagem s� � exibida se for diferente
 de uma string vazia
@return true, se a valida��o tiver sucesso; false, caso contr�rio

*/
function pfnValideValorMaximoOnBlur(input, mensagemErro)
{
	if (!pfnValideValorMaximo(input.value, mensagemErro))
		input.focus();
}

</script>































<script type="text/javascript">
/**
@name ValidaocaoData
@description Valida datas nos formatos dd/mm/aaaa e mm/aaaa.
@created 30/10/2003
 e Marcos Condes Lopes
*/


//*************************************************************************************************************
/**
@name AnoBissexto
@description Calcula se um determinado ano é bissexto
@created 10/08/2004
@param ano: o ano
@return true, se o ano for bissexto, false, caso contrário

*/
function AnoBissexto(ano)
{
	// se o ano for divisível por 4, ele é bissexto se não for divisível por 100 ou,
	// caso seja, se também for divisível por 400
	if (ano % 4 == 0)
		return (ano % 100 != 0 || (ano % 100 == 0 && ano % 400 == 0));
	// se não for divisível por 4, não é bissexto
	else
		return false;
}


//*************************************************************************************************************
/**
@name CalculeNumeroAnosBissexto
@description Calcula o número de anos bissextos compreendidos entre o ano 0 (inclusive) e o ano especificado (inclusive)
@created 10/08/2004
@param ano: o ano
@return o número de anos bissextos

*/
function CalculeNumeroAnosBissexto(ano)
{
	var ano_ = new Number(ano);
	// recupere o número de anos divisíveis por 4
	var quatro = Math.floor(ano_/4);
	// recupere o número de anos divisíveis por 100
	var cem = Math.floor(ano_/100);
	// recupere o número de anos divisíveis por 400
	var quatrocentos = Math.floor(ano_/400);
	
	// o número final é o quatro - (cem - quatrocentos)
	// adicione 1 porque o ano 0000 é bissexto
	return quatro - (cem - quatrocentos) + 1;
}


//*************************************************************************************************************
/**
@name CalculeNumeroDiasNoMes
@description Calcula o número de dias em um mês de um certo ano
@created 10/08/2004
@param mes: o mes a ser calculado
@param ano: o ano a qual o mes pertence
@return O número de dias do mês de um ano

*/
function CalculeNumeroDiasNoMes(mes, ano)
{
	var ano_ = new Number(ano).valueOf();
	var mes_ = new Number(mes).valueOf();
	switch (mes_)
	{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			return 31;
		case 4:
		case 6:
		case 9:
		case 11:
			return 30;
		case 2:
			return (AnoBissexto(ano_) ? 29 : 28);
	}
}

//*************************************************************************************************************
/**
@name CompareDatasUmAno
@description Compara data1 e data2 para verificar se data1 é 1 ano anterior a data2. Se for,
 confirma com o usuário se isso é desejado. Caso não seja, focaliza o campo.
@param data1: a primeira data
@param data2: a segunda data
@param mensagem: a mensagem a ser exibida para o usuário na hora da confirmação
@param inputToFocus: o input que receberá o foco se a confirmação do usuário for negativa
@param inputToClear: o input que armazena se o usuário já confirmou essa data previamente
@created 08/06/2004
@return true, se data1 for 1 ano anterior a data2, false, caso contrário

*/
function CompareDatasUmAno(data1, data2, mensagem, inputToFocus, inputToClear)
{
	// assuma que data1 não é 1 ano menor que data2
	var resultado = false;

	// se qualquer das datas estiver em branco, saia
	if (pfnTrim(data1) == "" || pfnTrim(data2) == "")
		return true;

	// recupere e quebre as datas
	var partesDt1 = data1.split("/");
	var partesDt2 = data2.split("/");
	var dia1 = new Number(partesDt1[0]).valueOf();
	var mes1 = new Number(partesDt1[1]).valueOf();
	var ano1 = new Number(partesDt1[2]).valueOf();

	var dia2 = new Number(partesDt2[0]).valueOf();
	var mes2 = new Number(partesDt2[1]).valueOf();
	var ano2 = new Number(partesDt2[2]).valueOf();

	// primeiro valide se o ano da primeira data é anterior a um ano da segunda
	if (ano1 < ano2)
	{
		// se o ano da primeira for 2 menor do que o ano da segunda, com certeza data1 é anterior
		// a um ano da data2
		if (ano1 <= ano2 - 2)
			resultado = true;
		// caso contrário é preciso examinar o mês e o dia
		else
		{
			// aqui ano1 é um a menos do que ano2
			// se mes1 for menor do que mes2, data1 é 1 ano anterior a data2
			if (mes1 < mes2)
				resultado = true;
			// se o mês for igual, é preciso examinar o dia
			else if (mes1 == mes2)
			{
				// aqui os meses são iguais - se dia1 for menor que dia2,
				// data1 é um ano anterior a data2
				resultado = (dia1 <= dia2);
			}
		}
	}
	// se data1 é anterior a um ano da data2, confirme com o usuário se isso é desejado
	if (resultado)
	{
		// só confirme com o usuário se este já não confirmou para esta data
		if (inputToClear != null && inputToClear.value == "")
		{
			var yesNo = confirm(mensagem);

			// se o usuário não confirmar, selecione a data
			if (!yesNo)
			{
				inputToFocus.select();
				inputToFocus.focus();
			}
			else
				// armazene o fato de que o usuário já confirmou essa data
				inputToClear.value = "y";
		}
	}
	// retorne o resultado
	return resultado;
}


//*************************************************************************************************************
/**
@name pfnCalculeNumeroDias
@description Calcula o número de dias que se passaram desde 0/0/0 até a data especificada, incluindo o dia da data
@created 10/08/2004
@param data: a data da qual se deseja o número de dias
@return O número de dias que se passaram desde 0/0/0 até a data especificada, incluindo o dia da data

*/
function pfnCalculeNumeroDias(data)
{
	var data_ = new String(data);
	var partes = data.split("/");
	var result;
	
	var dia = new Number(partes[0]).valueOf();
	var mes = new Number(partes[1]).valueOf();
	var ano = new Number(partes[2]).valueOf();
	
	// adicione o número de dias no mês atual
	result = dia;
	
	// adicione o número de dias dos meses anteriores
	var i = mes - 1;
	while (i > 0)
	{
		result += CalculeNumeroDiasNoMes(i, ano)
		i--;
	}
	
	// adicione o número de dias dos anos anteriores
	if (ano > 0)
		result += 365 * (ano) + CalculeNumeroAnosBissexto(ano - 1);
	
	// retorne o resultado
	return result;
}


//*************************************************************************************************************
/**
@name pfnCalculeNumeroMeses
@description Calcula o número de meses que se passaram desde 0/0/0 até a data especificada
@created 04/11/2004
@param data: a data da qual se deseja o número de meses
@return Conforme descrito acima.

*/
function pfnCalculeNumeroMeses(data)
{
	var data_ = new String(data);
	var partes = data.split("/");
	var mes = new Number(partes[0]).valueOf();
	var ano = new Number(partes[1]).valueOf();

	// o número de meses é o número de meses desse ano mais 12 * o número de anos anteriores
	// a esse
	return mes + 12 * (ano - 1);
}


//*************************************************************************************************************
/**
@name pfnCompareDatas
@description Compara duas datas no formato dd/mm/aaaa e devolve a diferença em dias
@created 03/11/2003
@param inicio: a primeira data a ser comparada
@param fim: a segunda data a ser comparada
@return a diferença das duas datas, em dias (fim - inicio, se o operador "-" funcionasse com data). Se inicio < fim, 
 o resultado é positivo. Se inicio > fim, o resultado é negativo. Se fim = inicio, o resultado é 0.

*/
function pfnCompareDatas(inicio, fim)
{	
	// calcule a diferença das duas datas, em dias
	return (pfnCalculeNumeroDias(fim) - pfnCalculeNumeroDias(inicio));
}


//*************************************************************************************************************
/**
@name pfnCompareDatasMesAno
@description Compara duas datas no formato mm/aaaa
@created 04/02/2004
@param inicio: data inicial mm/aaaa
@param fim: data final mm/aaaa
@return quantidade de diferença em meses.
*/
function pfnCompareDatasMesAno(inicio, fim)
{	
	return pfnCalculeNumeroMeses(fim) - pfnCalculeNumeroMeses(inicio);
}


//*************************************************************************************************************
/**
@name pfnDataHoje10Caracteres
@description Retorna a data de hoje no formato dd/mm/aaaa
@created 09/02/2004
@return A data de hoje, com 10 caracteres, no formato dd/mm/aaaa

*/
function pfnDataHoje10Caracteres()
{

	var dataHoje = new Date();
	var dia, mes;
	dia = new String(dataHoje.getDate());
	mes = new String(dataHoje.getMonth() + 1);
	if (dia.length == 1)
		dia = "0" + dia;
	if (mes.length == 1)
		mes = "0" + mes;
	dataHoje = dia + "/" + mes + "/" + dataHoje.getFullYear();
	return dataHoje;
}


//*************************************************************************************************************
/**
@name pfnDataHoje7Caracteres
@description Retorna a data de hoje no formato mm/aaaa
@created 29/10/2004
@return A data de hoje, com 7 caracteres, no formato mm/aaaa

*/
function pfnDataHoje7Caracteres()
{
	var dataHoje = new Date();
	var mes;
	mes = new String(dataHoje.getMonth() + 1);
	if (mes.length == 1)
		mes = "0" + mes;
	dataHoje = mes + "/" + dataHoje.getFullYear();
	return dataHoje;
}

//*************************************************************************************************************
/**
@name pfnDiasNoMes
@description Retorna o número de dias de um mês de um dado ano
@created 04/11/2003
@param mes: um dígito no intervalo [1,12]
@param ano: um ano de quatro dígitos
@return o número de dias no mês especificado (-1 se o mes for inválido, ou seja, 
 fora do intervalo [1,12], ou se o ano for invalido, ou seja, fora do intervalo [1, 9999])

*/
function pfnDiasNoMes(mes, ano)
{
	if (isNaN(mes) || isNaN(ano) || mes < 1 || mes > 12 || ano < 1 || ano > 9999)
		return -1;
		
	switch(mes)
	{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			return 31;
		case 4:
		case 6:
		case 9:
		case 11:
			return 30;
		case 2:
			return ((ano % 4 == 0) ? 29: 28);
	}
}

//*************************************************************************************************************
/**
@name pfnFormataDataOnBlur
@description Formata uma data à medida quando o foco sai do campo
 Elimina os caracteres que não sejam números. Inclui a barra separadora dos campos da data. 
 Deve ser usada no evento onBlur (apropriada para valores inseridos através de "cola")
@created 27/04/2011
@param input: o campo onde a data está sendo digitada
@return Não retorna nada
@author Aline Goulart
*/
function pfnFormataDataOnBlur(campo)
{
	var data, dataAux, dia, mes;
	
	data = campo.value.replace(/[^\d]+/g, '');
	dataAux = data;
	
	if ((data != "") || (data != '')){
	
		data = data.substring(0, 8);
	
		if (data.length >= 2){
			dia = data.substring(0,2);
			dataAux = dia + '/';
			
			if (data.length >= 4){
				mes = data.substring(2,4);
				dataAux = dataAux + mes + '/' + data.substring(4, data.length);
			}else 
				dataAux = dataAux + data.substring(2, data.length);
		}
	}
	
	data = dataAux;
	campo.value = data;			
}

//*************************************************************************************************************
/**
@name pfnFormataData
@description Formata uma data à medida que os caracteres são digitados
 Inclui a barra separadora dos campos da data. Não permite a digitação de caracteres que não sejam números
 Deve ser usada no evento onKeyPress
@created 30/10/2003
@param input: o campo onde a data está sendo digitada
@return Não retorna nada

*/

function pfnFormataData2(campo, evento)
{
  //tratamento para outros navegadores que nao o IE
  var tecla = 0;
  
  var UA = navigator.userAgent;
  if (UA.indexOf('MSIE') > -1) {
     alert('ie1');
    tecla = evtKeyPress.keyCode;
	alert('ie');
  } 
  else if (UA.indexOf('Firefox') > -1) {  
     alert('firefox1');
  tecla = evtKeyPress.which;  
   alert('firefox');}
  if (tecla == 0) tecla = evento.charCode;
 
  //verifica se os caracteres nao estao no range dos numericos 48-zero a 57-nove
  if (!pfnIsNumeric(campo, evento))
  {
    return false;
	  
  }else
  {
	//formata a data inserindo barra
	var data = campo.value;
	
	//verifica o tamanho para inserir barras, excetuando-se no momento do delete
	if (((data.length == 2)||(data.length == 5)) && tecla != 8)
	  campo.value = campo.value + "/" ;
  }
}	


//*************************************************************************************************************
/**
@name pfnFormataDataMesAno
@description Formata uma data à medida que os caracteres são digitados no formato mm/aaaa
 Inclui a barra separadora dos campos da data. Não permite a digitação de caracteres que não sejam números.
 Deve ser usada no evento onKeyPress
@created 15/01/2004
@param input: o objeto que contém a data a ser validada
@param true: se o objeto passado for uma data válida
@return Não retorna nada
@author Marcos Conde Lopes
*/
function pfnFormataDataMesAno(input)
{
//formata no seguinte formato mm/aaaa
	if (event.keyCode < 48 || event.keyCode > 57)
		event.returnValue = false;
	else 
		if(input.value.length == 2)
			input.value=input.value + "/";
}


//*************************************************************************************************************
/**
@name pfnFormataData10Caracteres
@description Formata uma data no formato dd/mm/aaaa
 O input dessa função deve ser uma data de 8 a 10 dígitos no formato d[d]/m[m]/aaaa
 Ou seja, o que essa função realmente faz é preencher com zeros à esquerda para assegurar 
 que o output dessa função seja uma data com 10 caracteres
@created 04/11/2003
@param data: a string a ser validada
@return a data formatada ou o parâmetro data caso data não esteja formatada apropriadamente

@exemplo var str10 = pfnFormataData10Caracteres("9/10/2002"); // str10 será "09/10/2002"
*/
function pfnFormataData10Caracteres(data)
{
	var partes;
	try
	{
		partes = data.split("/");
		if (partes[0].length == 1)
			partes[0] = "0" + partes[0];
		if (partes[1].length == 1)
			partes[1] = "0" + partes[1];
		
		return partes[0] + "/" + partes[1] + "/" + partes[2];
	}
	catch (e)
	{
		return data;
	}
}


//*************************************************************************************************************
/**
@name pfnFormataData7Caracteres
@description Formata uma data no formato mm/aaaa. O input dessa função deve ser uma data de 8 a 10 dígitos
 no formato d[d]/m[m]/aaaa. O que essa função realmente faz é preencher com zeros à
 esquerda para assegurar que o output dessa função seja uma data
@created 15/01/2004
@param data: a string a ser validada
@return a data formatada ou o parâmetro data caso data não esteja formatada apropriadamente
@author Marcos Conde Lopes
*/
function pfnFormataData7Caracteres(data)
{
	var partes;
	try
	{
		partes = data.split("/");
		if (partes[0].length == 1)
			partes[0] = "0" + partes[0];
		if (partes[1].length == 1)
			partes[1] = "0" + partes[1];
		
		return partes[1] + "/" + partes[2];
	}
	catch (e)
	{
		return data;
	}
}


//*************************************************************************************************************
/**
@name pfnValidaEFormataData
@description A mesma função abaixo, porém aceita o nome do form para obter o campo onde a data
 está sendo digitada
@created 04/11/2003
@param form: o nome do formulário que contém o campo cuja data será validada
@param campo: o nome do campo que contém a data a ser validada
@param mensagem: a mensagem a ser mostrada ao usuário se a data não for válida
@return true, se a validação da data tiver sucesso; false, caso contrário
@author Marcos Lopes Conde
@exemplo <input name="dataASerValidada" onBlur='pfnValidaEFormataData("formName", this.name, "Mensagem Personalizada")'></input>
*/
function pfnValidaEFormataData(form, campo, mensagem)
{
	eval("input = document." + form + "." + campo + ";");
  return pfnValideFormateData(input, mensagem);
}


//*************************************************************************************************************
/**
@name pfnValideFormateData
@description Verifica se uma data é válida, ou seja, se o dia, o mês e o ano estão corretos
 Se a data não estiver formatada no padrão dd/mm/aaaa mas for válida, formata a data nesse padrão
@created 04/11/2003
@param input: o campo onde a data está sendo digitada
@param mensagem: a mensagem a ser mostrada ao usuário se a data não for válida
@return true, se a validação da data tiver sucesso; false, caso contrário
@author Marcos Lopes Conde
*/
function pfnValideFormateData(input, mensagem)
{
	// se a validação falhar, focalize o campo que deu problema e mostre a mensagem, se houver alguma
	var sucesso = pfnValideFormateData_(input.value);
  if (sucesso == null && pfnTrim(input.value) != "")
	{
		if (mensagem != "")
			alert(mensagem);
		input.select();
		// o focus precisa estar aqui por causa de bugs nos tabs do explorer
		input.focus();
	}
	else if (sucesso != null)
	 input.value = sucesso;
	return sucesso != null;
}


//*************************************************************************************************************
/**
@name pfnValideFormateData_
@description Verifica se uma data é válida, ou seja, se o dia, o mês e o ano estão corretos
 Se a data não estiver formatada no padrão dd/mm/aaaa mas mas for válida, formata a data nesse padrão
@created 04/11/2004
@param data_: a string a ser validada
@return a data formatada, caso esta seja válida, ou null, caso contrário
*/
function pfnValideFormateData_(data_)
{
	try
	{
    var ano, mes, dia, data, partes, sucesso, resultado;
		resultado = null;
		sucesso = true;
    data = new String(data_);

		// se a data estiver em branco, a validação tem sucesso
		// isso permite ao usuário mudar sua opção de escolha no formulário
		if (data == "")
			return null;
		// uma data deve ter no mínimo 8 caracteres (d/m/aaaa ou ddmmaaaa) e no máximo 10 caracteres (dd/mm/aaaa)
		if (data.length < 8 || data.length > 10)
			throw "exception";
		// quebre a data em três partes
		partes = data.split("/");

		// se ela tiver duas barras, recupere o dia, mês e ano
		if (partes.length == 3)
		{
			// eu não uso parseInt porque ela não lê alguns dígitos com leading 0´s da maneira certa
			// por exemplo, '09' é convertido para 0
			dia = new Number(partes[0]).valueOf();
			mes = new Number(partes[1]).valueOf();
			ano = new Number(partes[2]).valueOf();

			if (isNaN(dia) || isNaN(mes) || isNaN(ano))
				throw "exception";
		}
		// se não houver duas barras, a data precisa ter exatamente 8 dígitos
		// para a validação funcionar - o dia é os 2 primeiros caracteres,
		// o mês é os 2 seguintes e o ano os 4 seguintes
		else
		{
			// se a data tiver caracteres inválidos, isso será detectado na próxima validação
			var dataSemBarras = data.replace(/\D/g, "");
			if (dataSemBarras.length != 8 || isNaN(dataSemBarras))
				throw "exception";
			else
			{
				dia = new Number(dataSemBarras.substring(0, 2)).valueOf();
				mes = new Number(dataSemBarras.substring(2, 4)).valueOf();
				ano = new Number(dataSemBarras.substring(4, 8)).valueOf();

				// preencha essa variável com as substrings porque ela será usada embaixo para
				// remontar as datas com as barras
				partes[0] = dataSemBarras.substring(0, 2);
				partes[1] = dataSemBarras.substring(2, 4);
				partes[2] = dataSemBarras.substring(4, 8);
			}
		}
		// valide o dia, mês e ano
		if ((mes < 1 || mes > 12) ||
			(ano < 1900 || ano > 2185) ||
			(dia < 1 || dia > pfnDiasNoMes(mes, ano)))
			sucesso = false;
	}
	catch(e)
	{
		sucesso = false;
	}

	// se a validação tiver sucesso, concatene as partes da data novamente, formatando-a de
	// modo que tenha 10 caracteres
	if (sucesso)
	{
		if (partes[0].length == 1)
			partes[0] = "0" + partes[0];
		if (partes[1].length == 1)
			partes[1] = "0" + partes[1];
		resultado =  partes[0] + '/' + partes[1]  + '/' + ano;
	}
	return resultado;
}

//*************************************************************************************************************
/**
@name pfnValidaEFormataDataMesAno
@description Verifica se uma data é válida, ou seja, se o mês e o ano estão corretos
 Se a data não estiver formatada no padrão mm/aaaa mas for válida, formata a data nesse padrão
@created 15/01/2004
@param input: o campo que contém a data a ser validada
@param mensagem: a mensagem a ser mostrada ao usuário se a data não for válida
@return true, se a validação da data tiver sucesso; false, caso contrário
@author Marcos Conde Lopes
*/
function pfnValidaEFormataDataMesAno(input, mensagem)
{
	// se a validação falhar, focalize o campo que deu problema e mostre a mensagem, se houver alguma
	var sucesso = pfnValideFormateDataMesAno(input.value);
  if (sucesso == null && pfnTrim(input.value) != "")
	{
		if (mensagem != "")
			alert(mensagem);
		input.select();
		// o focus precisa estar aqui por causa de bugs nos tabs do explorer
		input.focus();
	}
	return sucesso != null;
}


//*************************************************************************************************************
/**
@name pfnValideFormateDataMesAno
@description Verifica se uma data é válida, ou seja, se o mês e o ano estão corretos
 Se a data não estiver formatada no padrão mm/aaaa mas for válida, formata a data nesse padrão
@created 04/11/2004
@param data: a data a ser validada
@return a data formatada, se esta for válida, ou null, caso contrário
*/
function pfnValideFormateDataMesAno(data_)
{
	try
	{
		var partes, ano, mes, data, sucesso;
		resultado = null;
		sucesso = true;
		var data = pfnTrim(new String(data_));
		// se a data estiver em branco, a validação tem sucesso
		if (data == "")
			return null;
		if (data.indexOf("/")==-1)	   
			   throw "exception";
		// uma data deve ter no mínimo 6 caracteres (m/aaaa ou mmaaaa) e no máximo 7 caracteres (mm/aaaa)
		if (data.length < 6 || data.length > 7)
			throw "exception";
		// quebre a data em mês e ano
		partes = data.split("/");

		// se ela tiver duas partes, recupere  mês e ano
		if (partes.length == 2)
		{
			mes = new Number(partes[0]).valueOf();
			ano = new Number(partes[1]).valueOf();

			if (isNaN(mes) || isNaN(ano))
			   throw "exception";
		}
		// o mês é os 2 seguintes e o ano os 4 seguintes
		else
		{
			var dataSemBarras = data.replace("/", "");
			if (dataSemBarras.length != 6 || isNaN(dataSemBarras))
				throw "exception";

			mes = new Number(dataSemBarras.substring(0, 2)).valueOf();
			ano = new Number(dataSemBarras.substring(2, 6)).valueOf();

			// preencha essa variável com as substrings porque ela será usada embaixo para
			// remontar as datas com as barras
			partes[0] = dataSemBarras.substring(0, 2);
			partes[1] = dataSemBarras.substring(2, 6);
		}
		// valide o dia, mês e ano
		if ((mes < 1 || mes > 12) ||
			(ano < 1900 || ano > 2185))
			throw "exception";
	}
	catch(e)
	{
		sucesso = false;
	}

	// se a validação tiver sucesso, concatene as partes da data novamente, formatando-a de
	// modo que tenha 10 caracteres
	if (sucesso)
	{
		if (partes[0].length == 1)
			partes[0] = "0" + partes[0];
		resultado = partes[0]  + '/' + ano;
	}
	return resultado;
}
//exemplo de como usar
//if (!fnValidarHora(document.frm.HoraInicio.value))
//{
 			 // document.frm.HoraInicio.focus();
 //return false;
//};
//se retornar falso então a hora é inválida.
function fnValidarHora(valor){
			data = valor;
	  		partes = data.split(":");

		// se ela tiver duas partes, recupere  mês e ano
		if (partes.length == 2)
		{
			hora = new Number(partes[0]).valueOf();
			minuto = new Number(partes[1]).valueOf();

			if (isNaN(hora) || isNaN(minuto)){
			  alert("O preenchimento do campo é obrigatório.");
			 // document.frm.HoraInicio.focus();
			  return false;
			 
			};
			if (hora>23){
			  alert("Hora não pode ser mais que 23:59 horas.");
			 // document.frm.HoraInicio.focus();
			  return false;
			 
			};
			if (minuto>59){
			  alert("Minuto não pode ser mais que 23:59 minutos.");
			  document.frm.HoraInicio.focus();
			  return false;
			 
			};	
			
		};
		return true;
};
		
//*************************************************************************************************************
/**
@name pfnDiminuirDataMesAno
@description Diminui a data no formato de mês e ano.
@created 27/06/2007
@param data_: a data a ser diminuida.
@param mesesADiminuir: quantidade de meses a serem diminuidos.
@return a data formatada, se esta for válida, ou em branco, caso contrário
*/

function pfnDiminuirDataMesAno(data_,mesesADiminuir)
{
	try
	{
		var partes, ano, mes, data, sucesso;
		resultado = null;
		sucesso = true;
		var data = new String(data_);
		// se a data estiver em branco, a validação tem sucesso
		if (data == "")
			return null;
		if (data.indexOf("/")==-1)	   
			   throw "exception";
		// uma data deve ter no mínimo 6 caracteres (m/aaaa ou mmaaaa) e no máximo 7 caracteres (mm/aaaa)
		if (data.length < 6 || data.length > 7)
			throw "exception";
		// quebre a data em mês e ano
		partes = data.split("/");

		// se ela tiver duas partes, recupere  mês e ano
		if (partes.length == 2)
		{
			mes = new Number(partes[0]).valueOf();
			ano = new Number(partes[1]).valueOf();

			if (isNaN(mes) || isNaN(ano))
			   throw "exception";
		}
		// o mês é os 2 seguintes e o ano os 4 seguintes
		else
		{
			var dataSemBarras = data.replace("/", "");
			if (dataSemBarras.length != 6 || isNaN(dataSemBarras))
				throw "exception";

			mes = new Number(dataSemBarras.substring(0, 2)).valueOf();
			ano = new Number(dataSemBarras.substring(2, 6)).valueOf();

			// preencha essa variável com as substrings porque ela será usada embaixo para
			// remontar as datas com as barras
			partes[0] = dataSemBarras.substring(0, 2);
			partes[1] = dataSemBarras.substring(2, 6);
		}
		// valide o dia, mês e ano
		if ((mes < 1 || mes > 12) ||
			(ano < 1900 || ano > 2185))
			throw "exception";
	}
	catch(e)
	{
		sucesso = false;
	}

	// se a validação tiver sucesso, concatene as partes da data novamente, formatando-a de
	// modo que tenha 10 caracteres
	if (sucesso)
	{
		
		
		mes = mes - mesesADiminuir;
		//se passar para o ano passado o soma 12 meses e diminui um ano, até fixar o ano.
		while(mes<1)
		{	
			ano = ano - 1; 
			mes = mes*1 + 12;
		}
		mes = new String(mes);
		if (mes.length == 1)
			mes = "0" + mes;
							
		resultado = mes + '/' + ano;
	}
	return resultado;
}


//*************************************************************************************************************
/**
@name pfnValideDia
@description Valida um dia entrado pelo usuário em um campo qualquer
 Não leva em consideração o mês, por isso o dia pode ser qualquer valor entre 0 e 31, inclusive.
 A função exibe a mensagem de erro passada e focaliza o campo, caso o dia seja inválido e o
 usuário tenha passado uma mensagem e um campo a ser focalizado
@created 07/01/2004
@param input: o objeto que contém o dia a ser validado. Se for passado um campo válido, caso a validação falhe, 
 o campo é focalizado
@param dia: o valor a ser validado
@param mensagem: a mensagem a ser exibida caso a validação falhe. Se for passado uma mensagem em branco,
 nenhuma mensagem é exibida
@return true, se a validação tiver sucesso; false, caso contrário

*/
function pfnValideDia(input, diaStr, mensagemErro)
{
	// assuma que a validação falhou
	var sucesso = false;

	// prossiga se o valor digitado não for uma string vazia 
	if (diaStr != "")
	{
		// o valor digitado convertido a número
		var numero;
	
		// prossiga somente se o valor a ser validado não contiver caracteres não-numéricos
		if (diaStr.length == diaStr.replace(/\D/g, "").length)
		{
			// converta o valor digitado para um número
			numero = new Number(diaStr).valueOf();
	
			// determine se o número é um dia válido
			if (numero > 0 && numero <= 31)
				sucesso = true;
		}
		
		// se a validação falhou, exiba a mensagem de erro e focalize o campo onde o dia foi digitado
		// caso esses valores sejma válidos
		if (!sucesso)
		{
			if (mensagemErro != "")
				alert(mensagemErro);
			
			// determine se o nome do input é válido e se esse campo existe
			if (input != null)
			{
				var existe;
				eval("existe = document.all('" + input.id + "');");
				if (existe)
				{
					eval("document.all.item('" + input.id + "').focus();");
					eval("document.all.item('" + input.id + "').select();");
				}
			}
		}
	}
	return sucesso;
}
</script>



<!-- HTML5 -->
<script>
/*
function sizeOfThings(){
	//alert('aqui');
    var windowWidth = window.innerWidth;
  var windowHeight = window.innerHeight;
  
  var screenWidth = screen.width;
  var screenHeight = screen.height;
    if(windowWidth>1919){
        var scale = 'scale(1)';
        document.body.style.webkitTransform =  scale;    // Chrome, Opera, Safari
        document.body.style.msTransform =   scale;       // IE 9
        document.body.style.transform = scale;     // General
    } else{
       // var scale = 'scale(0.67)';
        document.body.style.webkitTransform =  scale;    // Chrome, Opera, Safari
        document.body.style.msTransform =   scale;       // IE 9
        document.body.style.transform = scale;     // General

    }





 // document.querySelector('.window-size').innerHTML = windowWidth + 'x' + windowHeight;
 // document.querySelector('.screen-size').innerHTML = screenWidth + 'x' + screenHeight;

};
sizeOfThings();
window.addEventListener('resize', function(){
	sizeOfThings();
});*/
</script>

<script>	
function sizeOfThingsFim(){
         /*                                                                           var windowWidth = window.innerWidth;
                                                                                    var windowHeight = window.innerHeight;
                                                                                    
                                                                                  //  document.getElementById("txChat").style.width=330;
                                                                                                                    //    button.style.width=285;
                                                                                                                     //   submit.style.width=285;
                                                                                                                       // reset.style.width=285;
                                                                                    //TAMANHO DO ZOOM
                                                                                    //alert('aqui');
                                                                                    var isMobile=  navigator.userAgent.match(/WPDesktop|IEMobile|Opera Mini|BlackBerry|Android|iPhone|iPad|iPod/i);
                                                                                    if (isMobile==null){
                                                                                        isMobile="Computador";
                                                                                        document.body.style.zoom = "100%";
                                                                                    } else{
                                                                                       // document.body.style.zoom = "67%";
                                                                                    };

                                                                                    //alert(isMobile);
                                                                                    if (windowWidth>1919){
                                                                                        document.body.style.zoom = "100%";
                                                                                         //     document.getElementById("idtamanhodaPaginaRolagem").style.height=1500   ;
                                                                                       
                                                                                    }else{

                                                                                        if (windowWidth>1500){
                                                                                        document.body.style.zoom = "100%";
                                                                                        //     document.getElementById("idtamanhodaPaginaRolagem").style.height=1204   ;
                                                                                        }else{                                                                            
                                                                                            if (windowWidth>1200){
                                                                                                document.body.style.zoom = "100%";
                                                                                                
                                                                                            }else{
                                                                                                if (windowWidth>765){
                                                                                                    document.body.style.zoom = "100%";
                                                                                                    
                    

                                                                                                }else{
                                                                                                    //entra aqui se for maior
                                                                                                    if (windowWidth>392){
                                                                                                        
                                                                                                        if (isMobile=='iPhone'){
                                                                                                               document.body.style.zoom = "55%";
                                                                                                            
                                                                                                            } else{
                                                                                                                // android 393
                                                                                                             //   document.body.style.zoom = "100%"; 
                                                                                                                
                                                                                                            }                                                                                            

                                                                                                    }else{
                                                                                                        if (windowWidth>376){
                                                                                                            if (isMobile=='iPhone'){
                                                                                                                document.body.style.zoom = "42%";
                                                                                                                

                                                                                                            } else{
                                                                                                            //    document.body.style.zoom = "100%";
                                                                                                                                                                                                                 
                                                                                                            }  
                                                                                                            

                                                                                                        }else{
                                                                                                            if (windowWidth>350){
                                                                                                                if (isMobile=='iPhone'){
                                                                                                                     document.body.style.zoom = "29%";                                                                                                                                               

                                                                                                                } else{
                                                                                                                 //   document.body.style.zoom = "100%";
                                                                                                                                                                                                                    
                                                                                                                }                                                                                                                
                                                                                                                                                                                                                   

                                                                                                            }else{
                                                                                                                if (windowWidth>310){
                                                                                                                    if (isMobile=='iPhone'){
                                                                                                                        document.body.style.zoom = "29%";      
                                                                                                                      //  document.getElementById("txChat").style.width=285;
                                                                                                                       // button.style.width=285;
                                                                                                                       // submit.style.width=285;
                                                                                                                       // reset.style.width=285;
                                                                                                                    } else{
                                                                                                                        document.body.style.zoom = "100%";
                                                                                                                                                                                                                        
                                                                                                                    }                                                                                                                
                                                                                                                                                                                                                   

                                                                                                                }else{
                                                                                                                    document.body.style.zoom = "100%";
                                                                                                                                                                                                                    
                                                                                                                }
                                                                                                                                                                                                                
                                                                                                            }
                                                                                                            
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                            
                                                                                //    var screenWidth = screen.width;
                                                                                //    var screenHeight = screen.height;
                                                                                    
                                                                                //  document.querySelector('.window-size').innerHTML = windowWidth + 'x' + windowHeight;

                                                                                //   document.querySelector('.screen-size').innerHTML = screenWidth + 'x' + screenHeight;
                                                                                //<br> Screen size is <span class="screen-size"></span>
                                                                              //  toggleZoomScreen();
                                                                            //    document.getElementById("divMensagemGeral").innerHTML= "Zoom="+document.body.style.zoom + "width="+windowWidth+ "AP="+ isMobile;
                                                                            document.getElementById("divMensagemGeral").innerHTML= " Copyright (c) 2021  |  TALKBOT. Zoom="+document.body.style.zoom + " Width="+windowWidth+ " Ap="+ isMobile;
                                                                             //   document.getElementById("txZoom").value=document.body.style.zoom;
                                                                             //   alert(document.getElementById("divMensagemGeral").innerHTML);

                                                                             //   alert(isMobile.iOS());

                                                                        };
                                                                        sizeOfThingsFim();

                                                                        window.addEventListener('resize', function(){
                                                                            sizeOfThingsFim();
                                                                        });
																		*/
                                                                    </script>
<style>
      
         
</style>
<meta charset="utf-8"/>

<link rel="stylesheet" type="text/css" href="_css_estiloGeral.css">
<link rel="stylesheet" type="text/css" href="jquery.dataTables.min.css">
<script type="text/javascript" language="javascript" src="jquery-1.12.4.js"></script>
<script type="text/javascript" language="javascript" src="Portuguese-Brasil.json.js"></script>
<script type="text/javascript" language="javascript" src="jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="dataTables.buttons.min.js"></script>
<script type="text/javascript" language="javascript" src="jszip.min.js"></script>
<script type="text/javascript" language="javascript" src="buttons.html5.min.js"></script>
<script type="text/javascript" language="javascript" src="buttons.print.min.js"></script>
<script type="text/javascript" language="javascript" src="vfs_fonts.js"></script>
<script type="text/javascript" language="javascript" src="pdfmake.min.js"></script>
<script type="text/javascript" language="javascript" src="buttons.flash.min.js"></script>

<link rel="stylesheet" href="style.css">

<script>
	function str_replace(strAntiga,strNova,str){
		var i = 0;
		while ((i = str.indexOf(strAntiga, i)) != -1) {
			str = str.replace(strAntiga, strNova);
		}
		return str;
	}
//tira caracteres especiais
function fnTirarCaracteresEspeciaisCampos(stringInformada){
	

	formatado=str_replace('Á','A',stringInformada);
	formatado=str_replace('á','A',formatado);
	formatado=str_replace('Â','A',formatado);
	formatado=str_replace('â','A',formatado);
	formatado=str_replace('À','A',formatado);
	formatado=str_replace('à','A',formatado);
	formatado=str_replace('Å','A',formatado);
	formatado=str_replace('å','A',formatado);
	formatado=str_replace('Ã','A',formatado);
	formatado=str_replace('ã','A',formatado);
	formatado=str_replace('Ä','A',formatado);
	formatado=str_replace('ä','A',formatado);
	formatado=str_replace('Æ','A',formatado);
	formatado=str_replace('æ','A',formatado);
	formatado=str_replace('É','E',formatado);
	formatado=str_replace('é','E',formatado);
	formatado=str_replace('Ê','E',formatado);
	formatado=str_replace('ê','E',formatado);
	formatado=str_replace('È','E',formatado);
	formatado=str_replace('è','E',formatado);
	formatado=str_replace('Ë','E',formatado);
	formatado=str_replace('ë','E',formatado);
	formatado=str_replace('Ð','D',formatado);
	formatado=str_replace('ð','E',formatado);
	formatado=str_replace('Í','I',formatado);
	formatado=str_replace('í','I',formatado);
	formatado=str_replace('Î','I',formatado);
	formatado=str_replace('î','I',formatado);
	formatado=str_replace('Ì','I',formatado);
	formatado=str_replace('ì','I',formatado);
	formatado=str_replace('Ï','I',formatado);
	formatado=str_replace('ï','I',formatado);
	formatado=str_replace('Ó','O',formatado);
	formatado=str_replace('ó','O',formatado);
	formatado=str_replace('Ô','O',formatado);
	formatado=str_replace('ô','O',formatado);
	formatado=str_replace('Ò','O',formatado);
	formatado=str_replace('ò','O',formatado);
	formatado=str_replace('Ø','O',formatado);
	formatado=str_replace('ø','O',formatado);
	formatado=str_replace('Õ','O',formatado);
	formatado=str_replace('õ','O',formatado);
	formatado=str_replace('Ö','O',formatado);
	formatado=str_replace('ö','O',formatado);
	formatado=str_replace('Ú','U',formatado);
	formatado=str_replace('ú','U',formatado);
	formatado=str_replace('Û','U',formatado);
	formatado=str_replace('û','U',formatado);
	formatado=str_replace('Ù','U',formatado);
	formatado=str_replace('ù','U',formatado);
	formatado=str_replace('Ü','U',formatado);
	formatado=str_replace('ü','U',formatado);
	formatado=str_replace('Ç','C',formatado);
	formatado=str_replace('ç','C',formatado);
	formatado=str_replace('Ñ','N',formatado);
	formatado=str_replace('ñ','N',formatado);
	formatado=str_replace('<','',formatado);
	formatado=str_replace('>','',formatado);
	formatado=str_replace('&','',formatado);
	formatado=str_replace('"','',formatado);
	formatado=str_replace('®','',formatado);
	formatado=str_replace('©','',formatado);
	formatado=str_replace('Ý','',formatado);
	formatado=str_replace('ý','',formatado);
	formatado=str_replace('Þ','',formatado);
	formatado=str_replace('þ','',formatado);
	formatado=str_replace('ß','',formatado);
	formatado=str_replace('Á','',formatado);
	formatado=str_replace('á','',formatado);
//FORMATAÇÃO HTML PARA LETRAS.
	formatado=str_replace('&Acirc;','A',formatado);
	formatado=str_replace('&acirc;','A',formatado);
	formatado=str_replace('&Agrave;','A',formatado);
	formatado=str_replace('&agrave;','A',formatado);
	formatado=str_replace('&Aring;','A',formatado);
	formatado=str_replace('&aring;','A',formatado);
	formatado=str_replace('&Atilde;','A',formatado);
	formatado=str_replace('&atilde;','A',formatado);
	formatado=str_replace('&Auml;','A',formatado);
	formatado=str_replace('&auml;','A',formatado);
	formatado=str_replace('&AElig;','A',formatado);
	formatado=str_replace('&aelig;','A',formatado);
	formatado=str_replace('&Eacute;','E',formatado);
	formatado=str_replace('&eacute;','E',formatado);
	formatado=str_replace('&Ecirc;','E',formatado);
	formatado=str_replace('&ecirc;','E',formatado);
	formatado=str_replace('&Egrave;','E',formatado);
	formatado=str_replace('&egrave;','E',formatado);
	formatado=str_replace('&Euml;','E',formatado);
	formatado=str_replace('&euml;','E',formatado);
	formatado=str_replace('&ETH;','D',formatado);
	formatado=str_replace('&eth;','E',formatado);
	formatado=str_replace('&Iacute;','I',formatado);
	formatado=str_replace('&iacute;','I',formatado);
	formatado=str_replace('&Icirc;','I',formatado);
	formatado=str_replace('&icirc;','I',formatado);
	formatado=str_replace('&Igrave;','I',formatado);
	formatado=str_replace('&igrave;','I',formatado);
	formatado=str_replace('&Iuml;','I',formatado);
	formatado=str_replace('&iuml;','I',formatado);
	formatado=str_replace('&Oacute;','O',formatado);
	formatado=str_replace('&oacute;','O',formatado);
	formatado=str_replace('&Ocirc;','O',formatado);
	formatado=str_replace('&ocirc;','O',formatado);
	formatado=str_replace('&Ograve;','O',formatado);
	formatado=str_replace('&ograve;','O',formatado);
	formatado=str_replace('&Oslash;','O',formatado);
	formatado=str_replace('&oslash;','O',formatado);
	formatado=str_replace('&Otilde;','O',formatado);
	formatado=str_replace('&otilde;','O',formatado);
	formatado=str_replace('&Ouml;','O',formatado);
	formatado=str_replace('&ouml;','O',formatado);
	formatado=str_replace('&Uacute;','U',formatado);
	formatado=str_replace('&uacute;','U',formatado);
	formatado=str_replace('&Ucirc;','U',formatado);
	formatado=str_replace('&ucirc;','U',formatado);
	formatado=str_replace('&Ugrave;','U',formatado);
	formatado=str_replace('&ugrave;','U',formatado);
	formatado=str_replace('&Uuml;','U',formatado);
	formatado=str_replace('&uuml;','U',formatado);
	formatado=str_replace('&Ccedil;','C',formatado);
	formatado=str_replace('&ccedil;','C',formatado);
	formatado=str_replace('&Ntilde;','N',formatado);
	formatado=str_replace('&ntilde;','N',formatado);

return formatado.toLowerCase();
};
//preenche um campo hidden baseado no checkbox que ele selecionou.
function fnPreencheCBAutomaticamenteB(campoSelecionado,NomeCampoHDSelect,valor)
{
	//alert(document.getElementById(NomeCampoHDSelect).value);
   // var valoratual;
    //pega o valor do Radio para verificar se j� est� checado.
   // eval('valoratual = document.' + pNomeform + '.' + pNomeCampo + '[' + preencheRBNumero + '].checked;');
    //se n�o fizer este if e dar checkin duas vezes d� um erro no java script.
  //  if( valoratual == false)
    //    eval('document.' + pNomeform + '.' + pNomeCampo + '[' + preencheRBNumero + '].checked = true;');   
	//alert(campoSelecionado.checked);
	//isso se for checkbox se for radio só preenche o ultimo.
	if(campoSelecionado.checked)
	{
		//adiciona.
		document.getElementById(NomeCampoHDSelect).value = document.getElementById(NomeCampoHDSelect).value+'#'+valor+'#';
	}
	else
	{
	//exclui
				data = document.getElementById(NomeCampoHDSelect).value;
				data = data.replace('#'+valor+'#','');
				document.getElementById(NomeCampoHDSelect).value =data;
	};
	//se for radio só preenche com o dado informado e apaga o resto automáticamente.
	if (campoSelecionado.type=="radio"){
		document.getElementById(NomeCampoHDSelect).value = '#'+valor+'#';
	}
	
	//alert(NomeCampoHDSelect);
	//alert(document.getElementById(NomeCampoHDSelect).value);
}

//*************************************************************************************************************
/**
@name fnPreencheCBEnviaOsCampos
@description preenche os check box com os dados do campo hidden no onload
@created 15/07/2020
@param valor: valor para ser gravado
@param NomeCampoHDSelect: Campo exclu�do
@param NomeCampoHDSelect2: Campo onde tem as informações #Sábado##Segunda#.
@return Nao retorna nada
@author Marcos Condes Lopes
*/
function fnPreencheCBOnload(NomeCampoHDSelect2)
{
	//alert("TodosOsCamposSelecionados");
	TodosOsCamposSelecionados =document.getElementById(NomeCampoHDSelect2).value;



	TodosOsCamposSelecionados=fnTirarCaracteresEspeciaisCampos(TodosOsCamposSelecionados);
	//TodosOsValores="";	
   // var valoratual;
    //pega o valor do Radio para verificar se j� est� checado.
   // eval('valoratual = document.' + pNomeform + '.' + pNomeCampo + '[' + preencheRBNumero + '].checked;');
    //se n�o fizer este if e dar checkin duas vezes d� um erro no java script.
  //  if( valoratual == false)
    //    eval('document.' + pNomeform + '.' + pNomeCampo + '[' + preencheRBNumero + '].checked = true;');   
	//alert(TodosOsCamposSelecionados);
	while(TodosOsCamposSelecionados!="")
	{
		//pega o campo
		//StringCompleta.substring(StringCompleta.indexOf(StrInicial)+StrInicial.length,StringCompleta.indexOf(StrFinal))
		ipSegundoCampo = TodosOsCamposSelecionados.substring(1,TodosOsCamposSelecionados.length);
	//	alert("ipSegundoCampo");		
	//	alert(ipSegundoCampo);
	//	alert(ipSegundoCampo.indexOf("#"));
		ipSegundoCampo = ipSegundoCampo.substring(0,ipSegundoCampo.indexOf("#"));
		nomeCheckbox= "rb_"+ipSegundoCampo.toLowerCase()+'_'+NomeCampoHDSelect2
	//pode ser null por ser checkbox ou é radio se diferente de null é radio
	if (document.getElementById(nomeCheckbox)!=null){
		nomeCheckbox= "rb_"+ipSegundoCampo.toLowerCase()+'_'+NomeCampoHDSelect2;
	}
	else{
	// o nome é formado por cb_valor_nomedocampohidden cb_Domingo_NomeCampoHDSelect2
		nomeCheckbox= "cb_"+ipSegundoCampo.toLowerCase()+'_'+NomeCampoHDSelect2;
	};
		document.getElementById(nomeCheckbox).checked = true;
	//	alert("ipSegundoCampo");		
	//	alert(ipSegundoCampo);
		//adiciona ele na vari�vel
	//	TodosOsValores = TodosOsValores+'#'+document.getElementById(ipSegundoCampo).value+'#';		
	//			alert("TodosOsValores");
	//	alert(TodosOsValores);		
		//if (pfnValidaCampo(document.getElementById(ipSegundoCampo),'O preenchimento do campo Quantidade de HST � obrigat�rio, quando a op��o � selecionada.','OBRIGATORIO','')){return false;}; 
		//exclui
		data = TodosOsCamposSelecionados;
		data = data.replace('#'+ipSegundoCampo+'#','');
		TodosOsCamposSelecionados =data;
	}

	return true;
}

</script>

<?php if (gt("ordenacao")=="") {
	 $ordenacao="1"; 
	} else{
		$ordenacao=gt("ordenacao"); 
	}; ?>
<script src="moment.min.js"></script>
<script src="datetime-moment.js"></script>

<script type="text/javascript">
			
	function fnUploadArquivoParaBase(prtabelaGravar,prstrCabecalhoRegras,prstrCabecalho){
		document.frmArquivo.tabelaGravar.value=prtabelaGravar;
		document.frmArquivo.strCabecalhoRegras.value=prstrCabecalhoRegras;
		document.frmArquivo.strCabecalho.value=prstrCabecalho;
		document.frmArquivo.submit();
		
	}
	
		function uniqueRand( n, max ) {
			var result = [];
			var pool = [];
			var i;

			for ( i=0 ; i<max ; i++ ) {
				pool.push( i );
			}

			var getNumber = function () {
				var index = Math.floor(pool.length * Math.random());
				var drawn = pool.splice(index, 1);
				return drawn[0];
			};

			for ( i=0 ; i<n ; i++ ) {
				result.push( getNumber() );
			}

			return result;
		}



		//$(document).ready( function () {
			//$.fn.dataTable.moment( 'DD/MM/YYYY HH:mm:ss' );
			$(document).ready(function(e){
				jQuery.extend(jQuery.fn.dataTableExt.oSort, {
					"date-br-pre": function ( a ) {
						if (a == null || a == "") {
							return 0;
						}
						var brDatea = a.split('/');
						return (brDatea[2] + brDatea[1] + brDatea[0]) * 1;
					},

					"date-br-asc": function ( a, b ) {
						return ((a < b) ? -1 : ((a > b) ? 1 : 0));
					},

					"date-br-desc": function ( a, b ) {
						return ((a < b) ? 1 : ((a > b) ? -1 : 0));
					}
				});
				$.fn.dataTable.moment( 'DD/MM/YYYY HH:mm:ss' );    //Formatação com Hora
				$.fn.dataTable.moment('DD/MM/YYYY');				

			$('#example')
				.addClass( 'nowrap' )
				.dataTable( {	
					    // você pode usar um dos dois com data ou data e hora

					"order": [[ <?php echo $ordenacao; ?>, "desc" ]] ,  //Campo ordenado por padrão (ao carregar página)				
					dom: 'Bfrtip',
					columnDefs: [
						{
							type: 'date-br', 
							targets: 4 
						}
					],					

					buttons: [
						'copy', 'csv', 'excel', 'pdf', 'print',
						       /*     ,{
							text: 'Import',
							action: function ( e, dt, node, config ) {
								alert( 'Importando arquivo aguarde.' );
							}
						}*/
					],
					responsive: true,
					columnDefs: [
						{ targets: [-1, -3], className: 'dt-body-right' }
					],
						"bJQueryUI": true,
						"oLanguage": {
							"sProcessing":   "Processando...",
							"sLengthMenu":   "Mostrar _MENU_ registros",
							"sZeroRecords":  "Não foram encontrados resultados",
							"sInfo":         "Mostrando de _START_ até _END_ de _TOTAL_ registros",
							"sInfoEmpty":    "Mostrando de 0 até 0 de 0 registros",
							"sInfoFiltered": "",
							"sInfoPostFix":  "",
							"sSearch":       "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Buscar:",
							"sUrl":          "",
							"oPaginate": {
								"sFirst":    " Primeiro ",
								"sPrevious": " Anterior ",
								"sNext":     " Seguinte ",
								"sLast":     " Último "
							}
						}
						
				} );

			var list = $('div.w-g-l > ul');
			list.children(':gt(7)').css( 'display', 'none' );

			var showingFull = false;
			$('<li><a>Mostre mais campos...</a></li>')
				.on( 'click', function (e) {
					e.preventDefault;

					if ( showingFull ) {
						list.children(':gt(7)').css( 'display', 'none' );
						list.children(':last').css( 'display', 'block' );
						$('a', this).html('Mostre mais campos...');
						showingFull = false;
					}
					else {
						list.find('li').css( 'display', 'block' );
						$('a', this).html('Show less');
						showingFull = true;
					}
				} )
				.appendTo( list );

			// Used by
			var usedBy = [
				[ 'http://www.cern.ch/', 'cern.png', 'CERN' ],
				[ 'http://latimes.com', 'la_times.png', 'LA Times' ],
				[ 'http://openlibrary.org/', 'open_library.png', 'Open Library' ],
				[ 'http://www.ppmroadmap.com/', 'ppmroadmap.jpg', 'PPM Roadmap' ],
				[ 'http://www.st-andrews.ac.uk/', 'stAndrews.png', 'St Andrews University' ],
				[ 'http://www.travellerspoint.com/', 'travellerspoint.png', 'Travellers Point' ],
				[ 'http://usatoday.com', 'usatoday.png', 'USA Today' ],
				[ 'http://www.sipcapture.org/', 'homer.png', 'Homer' ],
				[ 'http://www.amazon.com/', 'amazon.jpg', 'Amazon' ],
				[ 'http://pocketsmith.com/', 'pocketsmith_icon.png', 'PocketSmith' ],
				[ 'http://flightmapping.com/', 'flightmappinglogo88.png', 'FlightMapping.com' ],
				[ 'http://www.venuedirectory.com/', 'VenueDir.png', 'Venue Directory' ],
				[ 'https://www.misk.com/', 'Misk.png', 'Misk' ],
				[ 'http://www.avaza.com/', 'avaza.png', 'avaza' ],
				[ 'http://www.flysfo.com/', 'sfo.png', 'San Francisco International Airport' ]
			];

			$.each( uniqueRand( 6, usedBy.length ), function (i, val) {
				data = usedBy[ val ];
				$('#usedBy').append(
					'<div class="unit one-sixth center">'+
						'<a href="'+data[0]+'"><img src="/media/images/used_by/'+data[1]+'" alt="DataTables is used by '+data[2]+'"></a>'+
					'</div>'
				);
			} );
			
 

		} );
	
	
		</script>

<?php
//Aqui são armazenadas todas as funções globais tanto no servidor quanto no cliente
?>
<script language='JavaScript'>
/*var _str = "";
var _timeout = 0;
 
function cbboxSearch(sel, e) {
    var i=0, c=true;
    _str = _str + String.fromCharCode(e.keyCode);
    _str = _str.toLowerCase();
    while (c) {
        var textOpt = sel.options[i].text.toLowerCase();
        var strOpt = textOpt.substr(0, (_str.length));
        if (strOpt == _str) {
            sel.options[i].selected = true;
            c = false;
        }
        if (i >= (sel.options.length - 1)) {
            c = false;
        }
        i++;
    }
    clearTimeout(_timeout);
    _timeout = setTimeout("cbboxSearchRestart()", 2000);
}
 
function cbboxSearchRestart() {
    clearTimeout(_timeout);
    _str = "";
}
*/
//<input type=text value=""   placeholder="Busque o cliente aqui." onChange='fnBuscaSelect(this,"inputselectDE_CLIENTE");'><br>
</script>
<script language='JavaScript'>
		function fnBuscaSelect(busca,select){
		
				<?php 
				if(!isset($_SESSION["LOGADO"])){
					$_SESSION["LOGADO"]="";
				};
				if(!isset($_SESSION["SQ_PERFIL"])){
					$_SESSION["SQ_PERFIL"]="";
				};	
				?>			
				
				<?php 	
				// se ele estiver logado e o perfil for difetente de cliente pode buscar pelos dados dos clientes. 
					if ($_SESSION["LOGADO"]=="SIM" and $_SESSION["SQ_PERFIL"]!="10"){
						 ?>
					


					
												var valorABuscar= busca.value;
												document.getElementById("nomeCliente").innerHTML="";
												valorABuscar=valorABuscar.toLowerCase();
												var selectedTrends = document.getElementById(select);
												selectedTrends.style.display="none";
													valorIndex=selectedTrends.selectedIndex;
													var soprineiro=true;
													var soprineiroSelecionado='0';
													for(var i=0; i < selectedTrends.length; i++)
													{
														valorTextSelect=selectedTrends.options[i].text;
														valorTextSelect=valorTextSelect.toLowerCase();
														//se achou o dado dentro do que digitou então mostra.
														if (valorTextSelect.indexOf(valorABuscar)>-1){
															if (soprineiro){
																soprineiro=false;	
																valorIndex=i;
																//valorText=selectedTrends.options[i].text;
															}
															//se entrou aqui tem algum dado encontrado.
															if(valorTextSelect=="Nenhum dado encontrado para essa pesquisa."){
																selectedTrends.options[i].style.display="none";
															} else{
																selectedTrends.options[i].style.display="";
																if(soprineiroSelecionado=='0'){
																	document.getElementById("nomeCliente").innerHTML=valorTextSelect;																	
																	selectedTrends.options[i].selected="true";	
																	soprineiroSelecionado='1';															
																}
															}
															

														}else{
															selectedTrends.options[i].style.display="none";
															selectedTrends.options[i].selected='';
														}
													}
													//Não tem nenhum dado.
													if ((soprineiro) && (valorABuscar!="")){
														var opt0 = document.createElement("option");
														opt0.value = "";
														opt0.text = "Nenhum dado encontrado para essa pesquisa.";
														document.getElementById("nomeCliente").innerHTML="Nenhum dado encontrado para essa pesquisa.";
														//if (browser == "Microsoft Internet Explorer") {
														//	try{
														//		selectedTrends.appendChild(opt0, selectedTrends.options[selectedTrends.length+1]);
														//	}catch(e){
															
																selectedTrends.appendChild(opt0, selectedTrends.options[selectedTrends.length+1]);
																	//	}
																//	} else {
																		selectedTrends.appendChild(opt0, selectedTrends.options[selectedTrends.length+1]);
																		
																//	}
														//		selectedTrends.options[valorIndex].selected='selected';
														//	selectedTrends.style.display="";
														//	selectedTrends.focus();
														//manda para a outra página para consultar
														if (validarCPF(busca.value)){															
															document.formAgenda.DE_HORA.disabled=false; 
															document.formAgenda.DT_DATA.disabled=false; 
															alert('Cliente não cadastrado, será redirecionado para o cadastro de cliente.');
															fnConsultarOutraPagina(document.formAgenda.NU_CPF,"NU_CPF",document.formAgenda,"Agenda_Edit.php","Cliente_Edit.php");	
														}										
																						
												}
												selectedTrends.style.display="";
												selectedTrends.focus();S
														
														
													<?php } else
														{ 
														?>

											if (validarCPF(busca.value)){	
												document.getElementById("btCliente").style.display="none";
												document.getElementById("nomeCliente").innerHTML="";																							
												var valorABuscar= busca.value;
												valorABuscar=valorABuscar.toLowerCase();
												var selectedTrends = document.getElementById(select);
												selectedTrends.style.display="none";
													valorIndex=selectedTrends.selectedIndex;
													var soprineiro=true;
													for(var i=0; i < selectedTrends.length; i++)
													{
														valorTextSelect=selectedTrends.options[i].text;
														valorTextSelect=valorTextSelect.toLowerCase();
														//se achou o dado dentro do que digitou então mostra.
														if (valorTextSelect.indexOf(valorABuscar)>-1){
															if (soprineiro){
																soprineiro=false;	
																valorIndex=i;
																//valorText=selectedTrends.options[i].text;
															}
															//se entrou aqui tem algum dado encontrado.
															if(valorTextSelect=="Nenhum dado encontrado para essa pesquisa."){
																selectedTrends.options[i].style.display="none";
															} else{
																document.getElementById("nomeCliente").innerHTML=valorTextSelect;
																selectedTrends.options[i].style.display="";
																document.getElementById("btCliente").style.display="none";																
																selectedTrends.options[i].selected="true";
															}
															

														}else{
															selectedTrends.options[i].style.display="none";
															selectedTrends.options[i].selected='';
														}
													}
													//Não tem nenhum dado.
													if ((soprineiro) && (valorABuscar!="")){
														var opt0 = document.createElement("option");
														opt0.value = "";
														opt0.text = "Nenhum dado encontrado para essa pesquisa.";
														document.getElementById("nomeCliente").innerHTML="Nenhum CPF encontrado, clique em inserir novo cliente.";	
														document.getElementById("btCliente").style.display="";	

														//if (browser == "Microsoft Internet Explorer") {
														//	try{
														//		selectedTrends.appendChild(opt0, selectedTrends.options[selectedTrends.length+1]);
														//	}catch(e){
															
																selectedTrends.appendChild(opt0, selectedTrends.options[selectedTrends.length+1]);
														//	}
														//	} else {
															selectedTrends.appendChild(opt0, selectedTrends.options[selectedTrends.length+1]);
															
														//	}
														//		selectedTrends.options[valorIndex].selected='selected';
														//manda para a outra página para consultar
														if (validarCPF(busca.value)){															
															document.formAgenda.DE_HORA.disabled=false; 
															document.formAgenda.DT_DATA.disabled=false; 
															alert('Cliente não cadastrado, será redirecionado para o cadastro de cliente.');
															fnConsultarOutraPagina(document.formAgenda.NU_CPF,"NU_CPF",document.formAgenda,"Agenda_Edit.php","Cliente_Edit.php");	
														}	
																						
													}else {
														selectedTrends.style.display="";
														selectedTrends.focus();
													}

												//verificando se o cpf é válido.
											} else{
												var opt0 = document.createElement("option");
														opt0.value = "";
														opt0.text = "Nenhum CPF encontrado.";
														document.getElementById("nomeCliente").innerHTML="Digite um CPF válido para consultar.";	
														document.getElementById(select).style.display='none';

											};
										<?php //se não estiver logado
										}; ?>	

			};	
			</script>
<script language='JavaScript'>
			//	Exemplo: 
		//	onClick='fnConsultarOutraPagina(document.formAgenda.NU_CPF,"NU_CPF",document.formAgenda,"Agenda_Edit.php","Cliente_Edit.php");'	
		function fnConsultarOutraPagina(campoDado,campoBusca,form,paginaRetorno,paginaBusca){			
				<?php // se ele estiver logado e o perfil for difetente de cliente pode buscar pelos dados dos clientes. 
					if ($_SESSION["LOGADO"]=="SIM" and $_SESSION["SQ_PERFIL"]!="10"){ ?>

						if(campoDado.value!=0){
							document.formAgenda.action=paginaBusca+"?TelaVinculadaRetorno="+paginaRetorno+"&"+campoBusca+"="+campoDado.value;form.submit();
						} else {
							alert("Preencha o campo abaixo com o CPF ou nome dele para ver se tem o cliente cadastrado.");
						};						

					<?php } else
					 { 
					?>
						if (validarCPF(campoDado.value)){
							document.formAgenda.action=paginaBusca+"?TelaVinculadaRetorno="+paginaRetorno+"&"+campoBusca+"="+campoDado.value;form.submit();
						} else {
							alert("Preencha o campo abaixo com o seu CPF para ver se já está cadastrado no sistema. Evitando duplicidade no cadastro.");
						}
						;
				

				<?php }; ?>	
				};	
												

</script>

<script language='JavaScript'>
	function fnReplaceAll(str,strAntiga,strNova){
		var i = 0;
		while ((i = str.indexOf(strAntiga, i)) != -1) {
			str = str.replace(strAntiga, strNova);
		}
		return str;
	}
	

function fnTituloPrimeiraMaiuscula(str) {
 //pega apenas as palavras e tira todos os espaços em branco.
 return str.replace(/\w\S*/g, function(str) {

  //passa o primeiro caractere para maiusculo, e adiciona o todo resto minusculo
  return str.charAt(0).toUpperCase() + str.substr(1).toLowerCase();
 });
} 
</script>
<script type="text/javascript">   
	function funcoesGlobaisMensagem(Mensagem,campo){
		//assim pode mudar em apenas um lugar e colocar em um div, ou no topo da página como o cliente desejar alterando só nesse arquivo.
	//	alert('Mensagem2');
		alertM(Mensagem,campo);
		
	}  
</script>
<script type="text/javascript">   	
	function funcoesGlobaisDtMaiorAtual(Mensagem,campo){	
	    dataForm  = new Date(campo.value);
        dataAtual = new Date();
        if(dataForm >= dataAtual){
          alertM("Data tem que ser maior que a data atual.",campo);
          return false;
        }
	}
</script>
<script type="text/javascript">   
	function funcoesGlobaisDtMaiorOutra(Mensagem,campo,campoData2){	
	    dataForm  = new Date(campo.value);
        dataAtual =  new Date(campoData2.value);
        if(dataForm >= dataAtual){
			//"Data tem que ser maior que a data deste campo."
	      alertM(Mensagem,campo);
          return false;
        }
	}	
	</script>
<script type="text/javascript">   
	function funcoesGlobaisValidaData(Mensagem,campo){
			
			data=campo.value;
			//verifica se veio no formato 2107-12-31 ou 31/12/2017
			if ((data.substring(4,5)=='-') && (data.substring(7,8)=='-')){
				//var $dia = data.substring(0,2);
				//var $mes = data.substring(3,5);
				//var $ano = data.substring(6,10);
				var $dia = data.substring(8,10);
				var $mes = data.substring(5,7);
				var $ano = data.substring(0,4);
				data= $dia + '/' + $mes + '/'+ $ano;
			}
	//		alert(data);
//	alert('funcoesGlobaisvalData');
		if (data!=''){	
								//				alert('funcoesGlobaisvalData1');
			// Verificar se o formato da data digitada está correto	
			var patternData = /^[0-9]{2}\/[0-9]{2}\/[0-9]{4}$/;
			if(!patternData.test(data)){
				if(Mensagem==""){

					Mensagem="Digite a data no formato Dia/Mês/Ano";
				}

				fnMensagem(Mensagem,campo);		
				//campo.focus();
				return false;
			} else {
								//		alert('funcoesGlobaisvalData2');
				if(funcoesGlobaisvalData(Mensagem,campo)){
					return true;
				}else{
					return false;
				};
			}
		}else{
											//		alert('funcoesGlobaisvalData2');
			return true;
		}
			
	}
</script>
<script type="text/javascript">   

function funcoesGlobaisvalData(Mensagem,campo){//dd/mm/aaaa
	data=campo.value;
	//verifica se veio no formato 2107-12-31 ou 31/12/2017
	if ((data.substring(4,5)=='-') && (data.substring(7,8)=='-')){
		//var $dia = data.substring(0,2);
		//var $mes = data.substring(3,5);
		//var $ano = data.substring(6,10);
		var $dia = data.substring(8,10);
		var $mes = data.substring(5,7);
		var $ano = data.substring(0,4);
		data= $dia + '/' + $mes + '/'+ $ano;
	}
	var day = data.substring(0,2);
	var month = data.substring(3,5);
	var year = data.substring(6,10);
	//alert('aq');
	//alert(data);
	if( (year < 1) || (year > 9999) ){
		//	alert('aq1');
			if(Mensagem==""){
				Mensagem="O ano da data está inválido.";
			}
			fnMensagem(Mensagem,campo);		
			campo.focus();
			return false;
	} else {
//alert('aq3');		
		if( (month < 01) || (month > 12) ){
				if(Mensagem==""){
					Mensagem="O mês da data está inválido.";
				}
				fnMensagem(Mensagem,campo);			
				campo.focus();
				return false;
		} else {
			if( (month==01) || (month==03) || (month==05) || (month==07) || (month==08) || (month==10) || (month==12) )    {//mes com 31 dias
				if( (day < 01) || (day > 31) ){
					if(Mensagem==""){
						Mensagem="O dia da data está inválido, tem que estar entre 01 e 31 dias.";
					}
					fnMensagem(Mensagem,campo);		
					campo.focus();
					return false;
				}
			} else {
				if( (month==04) || (month==06) || (month==09) || (month==11) ){//mes com 30 dias
					if( (day < 01) || (day > 30) ){
						if(Mensagem==""){
							Mensagem="O dia da data está inválido. O mês especificado tem que estar entre 01 e 30 dias.";
						}
						fnMensagem(Mensagem,campo);		
						campo.focus();
						return false;
					}
				} 
				else {
               // alert('aa');				
					if( (month==02) ){//February and leap year
						if( (year % 4 == 0) && ( (year % 100 != 0) || (year % 400 == 0) ) ){
							if( (day < 01) || (day > 29) ){
								if(Mensagem==""){
									
									Mensagem="O dia da data está inválido. O mês especificado tem que estar entre 01 e 29 dias.";
								}
								fnMensagem(Mensagem,campo);		
								//campo.focus();
								return false;
							}
						} else {
							if( (day < 01) || (day > 28) ){
								if(Mensagem==""){
									Mensagem="O dia da data está inválido. O mês especificado tem que estar entre 01 e 28 dias.";
								}
								fnMensagem(Mensagem,campo);		
								//campo.focus();
								return false;
							}
						}
					}
				}	
			}
		}
	}
	return true;
}


/************************************************************************************************************************************************************************************************************************************* 
 
	* FIM  DAS FUNÇÕES EM JAVA SCRIPT

************************************************************************************************************************************************************************************************************************************ */

</script>